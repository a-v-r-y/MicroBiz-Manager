import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { AppNotification, NotificationCategory, NotificationPriority, NotificationType } from '../types';
import { useApp } from './AppContext';
import { useAuth } from './AuthContext';

interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  isOpen: boolean;
  openNotifications: () => void;
  closeNotifications: () => void;
  toggleNotifications: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  dismissNotification: (id: string) => void;
  clearAllNotifications: () => void;
  triggerTestNotification: () => void;
  soundEnabled: boolean;
  toggleSound: () => void;
  playChime: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

const STORAGE_KEY_READ = 'microbiz_notifications_read';
const STORAGE_KEY_DISMISSED = 'microbiz_notifications_dismissed';
const STORAGE_KEY_CUSTOM = 'microbiz_notifications_custom';
const STORAGE_KEY_SOUND = 'microbiz_notifications_sound';

export const playNotificationChime = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;
    
    // Smooth dual-tone chime (D5 -> A5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
    
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
    
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    
    osc1.start(now);
    osc1.stop(now + 0.38);
  } catch {
    // Graceful fallback if autoplay restricted
  }
};

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { products, orders, purchaseOrders, settings } = useApp();
  const { isAuthenticated, isEmailVerified, currentUser } = useAuth();

  const [isOpen, setIsOpen] = useState(false);
  const [readIds, setReadIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_READ);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DISMISSED);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [customNotifications, setCustomNotifications] = useState<AppNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CUSTOM);
      return saved ? JSON.parse(saved) : [
        {
          id: 'sys-welcome',
          type: 'system_update',
          title: 'FIFO & LIFO Engine Active',
          message: 'Advanced inventory accounting with FIFO, LIFO, and LIFO Reserve audit verification is active.',
          timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
          read: false,
          priority: 'info',
          category: 'system',
          targetTab: 'inventory',
          actionLabel: 'Inspect Inventory'
        }
      ];
    } catch {
      return [];
    }
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SOUND);
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_READ, JSON.stringify(readIds));
    } catch (e) {
      console.error(e);
    }
  }, [readIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DISMISSED, JSON.stringify(dismissedIds));
    } catch (e) {
      console.error(e);
    }
  }, [dismissedIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CUSTOM, JSON.stringify(customNotifications));
    } catch (e) {
      console.error(e);
    }
  }, [customNotifications]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SOUND, JSON.stringify(soundEnabled));
    } catch (e) {
      console.error(e);
    }
  }, [soundEnabled]);

  // Derived automated business notifications
  const automatedNotifications = useMemo<AppNotification[]>(() => {
    const list: AppNotification[] = [];

    // 1. Out of stock / Low stock items
    products.forEach(p => {
      if (p.status === 'archived') return;
      if (p.stock <= 0) {
        list.push({
          id: `stock-out-${p.id}`,
          type: 'inventory_out',
          title: `Stock Depleted: ${p.name}`,
          message: `Zero physical units remaining in warehouse. Restock immediately to avoid lost orders.`,
          timestamp: p.createdAt || new Date().toISOString(),
          read: readIds.includes(`stock-out-${p.id}`),
          priority: 'critical',
          category: 'inventory',
          targetTab: 'inventory',
          targetId: p.id,
          actionLabel: 'Restock Product'
        });
      } else if (p.stock <= p.minStockAlert) {
        list.push({
          id: `stock-low-${p.id}`,
          type: 'inventory_low',
          title: `Low Stock Warning: ${p.name}`,
          message: `Only ${p.stock} ${p.unit} remaining (minimum alert threshold: ${p.minStockAlert}).`,
          timestamp: p.createdAt || new Date().toISOString(),
          read: readIds.includes(`stock-low-${p.id}`),
          priority: 'warning',
          category: 'inventory',
          targetTab: 'inventory',
          targetId: p.id,
          actionLabel: 'View Batches'
        });
      }
    });

    // 2. Pending orders needing confirmation or fulfillment
    const pendingOrders = orders.filter(o => o.orderStatus === 'pending');
    pendingOrders.forEach(o => {
      list.push({
        id: `order-pending-${o.id}`,
        type: 'order_pending',
        title: `Pending Order #${o.orderNumber}`,
        message: `${o.customerName} ordered ${o.items.length} item(s) totaling ${settings.currency} ${o.totalAmount.toLocaleString()}. Awaiting confirmation.`,
        timestamp: o.date || new Date().toISOString(),
        read: readIds.includes(`order-pending-${o.id}`),
        priority: 'warning',
        category: 'orders',
        targetTab: 'orders',
        targetId: o.id,
        actionLabel: 'Confirm Order'
      });
    });

    // 3. Outstanding accounts payable to suppliers
    const unpaidPOs = purchaseOrders.filter(po => po.status !== 'cancelled' && (po.totalAmount - (po.amountPaid || 0)) > 0);
    unpaidPOs.forEach(po => {
      const balance = po.totalAmount - (po.amountPaid || 0);
      list.push({
        id: `po-payable-${po.id}`,
        type: 'payment_due',
        title: `Supplier Payable: ${po.supplierName}`,
        message: `Outstanding balance of ${settings.currency} ${balance.toLocaleString()} on PO #${po.poNumber}.`,
        timestamp: po.createdAt || new Date().toISOString(),
        read: readIds.includes(`po-payable-${po.id}`),
        priority: 'info',
        category: 'financial',
        targetTab: 'payments',
        targetId: po.id,
        actionLabel: 'Pay Supplier'
      });
    });

    // 4. Authentication / Security Alerts
    if (isAuthenticated && !isEmailVerified) {
      list.push({
        id: `auth-verify-email`,
        type: 'security_alert',
        title: 'Email Verification Recommended',
        message: `Your account (${currentUser?.email}) is not yet verified. Complete verification to protect account access.`,
        timestamp: new Date().toISOString(),
        read: readIds.includes(`auth-verify-email`),
        priority: 'warning',
        category: 'system',
        targetTab: 'settings',
        actionLabel: 'Verify Account'
      });
    }

    return list;
  }, [products, orders, purchaseOrders, settings.currency, readIds, isAuthenticated, isEmailVerified, currentUser]);

  // Combined notifications (excluding dismissed ones), sorted by timestamp descending
  const notifications = useMemo(() => {
    const combined = [...customNotifications, ...automatedNotifications]
      .filter(n => !dismissedIds.includes(n.id))
      .map(n => ({
        ...n,
        read: readIds.includes(n.id)
      }));

    return combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [customNotifications, automatedNotifications, dismissedIds, readIds]);

  const unreadCount = useMemo(() => {
    return notifications.filter(n => !n.read).length;
  }, [notifications]);

  const markAsRead = (id: string) => {
    setReadIds(prev => prev.includes(id) ? prev : [...prev, id]);
  };

  const markAllAsRead = () => {
    const allIds = notifications.map(n => n.id);
    setReadIds(prev => Array.from(new Set([...prev, ...allIds])));
  };

  const dismissNotification = (id: string) => {
    setDismissedIds(prev => prev.includes(id) ? prev : [...prev, id]);
    // Also remove from custom if present
    setCustomNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    const allIds = notifications.map(n => n.id);
    setDismissedIds(prev => Array.from(new Set([...prev, ...allIds])));
    setCustomNotifications([]);
  };

  const toggleSound = () => {
    setSoundEnabled(prev => !prev);
  };

  const playChime = () => {
    if (soundEnabled) {
      playNotificationChime();
    }
  };

  const triggerTestNotification = () => {
    const now = new Date();
    const id = `test-notif-${Date.now()}`;
    const testItem: AppNotification = {
      id,
      type: 'order_placed',
      title: 'Real-time Test Alert Received',
      message: `Notification dispatch system tested successfully at ${now.toLocaleTimeString()}. Audio chime and badge counter verified!`,
      timestamp: now.toISOString(),
      read: false,
      priority: 'success',
      category: 'orders',
      targetTab: 'orders',
      actionLabel: 'View Orders'
    };

    setCustomNotifications(prev => [testItem, ...prev]);
    playChime();
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        isOpen,
        openNotifications: () => setIsOpen(true),
        closeNotifications: () => setIsOpen(false),
        toggleNotifications: () => setIsOpen(prev => !prev),
        markAsRead,
        markAllAsRead,
        dismissNotification,
        clearAllNotifications,
        triggerTestNotification,
        soundEnabled,
        toggleSound,
        playChime
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
