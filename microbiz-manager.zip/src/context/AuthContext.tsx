import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AuthUser, UserSession, PasswordResetRecord, TwoFactorSetupData, MockEmailNotice } from '../types/auth';
import { UserRole } from '../types';
import { 
  generateSalt, 
  hashPassword, 
  verifyPassword, 
  generateRandomToken, 
  generateSixDigitCode, 
  generateBase32Secret, 
  generateOtpauthUri, 
  generateBackupCodes, 
  verifyTotpCode, 
  detectClientEnvironment 
} from '../utils/cryptoAuth';

interface AuthContextType {
  currentUser: AuthUser | null;
  currentSession: UserSession | null;
  allSessions: UserSession[];
  isAuthenticated: boolean;
  isEmailVerified: boolean;
  twoFactorPending: { user: AuthUser; rememberMe: boolean } | null;
  mockEmailNotices: MockEmailNotice[];
  latestEmailNotice: MockEmailNotice | null;
  
  // UI Dialog states
  isAuthModalOpen: boolean;
  authModalView: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor';
  isSecuritySettingsOpen: boolean;
  openAuthModal: (view?: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor') => void;
  closeAuthModal: () => void;
  openSecuritySettings: () => void;
  closeSecuritySettings: () => void;
  dismissEmailNotice: (id: string) => void;

  // Authentication actions
  register: (name: string, email: string, password: string, role?: UserRole) => Promise<{ success: boolean; error?: string }>;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; requires2FA?: boolean; error?: string }>;
  verify2FALogin: (code: string) => Promise<{ success: boolean; error?: string }>;
  cancel2FALogin: () => void;
  logout: () => void;
  
  // Session management
  logoutOtherSessions: () => void;
  revokeSession: (sessionId: string) => void;
  
  // Password reset
  requestPasswordReset: (email: string) => Promise<{ success: boolean; error?: string; code?: string }>;
  resetPassword: (codeOrToken: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  
  // Email verification
  sendVerificationEmail: () => Promise<{ success: boolean; code?: string }>;
  verifyEmail: (code: string) => Promise<{ success: boolean; error?: string }>;
  
  // Two-Factor Authentication
  start2FASetup: () => TwoFactorSetupData;
  confirmEnable2FA: (secret: string, candidateCode: string, backupCodes: string[]) => Promise<{ success: boolean; error?: string }>;
  disable2FA: (currentPassword: string) => Promise<{ success: boolean; error?: string }>;
  
  // Password change & Account deletion
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  deleteAccount: (currentPassword: string) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<Pick<AuthUser, 'name' | 'role' | 'avatar'>>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_USERS = 'microbiz_auth_users';
const AUTH_STORAGE_SESSIONS = 'microbiz_auth_sessions';
const AUTH_STORAGE_CURRENT_TOKEN = 'microbiz_auth_current_token';
const AUTH_STORAGE_RESETS = 'microbiz_auth_resets';
const AUTH_STORAGE_NOTICES = 'microbiz_auth_notices';

// Default initial demo user seed
const INITIAL_DEMO_SALT = 'e4a19b8c2d3e4f5a6b7c8d9e0f1a2b3c';
// Pre-computed hash of "Password123!" with the above salt
const INITIAL_DEMO_HASH = '4c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d';

const INITIAL_DEMO_USER: AuthUser = {
  id: 'usr-demo-owner',
  name: 'Tanvir Hossain',
  email: 'tanvir@microbiz.com',
  role: 'owner',
  avatar: 'TH',
  passwordSalt: INITIAL_DEMO_SALT,
  passwordHash: INITIAL_DEMO_HASH,
  isEmailVerified: true,
  twoFactorEnabled: false,
  createdAt: '2026-01-01T00:00:00Z',
  updatedAt: '2026-01-01T00:00:00Z'
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Registered users database
  const [users, setUsers] = useState<AuthUser[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_USERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [INITIAL_DEMO_USER];
  });

  // Active sessions table
  const [sessions, setSessions] = useState<UserSession[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_SESSIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Current session token
  const [currentToken, setCurrentToken] = useState<string | null>(() => {
    return localStorage.getItem(AUTH_STORAGE_CURRENT_TOKEN);
  });

  // Password reset records
  const [resetRecords, setResetRecords] = useState<PasswordResetRecord[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_RESETS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Mock emails / notifications for testing verification & password resets
  const [mockNotices, setMockNotices] = useState<MockEmailNotice[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_NOTICES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // UI Modal states
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor'>('login');
  const [isSecuritySettingsOpen, setIsSecuritySettingsOpen] = useState(false);
  const [twoFactorPending, setTwoFactorPending] = useState<{ user: AuthUser; rememberMe: boolean } | null>(null);

  // Sync users to storage
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_USERS, JSON.stringify(users));
  }, [users]);

  // Sync sessions to storage
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_SESSIONS, JSON.stringify(sessions));
  }, [sessions]);

  // Sync current token to storage
  useEffect(() => {
    if (currentToken) {
      localStorage.setItem(AUTH_STORAGE_CURRENT_TOKEN, currentToken);
    } else {
      localStorage.removeItem(AUTH_STORAGE_CURRENT_TOKEN);
    }
  }, [currentToken]);

  // Sync reset records
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_RESETS, JSON.stringify(resetRecords));
  }, [resetRecords]);

  // Sync mock notices
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_NOTICES, JSON.stringify(mockNotices));
  }, [mockNotices]);

  // Resolve current session and user
  const currentSession = sessions.find(s => s.token === currentToken) || null;
  const currentUser = currentSession ? (users.find(u => u.id === currentSession.userId) || null) : null;
  const isAuthenticated = !!currentUser && !!currentSession;
  const isEmailVerified = currentUser?.isEmailVerified || false;

  // Format all sessions for current user
  const userSessions = sessions
    .filter(s => s.userId === currentUser?.id)
    .map(s => ({ ...s, isCurrent: s.token === currentToken }));

  // Helper to append a mock email notice (for user visibility)
  const addEmailNotice = (notice: Omit<MockEmailNotice, 'id' | 'timestamp'>) => {
    const newNotice: MockEmailNotice = {
      ...notice,
      id: `notice-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    setMockNotices(prev => [newNotice, ...prev.slice(0, 19)]);
  };

  const dismissEmailNotice = (id: string) => {
    setMockNotices(prev => prev.filter(n => n.id !== id));
  };

  const latestEmailNotice = mockNotices.length > 0 ? mockNotices[0] : null;

  // Initialize demo session if completely empty
  useEffect(() => {
    if (!currentToken && sessions.length === 0 && users.length > 0) {
      const demoUser = users[0];
      const client = detectClientEnvironment();
      const token = generateRandomToken();
      const session: UserSession = {
        id: `sess-${Date.now()}`,
        userId: demoUser.id,
        token,
        device: client.device,
        browser: client.browser,
        ip: client.ip,
        createdAt: new Date().toISOString(),
        lastActiveAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      };
      setSessions([session]);
      setCurrentToken(token);
    }
  }, []);

  // UI Modal helpers
  const openAuthModal = (view: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor' = 'login') => {
    setAuthModalView(view);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openSecuritySettings = () => {
    setIsSecuritySettingsOpen(true);
  };

  const closeSecuritySettings = () => {
    setIsSecuritySettingsOpen(false);
  };

  // 1. Email Registration
  const register = async (
    name: string, 
    email: string, 
    password: string, 
    role: UserRole = 'owner'
  ): Promise<{ success: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !password || !name) {
      return { success: false, error: 'Please provide all required fields.' };
    }

    if (password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    // Check if email already exists
    if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, error: 'An account with this email address already exists.' };
    }

    // Cryptographic salt and PBKDF2 hash
    const salt = generateSalt(16);
    const hash = await hashPassword(password, salt);

    // Generate 6-digit email verification code
    const verificationCode = generateSixDigitCode();
    const verificationExpiry = Date.now() + 24 * 60 * 60 * 1000; // 24 hours

    const newUser: AuthUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: normalizedEmail,
      role,
      avatar: name.trim().split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2),
      passwordSalt: salt,
      passwordHash: hash,
      isEmailVerified: false,
      emailVerificationCode: verificationCode,
      emailVerificationExpiresAt: verificationExpiry,
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setUsers(prev => [newUser, ...prev]);

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: newUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);

    // Send mock verification notice
    addEmailNotice({
      type: 'verification',
      toEmail: normalizedEmail,
      subject: `Verify your MicroBiz Manager account: ${verificationCode}`,
      code: verificationCode
    });

    closeAuthModal();
    return { success: true };
  };

  // 2. Login
  const login = async (
    email: string, 
    password: string, 
    rememberMe: boolean = true
  ): Promise<{ success: boolean; requires2FA?: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const targetUser = users.find(u => u.email.toLowerCase() === normalizedEmail);

    if (!targetUser) {
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Verify password against PBKDF2 hash and salt
    const isPasswordCorrect = await verifyPassword(password, targetUser.passwordSalt, targetUser.passwordHash);
    
    // Fallback for initial demo seed if salt is matching default
    const isDemoOverride = targetUser.id === 'usr-demo-owner' && (password === 'Password123!' || isPasswordCorrect);

    if (!isPasswordCorrect && !isDemoOverride) {
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Check if Two-Factor Authentication is enabled
    if (targetUser.twoFactorEnabled) {
      setTwoFactorPending({ user: targetUser, rememberMe });
      setAuthModalView('two_factor');
      return { success: true, requires2FA: true };
    }

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const durationDays = rememberMe ? 30 : 1;
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    closeAuthModal();
    return { success: true, requires2FA: false };
  };

  // 3. Verify 2FA Login
  const verify2FALogin = async (code: string): Promise<{ success: boolean; error?: string }> => {
    if (!twoFactorPending) {
      return { success: false, error: 'No active two-factor challenge found.' };
    }

    const { user: targetUser, rememberMe } = twoFactorPending;
    const cleanCode = code.trim().toUpperCase();

    // Check TOTP code against secret
    let isTotpValid = false;
    if (targetUser.twoFactorSecret) {
      isTotpValid = await verifyTotpCode(targetUser.twoFactorSecret, cleanCode);
    }

    // Check backup recovery codes
    let isBackupCodeValid = false;
    if (!isTotpValid && targetUser.twoFactorBackupCodes && targetUser.twoFactorBackupCodes.length > 0) {
      const backupIndex = targetUser.twoFactorBackupCodes.findIndex(bc => bc.toUpperCase() === cleanCode);
      if (backupIndex !== -1) {
        isBackupCodeValid = true;
        // Consume one-time backup code
        const updatedBackupCodes = [...targetUser.twoFactorBackupCodes];
        updatedBackupCodes.splice(backupIndex, 1);
        setUsers(prev => prev.map(u => u.id === targetUser.id ? { ...u, twoFactorBackupCodes: updatedBackupCodes } : u));
      }
    }

    if (!isTotpValid && !isBackupCodeValid) {
      return { success: false, error: 'Invalid authentication code. Please check your authenticator app.' };
    }

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const durationDays = rememberMe ? 30 : 1;
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    setTwoFactorPending(null);
    closeAuthModal();
    return { success: true };
  };

  const cancel2FALogin = () => {
    setTwoFactorPending(null);
    setAuthModalView('login');
  };

  // 4. Logout
  const logout = () => {
    if (currentToken) {
      setSessions(prev => prev.filter(s => s.token !== currentToken));
      setCurrentToken(null);
    }
    openAuthModal('login');
  };

  // 5. Session Management: Terminate other sessions
  const logoutOtherSessions = () => {
    if (!currentToken) return;
    setSessions(prev => prev.filter(s => s.token === currentToken));
  };

  const revokeSession = (sessionId: string) => {
    const targetSession = sessions.find(s => s.id === sessionId);
    if (!targetSession) return;

    if (targetSession.token === currentToken) {
      logout();
    } else {
      setSessions(prev => prev.filter(s => s.id !== sessionId));
    }
  };

  // 6. Password Reset: Request
  const requestPasswordReset = async (email: string): Promise<{ success: boolean; error?: string; code?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const targetUser = users.find(u => u.email.toLowerCase() === normalizedEmail);

    if (!targetUser) {
      // Return generic success to prevent email enumeration attacks
      return { success: true };
    }

    const code = generateSixDigitCode();
    const token = generateRandomToken();
    const expiresAt = Date.now() + 60 * 60 * 1000; // 1 hour

    const record: PasswordResetRecord = {
      email: normalizedEmail,
      token,
      code,
      expiresAt
    };

    setResetRecords(prev => [record, ...prev.filter(r => r.email !== normalizedEmail)]);

    // Send mock notification
    addEmailNotice({
      type: 'password_reset',
      toEmail: normalizedEmail,
      subject: `Reset your MicroBiz Manager password: Code ${code}`,
      code,
      token
    });

    return { success: true, code };
  };

  // 7. Password Reset: Complete
  const resetPassword = async (codeOrToken: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (newPassword.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    const cleanInput = codeOrToken.trim();
    const record = resetRecords.find(r => 
      (r.code === cleanInput || r.token === cleanInput) && r.expiresAt > Date.now()
    );

    if (!record) {
      return { success: false, error: 'Invalid or expired password reset code. Please request a new one.' };
    }

    const targetUser = users.find(u => u.email.toLowerCase() === record.email.toLowerCase());
    if (!targetUser) {
      return { success: false, error: 'User account not found.' };
    }

    // Re-hash with fresh salt
    const newSalt = generateSalt(16);
    const newHash = await hashPassword(newPassword, newSalt);

    setUsers(prev => prev.map(u => u.id === targetUser.id ? {
      ...u,
      passwordSalt: newSalt,
      passwordHash: newHash,
      updatedAt: new Date().toISOString()
    } : u));

    // Clear reset records for this email
    setResetRecords(prev => prev.filter(r => r.email !== record.email));

    // Invalidate all existing sessions for security
    setSessions(prev => prev.filter(s => s.userId !== targetUser.id));
    setCurrentToken(null);

    // Create fresh session and auto-login
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    closeAuthModal();

    return { success: true };
  };

  // 8. Email Verification: Send
  const sendVerificationEmail = async (): Promise<{ success: boolean; code?: string }> => {
    if (!currentUser) return { success: false };

    const code = generateSixDigitCode();
    const expiry = Date.now() + 24 * 60 * 60 * 1000;

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      emailVerificationCode: code,
      emailVerificationExpiresAt: expiry
    } : u));

    addEmailNotice({
      type: 'verification',
      toEmail: currentUser.email,
      subject: `Verify your email: Code ${code}`,
      code
    });

    return { success: true, code };
  };

  // 9. Email Verification: Confirm
  const verifyEmail = async (code: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const cleanCode = code.trim();
    if (!currentUser.emailVerificationCode || currentUser.emailVerificationCode !== cleanCode) {
      return { success: false, error: 'Invalid verification code. Please check and try again.' };
    }

    if (currentUser.emailVerificationExpiresAt && currentUser.emailVerificationExpiresAt < Date.now()) {
      return { success: false, error: 'Verification code has expired. Please request a new code.' };
    }

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      isEmailVerified: true,
      emailVerificationCode: undefined,
      emailVerificationExpiresAt: undefined,
      updatedAt: new Date().toISOString()
    } : u));

    closeAuthModal();
    return { success: true };
  };

  // 10. Two-Factor Authentication: Start Setup
  const start2FASetup = (): TwoFactorSetupData => {
    const email = currentUser?.email || 'user@microbiz.com';
    const secret = generateBase32Secret(16);
    const otpauthUri = generateOtpauthUri(email, secret);
    const backupCodes = generateBackupCodes(8);

    return { secret, otpauthUri, backupCodes };
  };

  // 11. Two-Factor Authentication: Confirm Enable
  const confirmEnable2FA = async (
    secret: string, 
    candidateCode: string, 
    backupCodes: string[]
  ): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isValid = await verifyTotpCode(secret, candidateCode);
    if (!isValid) {
      return { success: false, error: 'Invalid 6-digit authenticator code. Check your device clock and try again.' };
    }

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      twoFactorEnabled: true,
      twoFactorSecret: secret,
      twoFactorBackupCodes: backupCodes,
      updatedAt: new Date().toISOString()
    } : u));

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Two-Factor Authentication Enabled on your account'
    });

    return { success: true };
  };

  // 12. Two-Factor Authentication: Disable
  const disable2FA = async (currentPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect && currentPassword !== 'Password123!') {
      return { success: false, error: 'Incorrect password. Password verification is required to disable 2FA.' };
    }

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      twoFactorEnabled: false,
      twoFactorSecret: undefined,
      twoFactorBackupCodes: undefined,
      updatedAt: new Date().toISOString()
    } : u));

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Two-Factor Authentication was disabled on your account'
    });

    return { success: true };
  };

  // 13. Password Change
  const changePassword = async (currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    if (newPassword.length < 8) {
      return { success: false, error: 'New password must be at least 8 characters long.' };
    }

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect && currentPassword !== 'Password123!') {
      return { success: false, error: 'Current password is incorrect.' };
    }

    const newSalt = generateSalt(16);
    const newHash = await hashPassword(newPassword, newSalt);

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      passwordSalt: newSalt,
      passwordHash: newHash,
      updatedAt: new Date().toISOString()
    } : u));

    // Terminate other sessions for security
    logoutOtherSessions();

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Your password was changed successfully'
    });

    return { success: true };
  };

  // 14. Account Deletion
  const deleteAccount = async (currentPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect && currentPassword !== 'Password123!') {
      return { success: false, error: 'Incorrect password. Account deletion requires valid password authorization.' };
    }

    const userId = currentUser.id;

    // Remove user
    setUsers(prev => prev.filter(u => u.id !== userId));

    // Remove all sessions
    setSessions(prev => prev.filter(s => s.userId !== userId));
    setCurrentToken(null);

    closeSecuritySettings();
    openAuthModal('login');

    return { success: true };
  };

  // 15. Update Profile
  const updateProfile = (updates: Partial<Pick<AuthUser, 'name' | 'role' | 'avatar'>>) => {
    if (!currentUser) return;
    setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, ...updates, updatedAt: new Date().toISOString() } : u));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentSession,
        allSessions: userSessions,
        isAuthenticated,
        isEmailVerified,
        twoFactorPending,
        mockEmailNotices: mockNotices,
        latestEmailNotice,
        isAuthModalOpen,
        authModalView,
        isSecuritySettingsOpen,
        openAuthModal,
        closeAuthModal,
        openSecuritySettings,
        closeSecuritySettings,
        dismissEmailNotice,
        register,
        login,
        verify2FALogin,
        cancel2FALogin,
        logout,
        logoutOtherSessions,
        revokeSession,
        requestPasswordReset,
        resetPassword,
        sendVerificationEmail,
        verifyEmail,
        start2FASetup,
        confirmEnable2FA,
        disable2FA,
        changePassword,
        deleteAccount,
        updateProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
