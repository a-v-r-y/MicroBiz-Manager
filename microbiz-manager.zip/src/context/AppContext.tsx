import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  BusinessSettings, 
  Product, 
  Customer, 
  Supplier, 
  Order, 
  PurchaseOrder, 
  Expense, 
  FinancialAccount, 
  CashTransaction, 
  InventoryMovement,
  UserProfile,
  UserRole,
  AuditLog,
  OrderStatus,
  PaymentStatus,
  MovementType
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_SUPPLIERS,
  INITIAL_ORDERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_EXPENSES,
  INITIAL_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  INITIAL_MOVEMENTS,
  INITIAL_USER
} from '../data/sampleData';

interface AppContextType {
  user: UserProfile;
  settings: BusinessSettings;
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  orders: Order[];
  purchaseOrders: PurchaseOrder[];
  expenses: Expense[];
  accounts: FinancialAccount[];
  transactions: CashTransaction[];
  movements: InventoryMovement[];
  auditLogs: AuditLog[];
  darkMode: boolean;
  toggleDarkMode: () => void;
  setUserRole: (role: UserRole) => void;
  updateSettings: (newSettings: Partial<BusinessSettings>) => void;

  // Order actions
  addOrder: (order: Omit<Order, 'id' | 'orderNumber' | 'createdAt'>) => Order;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  updateOrderStatus: (id: string, newStatus: OrderStatus) => void;
  recordOrderPayment: (orderId: string, amount: number, accountId: string, method: string) => void;
  refundOrder: (orderId: string, refundAmount: number, accountId?: string) => void;

  // Product actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  archiveProduct: (id: string) => void;
  bulkImportProducts: (newProducts: Array<Omit<Product, 'id' | 'createdAt'>>) => void;

  // Inventory actions
  adjustStock: (productId: string, quantityChange: number, type: MovementType, notes?: string, unitCost?: number) => boolean;

  // Purchase Order actions
  addPurchaseOrder: (po: Omit<PurchaseOrder, 'id' | 'poNumber' | 'createdAt'>) => PurchaseOrder;
  updatePurchaseOrderStatus: (poId: string, status: PurchaseOrder['status']) => void;
  receivePurchaseOrder: (poId: string) => void;
  recordPOPayment: (poId: string, amount: number, accountId: string) => void;

  // Expense actions
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => Expense;
  deleteExpense: (id: string) => void;

  // Customer & Supplier actions
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => Customer;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  addSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt'>) => Supplier;
  updateSupplier: (id: string, updates: Partial<Supplier>) => void;

  // Financial Account & Transfer actions
  addAccount: (account: Omit<FinancialAccount, 'id'>) => FinancialAccount;
  transferFunds: (fromAccountId: string, toAccountId: string, amount: number, fee?: number, description?: string) => boolean;
  reconcileTransaction: (txId: string) => void;

  // Backup & Reset
  resetToSampleData: () => void;
  exportBackupJSON: () => string;
  importBackupJSON: (jsonData: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_PREFIX = 'microbiz_mgr_';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load state or fallback to sample seed
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}user`);
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [settings, setSettings] = useState<BusinessSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}settings`);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}products`);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}customers`);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}suppliers`);
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}orders`);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}purchaseOrders`);
    return saved ? JSON.parse(saved) : INITIAL_PURCHASE_ORDERS;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}expenses`);
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [accounts, setAccounts] = useState<FinancialAccount[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}accounts`);
    return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
  });

  const [transactions, setTransactions] = useState<CashTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}transactions`);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [movements, setMovements] = useState<InventoryMovement[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}movements`);
    return saved ? JSON.parse(saved) : INITIAL_MOVEMENTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}auditLogs`);
    return saved ? JSON.parse(saved) : [
      {
        id: 'aud-1',
        timestamp: new Date().toISOString(),
        user: 'Tanvir Hossain',
        action: 'System Initialized',
        entity: 'System',
        details: 'MicroBiz Manager loaded successfully with business profile'
      }
    ];
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem(`${STORAGE_PREFIX}darkMode`) === 'true';
  });

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(`${STORAGE_PREFIX}darkMode`, String(darkMode));
  }, [darkMode]);

  // Persist state changes
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}user`, JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}settings`, JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}products`, JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}customers`, JSON.stringify(customers)); }, [customers]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}suppliers`, JSON.stringify(suppliers)); }, [suppliers]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}orders`, JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}purchaseOrders`, JSON.stringify(purchaseOrders)); }, [purchaseOrders]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}expenses`, JSON.stringify(expenses)); }, [expenses]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}accounts`, JSON.stringify(accounts)); }, [accounts]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}transactions`, JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}movements`, JSON.stringify(movements)); }, [movements]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}auditLogs`, JSON.stringify(auditLogs)); }, [auditLogs]);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  const logAudit = (action: string, entity: string, details: string) => {
    const entry: AuditLog = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      user: user.name,
      action,
      entity,
      details
    };
    setAuditLogs(prev => [entry, ...prev.slice(0, 99)]);
  };

  const setUserRole = (role: UserRole) => {
    setUser(prev => ({ ...prev, role }));
    logAudit('Role Switched', 'User', `Active simulation role changed to ${role}`);
  };

  const updateSettings = (newSettings: Partial<BusinessSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    logAudit('Settings Updated', 'BusinessSettings', 'Business configurations updated');
  };

  // Order Actions
  const addOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt'>): Order => {
    const orderNumber = `ORD-${1000 + orders.length + 1}`;
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString()
    };

    // If inventory tracking is enabled and order is confirmed or delivered, deduct inventory and log movements
    if (settings.inventoryTracking && newOrder.orderStatus !== 'cancelled' && newOrder.orderStatus !== 'draft') {
      newOrder.items.forEach(item => {
        const prod = products.find(p => p.id === item.productId);
        if (prod) {
          const newStock = Math.max(0, prod.stock - item.quantity);
          // Movement log
          const movement: InventoryMovement = {
            id: `mov-${Date.now()}-${Math.random()}`,
            productId: prod.id,
            productName: prod.name,
            variantId: item.variantId,
            date: newOrder.date,
            type: 'sale',
            quantity: -item.quantity,
            unitCost: item.unitCostSnapshot,
            balanceAfter: newStock,
            referenceId: orderNumber,
            notes: `Sold in order ${orderNumber}`,
            createdBy: user.name
          };
          setMovements(prev => [movement, ...prev]);
        }
      });

      // Update product stock levels
      setProducts(prev => prev.map(p => {
        const matchedItems = newOrder.items.filter(i => i.productId === p.id);
        if (matchedItems.length === 0) return p;
        const totalQtyDeducted = matchedItems.reduce((sum, i) => sum + i.quantity, 0);
        return {
          ...p,
          stock: Math.max(0, p.stock - totalQtyDeducted)
        };
      }));
    }

    // If payment was made at order placement, record cash transaction and update account balance
    if (newOrder.amountPaid > 0 && newOrder.paymentAccountId) {
      const tx: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: newOrder.date,
        type: 'customer_payment',
        amount: newOrder.amountPaid,
        fee: newOrder.paymentFee,
        toAccountId: newOrder.paymentAccountId,
        reference: orderNumber,
        description: `Payment for ${orderNumber} (${newOrder.customerName})`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [tx, ...prev]);

      setAccounts(prev => prev.map(acc => {
        if (acc.id === newOrder.paymentAccountId) {
          return { ...acc, balance: acc.balance + newOrder.amountPaid - (newOrder.paymentFee || 0) };
        }
        return acc;
      }));
    }

    setOrders(prev => [newOrder, ...prev]);
    logAudit('Order Created', 'Order', `Order ${orderNumber} created for customer ${newOrder.customerName}`);
    return newOrder;
  };

  const updateOrder = (id: string, updates: Partial<Order>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
    logAudit('Order Modified', 'Order', `Order ${id} details updated`);
  };

  const updateOrderStatus = (id: string, newStatus: OrderStatus) => {
    const existing = orders.find(o => o.id === id);
    if (!existing) return;

    // Handle cancellation: return reserved items to stock
    if (newStatus === 'cancelled' && existing.orderStatus !== 'cancelled') {
      if (settings.inventoryTracking) {
        existing.items.forEach(item => {
          const prod = products.find(p => p.id === item.productId);
          if (prod) {
            const newStock = prod.stock + item.quantity;
            const movement: InventoryMovement = {
              id: `mov-${Date.now()}-${Math.random()}`,
              productId: prod.id,
              productName: prod.name,
              variantId: item.variantId,
              date: new Date().toISOString(),
              type: 'manual_adjustment',
              quantity: item.quantity,
              unitCost: item.unitCostSnapshot,
              balanceAfter: newStock,
              referenceId: existing.orderNumber,
              notes: `Stock returned due to cancelled order ${existing.orderNumber}`,
              createdBy: user.name
            };
            setMovements(prev => [movement, ...prev]);
          }
        });

        setProducts(prev => prev.map(p => {
          const matched = existing.items.filter(i => i.productId === p.id);
          if (matched.length === 0) return p;
          const returned = matched.reduce((sum, i) => sum + i.quantity, 0);
          return { ...p, stock: p.stock + returned };
        }));
      }
    }

    setOrders(prev => prev.map(o => o.id === id ? { ...o, orderStatus: newStatus } : o));
    logAudit('Order Status Updated', 'Order', `Order ${existing.orderNumber} status changed to ${newStatus}`);
  };

  const recordOrderPayment = (orderId: string, amount: number, accountId: string, method: string) => {
    const target = orders.find(o => o.id === orderId);
    if (!target) return;

    const newAmountPaid = (target.amountPaid || 0) + amount;
    const newPaymentStatus: PaymentStatus = newAmountPaid >= target.totalAmount ? 'paid' : 'partial';

    // Update order
    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      amountPaid: newAmountPaid,
      paymentStatus: newPaymentStatus,
      paymentAccountId: accountId,
      paymentMethod: method
    } : o));

    // Record cash transaction
    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'customer_payment',
      amount,
      toAccountId: accountId,
      reference: target.orderNumber,
      description: `Payment collected for ${target.orderNumber}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [tx, ...prev]);

    // Update account balance
    setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance + amount } : acc));
    logAudit('Payment Received', 'Order', `Received ${amount} for order ${target.orderNumber}`);
  };

  const refundOrder = (orderId: string, refundAmount: number, accountId?: string) => {
    const target = orders.find(o => o.id === orderId);
    if (!target) return;

    const currentRefund = target.refundAmount || 0;
    const totalRefund = currentRefund + refundAmount;

    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      refundAmount: totalRefund,
      paymentStatus: 'refunded'
    } : o));

    if (accountId) {
      const tx: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: new Date().toISOString(),
        type: 'refund',
        amount: refundAmount,
        fromAccountId: accountId,
        reference: target.orderNumber,
        description: `Customer refund for ${target.orderNumber}`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [tx, ...prev]);
      setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance - refundAmount } : acc));
    }

    logAudit('Order Refunded', 'Order', `Refund of ${refundAmount} issued for ${target.orderNumber}`);
  };

  // Product Actions
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt'>): Product => {
    const newProd: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    setProducts(prev => [newProd, ...prev]);

    // Record initial stock movement if > 0
    if (newProd.stock > 0) {
      const movement: InventoryMovement = {
        id: `mov-${Date.now()}`,
        productId: newProd.id,
        productName: newProd.name,
        date: new Date().toISOString(),
        type: 'initial',
        quantity: newProd.stock,
        unitCost: newProd.costPrice,
        balanceAfter: newProd.stock,
        referenceId: 'INITIAL-STOCK',
        notes: 'Initial inventory balance setup',
        createdBy: user.name
      };
      setMovements(prev => [movement, ...prev]);
    }

    logAudit('Product Created', 'Product', `Added new product ${newProd.name} (SKU: ${newProd.sku})`);
    return newProd;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    logAudit('Product Updated', 'Product', `Updated product details for ${id}`);
  };

  const archiveProduct = (id: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, status: 'archived' } : p));
    logAudit('Product Archived', 'Product', `Archived product ID ${id}`);
  };

  const bulkImportProducts = (newProducts: Array<Omit<Product, 'id' | 'createdAt'>>) => {
    const created: Product[] = newProducts.map((p, index) => ({
      ...p,
      id: `prod-${Date.now()}-${index}`,
      createdAt: new Date().toISOString()
    }));

    setProducts(prev => [...created, ...prev]);
    logAudit('Bulk Import', 'Product', `Imported ${created.length} products via CSV`);
  };

  // Stock Adjustment
  const adjustStock = (
    productId: string, 
    quantityChange: number, 
    type: MovementType, 
    notes?: string, 
    unitCost?: number
  ): boolean => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return false;

    const newStock = prod.stock + quantityChange;
    if (newStock < 0 && !settings.allowNegativeStock) {
      alert(`Adjustment rejected: Stock cannot become negative (${newStock}). Current stock is ${prod.stock}.`);
      return false;
    }

    const movement: InventoryMovement = {
      id: `mov-${Date.now()}`,
      productId: prod.id,
      productName: prod.name,
      date: new Date().toISOString(),
      type,
      quantity: quantityChange,
      unitCost: unitCost || prod.costPrice,
      balanceAfter: newStock,
      referenceId: `ADJ-${Date.now().toString().slice(-4)}`,
      notes: notes || `Manual stock adjustment (${type})`,
      createdBy: user.name
    };

    setMovements(prev => [movement, ...prev]);
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: newStock } : p));
    logAudit('Stock Adjusted', 'Inventory', `${prod.name} stock changed by ${quantityChange} (${type})`);
    return true;
  };

  // Purchase Orders Actions
  const addPurchaseOrder = (poData: Omit<PurchaseOrder, 'id' | 'poNumber' | 'createdAt'>): PurchaseOrder => {
    const poNumber = `PO-2026-${String(purchaseOrders.length + 1).padStart(2, '0')}`;
    const newPO: PurchaseOrder = {
      ...poData,
      id: `po-${Date.now()}`,
      poNumber,
      createdAt: new Date().toISOString()
    };

    setPurchaseOrders(prev => [newPO, ...prev]);
    logAudit('Purchase Order Created', 'PurchaseOrder', `Created PO ${poNumber} for supplier ${newPO.supplierName}`);
    return newPO;
  };

  const updatePurchaseOrderStatus = (poId: string, status: PurchaseOrder['status']) => {
    setPurchaseOrders(prev => prev.map(po => po.id === poId ? { ...po, status } : po));
    logAudit('PO Status Updated', 'PurchaseOrder', `PO ${poId} status changed to ${status}`);
  };

  // Goods Receipt from Purchase Order (Increases stock and records movement)
  const receivePurchaseOrder = (poId: string) => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;

    po.items.forEach(item => {
      const unreceivedQty = item.quantityOrdered - item.quantityReceived;
      if (unreceivedQty > 0) {
        const prod = products.find(p => p.id === item.productId);
        if (prod) {
          const newStock = prod.stock + unreceivedQty;
          const movement: InventoryMovement = {
            id: `mov-${Date.now()}-${Math.random()}`,
            productId: prod.id,
            productName: prod.name,
            date: new Date().toISOString(),
            type: 'purchase_receipt',
            quantity: unreceivedQty,
            unitCost: item.unitCost,
            balanceAfter: newStock,
            referenceId: po.poNumber,
            notes: `Received from supplier ${po.supplierName} under ${po.poNumber}`,
            createdBy: user.name
          };
          setMovements(prev => [movement, ...prev]);
          setProducts(prev => prev.map(p => p.id === prod.id ? { ...p, stock: newStock } : p));
        }
      }
    });

    setPurchaseOrders(prev => prev.map(p => p.id === poId ? {
      ...p,
      status: 'received',
      items: p.items.map(i => ({ ...i, quantityReceived: i.quantityOrdered }))
    } : p));

    logAudit('Goods Received', 'PurchaseOrder', `Goods received and stocked for PO ${po.poNumber}`);
  };

  const recordPOPayment = (poId: string, amount: number, accountId: string) => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;

    const newAmountPaid = po.amountPaid + amount;
    const newPaymentStatus: PaymentStatus = newAmountPaid >= po.totalAmount ? 'paid' : 'partial';

    setPurchaseOrders(prev => prev.map(p => p.id === poId ? {
      ...p,
      amountPaid: newAmountPaid,
      paymentStatus: newPaymentStatus
    } : p));

    // Cash transaction (deduct from account)
    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'supplier_payment',
      amount,
      fromAccountId: accountId,
      reference: po.poNumber,
      description: `Payment to ${po.supplierName} for ${po.poNumber}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [tx, ...prev]);

    setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance - amount } : acc));
    logAudit('Supplier Paid', 'PurchaseOrder', `Paid ${amount} to supplier for PO ${po.poNumber}`);
  };

  // Expense Actions
  const addExpense = (expenseData: Omit<Expense, 'id' | 'createdAt'>): Expense => {
    const newExp: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    setExpenses(prev => [newExp, ...prev]);

    // If an account was chosen, deduct balance and record transaction
    if (newExp.accountId) {
      const tx: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: newExp.date,
        type: 'expense',
        amount: newExp.amount,
        fromAccountId: newExp.accountId,
        reference: `EXP-${newExp.category.slice(0, 3).toUpperCase()}`,
        description: `${newExp.category}: ${newExp.description}`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [tx, ...prev]);
      setAccounts(prev => prev.map(acc => acc.id === newExp.accountId ? { ...acc, balance: acc.balance - newExp.amount } : acc));
    }

    logAudit('Expense Recorded', 'Expense', `Recorded expense of ${newExp.amount} for ${newExp.category}`);
    return newExp;
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
    logAudit('Expense Deleted', 'Expense', `Deleted expense ID ${id}`);
  };

  // Customers & Suppliers
  const addCustomer = (customerData: Omit<Customer, 'id' | 'createdAt'>): Customer => {
    const newCust: Customer = {
      ...customerData,
      id: `cust-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setCustomers(prev => [newCust, ...prev]);
    logAudit('Customer Created', 'Customer', `Added customer ${newCust.name}`);
    return newCust;
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const addSupplier = (supplierData: Omit<Supplier, 'id' | 'createdAt'>): Supplier => {
    const newSup: Supplier = {
      ...supplierData,
      id: `sup-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setSuppliers(prev => [newSup, ...prev]);
    logAudit('Supplier Created', 'Supplier', `Added supplier ${newSup.name}`);
    return newSup;
  };

  const updateSupplier = (id: string, updates: Partial<Supplier>) => {
    setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  // Financial Accounts & Transfers
  const addAccount = (accData: Omit<FinancialAccount, 'id'>): FinancialAccount => {
    const newAcc: FinancialAccount = {
      ...accData,
      id: `acc-${Date.now()}`
    };
    setAccounts(prev => [...prev, newAcc]);
    logAudit('Account Added', 'FinancialAccount', `Created account ${newAcc.name}`);
    return newAcc;
  };

  const transferFunds = (
    fromAccountId: string, 
    toAccountId: string, 
    amount: number, 
    fee: number = 0, 
    description?: string
  ): boolean => {
    if (fromAccountId === toAccountId) {
      alert('Sender and receiver account cannot be the same.');
      return false;
    }

    const fromAcc = accounts.find(a => a.id === fromAccountId);
    const toAcc = accounts.find(a => a.id === toAccountId);

    if (!fromAcc || !toAcc) return false;

    if (fromAcc.balance < amount + fee) {
      alert(`Insufficient funds in ${fromAcc.name}. Available: ${fromAcc.balance}, Required: ${amount + fee}`);
      return false;
    }

    // Double-entry transfer: decreases fromAcc, increases toAcc (P&L neutral!)
    setAccounts(prev => prev.map(acc => {
      if (acc.id === fromAccountId) {
        return { ...acc, balance: acc.balance - (amount + fee) };
      }
      if (acc.id === toAccountId) {
        return { ...acc, balance: acc.balance + amount };
      }
      return acc;
    }));

    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'transfer',
      amount,
      fee,
      fromAccountId,
      toAccountId,
      reference: `TRF-${fromAcc.name.slice(0, 3)}-${toAcc.name.slice(0, 3)}`,
      description: description || `Internal transfer from ${fromAcc.name} to ${toAcc.name}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };

    setTransactions(prev => [tx, ...prev]);
    logAudit('Funds Transferred', 'CashLedger', `Transferred ${amount} from ${fromAcc.name} to ${toAcc.name}`);
    return true;
  };

  const reconcileTransaction = (txId: string) => {
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, isReconciled: !t.isReconciled } : t));
  };

  // Reset & Backup
  const resetToSampleData = () => {
    setUser(INITIAL_USER);
    setSettings(INITIAL_SETTINGS);
    setProducts(INITIAL_PRODUCTS);
    setCustomers(INITIAL_CUSTOMERS);
    setSuppliers(INITIAL_SUPPLIERS);
    setOrders(INITIAL_ORDERS);
    setPurchaseOrders(INITIAL_PURCHASE_ORDERS);
    setExpenses(INITIAL_EXPENSES);
    setAccounts(INITIAL_ACCOUNTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setMovements(INITIAL_MOVEMENTS);
    setAuditLogs([
      {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        user: INITIAL_USER.name,
        action: 'Database Reset',
        entity: 'System',
        details: 'All modules restored to standard verified sample store dataset'
      }
    ]);
  };

  const exportBackupJSON = (): string => {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      settings,
      products,
      customers,
      suppliers,
      orders,
      purchaseOrders,
      expenses,
      accounts,
      transactions,
      movements
    };
    return JSON.stringify(backup, null, 2);
  };

  const importBackupJSON = (jsonData: string): boolean => {
    try {
      const data = JSON.parse(jsonData);
      if (data.settings) setSettings(data.settings);
      if (data.products) setProducts(data.products);
      if (data.customers) setCustomers(data.customers);
      if (data.suppliers) setSuppliers(data.suppliers);
      if (data.orders) setOrders(data.orders);
      if (data.purchaseOrders) setPurchaseOrders(data.purchaseOrders);
      if (data.expenses) setExpenses(data.expenses);
      if (data.accounts) setAccounts(data.accounts);
      if (data.transactions) setTransactions(data.transactions);
      if (data.movements) setMovements(data.movements);
      logAudit('Backup Restored', 'System', 'Data successfully restored from imported JSON backup');
      return true;
    } catch {
      alert('Failed to parse JSON backup file. Please ensure it is valid.');
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        settings,
        products,
        customers,
        suppliers,
        orders,
        purchaseOrders,
        expenses,
        accounts,
        transactions,
        movements,
        auditLogs,
        darkMode,
        toggleDarkMode,
        setUserRole,
        updateSettings,
        addOrder,
        updateOrder,
        updateOrderStatus,
        recordOrderPayment,
        refundOrder,
        addProduct,
        updateProduct,
        archiveProduct,
        bulkImportProducts,
        adjustStock,
        addPurchaseOrder,
        updatePurchaseOrderStatus,
        receivePurchaseOrder,
        recordPOPayment,
        addExpense,
        deleteExpense,
        addCustomer,
        updateCustomer,
        addSupplier,
        updateSupplier,
        addAccount,
        transferFunds,
        reconcileTransaction,
        resetToSampleData,
        exportBackupJSON,
        importBackupJSON
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
