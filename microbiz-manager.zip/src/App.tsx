import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ProfitCalculatorView } from './components/ProfitCalculatorView';
import { OrdersView } from './components/OrdersView';
import { ProductsView } from './components/ProductsView';
import { InventoryView } from './components/InventoryView';
import { ExpensesView } from './components/ExpensesView';
import { CustomersView } from './components/CustomersView';
import { SuppliersView } from './components/SuppliersView';
import { PaymentsView } from './components/PaymentsView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { AuthModal } from './components/auth/AuthModal';
import { SecuritySettingsModal } from './components/auth/SecuritySettingsModal';
import { EmailNoticeToast } from './components/auth/EmailNoticeToast';

const MainLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState(false);
  const { addOrder, products, customers } = useApp();

  const handleQuickAction = (action: 'order' | 'product' | 'expense' | 'calculator') => {
    switch (action) {
      case 'calculator':
        setActiveTab('calculator');
        break;
      case 'order':
        setActiveTab('orders');
        break;
      case 'product':
        setActiveTab('products');
        break;
      case 'expense':
        setActiveTab('expenses');
        break;
    }
  };

  const handleConvertCalculatorToOrder = (calcData: any) => {
    // Finds or creates order based on calculator inputs
    const matchedProduct = products.find(p => p.name.toLowerCase() === calcData.productName?.toLowerCase()) || products[0];
    const customer = customers[0];

    const quantity = calcData.quantity || 1;
    const unitPrice = calcData.sellingPrice || 0;
    const unitCost = calcData.unitCost || 0;
    const discount = calcData.discount || 0;
    const deliveryChargeCollected = calcData.deliveryChargeCollected || 0;
    const actualDeliveryExpense = calcData.actualDeliveryExpense || 0;
    const packagingExpense = calcData.packagingExpense || 0;
    const paymentFee = calcData.paymentFee || 0;
    const subtotal = quantity * unitPrice;
    const totalAmount = Math.max(0, subtotal - discount + deliveryChargeCollected);

    addOrder({
      customerId: customer?.id || 'cust-1',
      customerName: customer?.name || 'Walk-in Customer',
      customerPhone: customer?.phone || '01700-000000',
      customerAddress: customer?.address,
      date: new Date().toISOString(),
      items: [
        {
          productId: matchedProduct?.id || 'prod-custom',
          productName: calcData.productName || matchedProduct?.name || 'Custom Product',
          sku: matchedProduct?.sku || 'SKU-CALC',
          quantity,
          unitCostSnapshot: unitCost,
          unitPrice,
          discount: 0,
          total: subtotal
        }
      ],
      subtotal,
      discount,
      taxAmount: 0,
      deliveryChargeCollected,
      actualDeliveryExpense,
      packagingExpense,
      paymentFee,
      marketplaceCommission: 0,
      adCostAllocated: calcData.adCostAllocated || 0,
      otherExpenses: calcData.otherExpenses || 0,
      totalAmount,
      amountPaid: 0,
      paymentMethod: 'Cash on Delivery',
      paymentStatus: 'unpaid',
      orderStatus: 'confirmed',
      internalNotes: 'Generated from Profit Calculator calculation'
    });

    setActiveTab('orders');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-sans text-slate-800 dark:text-slate-100 transition-colors">
      <Header
        onToggleSidebar={() => setIsSidebarOpenMobile(prev => !prev)}
        onOpenQuickAction={handleQuickAction}
        activeTab={activeTab}
        onNavigate={(tab) => setActiveTab(tab)}
      />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          isOpenMobile={isSidebarOpenMobile}
          onCloseMobile={() => setIsSidebarOpenMobile(false)}
        />

        <main className="flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenQuickAction={handleQuickAction}
            />
          )}

          {activeTab === 'calculator' && (
            <ProfitCalculatorView
              onConvertToOrder={handleConvertCalculatorToOrder}
            />
          )}

          {activeTab === 'orders' && <OrdersView />}

          {activeTab === 'products' && <ProductsView />}

          {activeTab === 'inventory' && <InventoryView />}

          {activeTab === 'expenses' && <ExpensesView />}

          {activeTab === 'customers' && <CustomersView />}

          {activeTab === 'suppliers' && <SuppliersView />}

          {activeTab === 'payments' && <PaymentsView />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <NotificationProvider>
          <MainLayout />
          <AuthModal />
          <SecuritySettingsModal />
          <EmailNoticeToast />
        </NotificationProvider>
      </AppProvider>
    </AuthProvider>
  );
}
