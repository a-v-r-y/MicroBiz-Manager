import React, { useState } from 'react';
import { 
  Boxes, 
  Search, 
  Plus, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RotateCcw, 
  Filter, 
  SlidersHorizontal, 
  X, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Info, 
  ArrowRight, 
  TrendingUp, 
  BarChart2, 
  Eye,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MovementType, Product, InventoryValuationMethod } from '../types';
import { 
  formatCurrency, 
  calculateInventoryValuationSummary, 
  ProductCostingDetail, 
  calculateProductInventoryCosting 
} from '../utils/calculations';

export const InventoryView: React.FC = () => {
  const { products, movements, settings, updateSettings, adjustStock, user } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [activeViewMode, setActiveViewMode] = useState<'movements' | 'costing'>('movements');
  const [inspectProduct, setInspectProduct] = useState<ProductCostingDetail | null>(null);

  // Selected method for preview/filtering (defaults to system settings)
  const [selectedMethod, setSelectedMethod] = useState<InventoryValuationMethod>(
    settings.inventoryValuationMethod || 'FIFO'
  );

  // Adjustment Form State
  const [adjustProductId, setAdjustProductId] = useState(products[0]?.id || '');
  const [adjustType, setAdjustType] = useState<MovementType>('manual_adjustment');
  const [adjustQuantityChange, setAdjustQuantityChange] = useState(0);
  const [adjustNotes, setAdjustNotes] = useState('');

  // Comprehensive Inventory Valuation under FIFO, LIFO, and WAC
  const valuationSummary = calculateInventoryValuationSummary(products, movements, selectedMethod);
  const totalStockUnits = valuationSummary.totalStockUnits;
  const lowStockCount = products.filter(p => p.stock <= p.minStockAlert && p.stock > 0 && p.status !== 'archived').length;
  const outOfStockCount = products.filter(p => p.stock <= 0 && p.status !== 'archived').length;

  const filteredMovements = movements.filter(m => {
    const matchesSearch = 
      m.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.referenceId && m.referenceId.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (m.notes && m.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = selectedType === 'all' || m.type === selectedType;
    return matchesSearch && matchesType;
  });

  const filteredCostings = valuationSummary.productCostings.filter(c => {
    return c.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           c.sku.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustProductId || adjustQuantityChange === 0) {
      alert('Please select a product and enter a non-zero quantity change.');
      return;
    }

    const success = adjustStock(adjustProductId, adjustQuantityChange, adjustType, adjustNotes);
    if (success) {
      setIsAdjustModalOpen(false);
      setAdjustQuantityChange(0);
      setAdjustNotes('');
    }
  };

  const handleSetDefaultMethod = (method: InventoryValuationMethod) => {
    setSelectedMethod(method);
    updateSettings({ inventoryValuationMethod: method });
  };

  const getMovementBadge = (type: MovementType) => {
    switch (type) {
      case 'purchase_receipt':
        return { label: 'Purchase Receipt', bg: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' };
      case 'sale':
        return { label: 'Customer Sale', bg: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400' };
      case 'customer_return':
        return { label: 'Customer Return', bg: 'bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-400' };
      case 'supplier_return':
        return { label: 'Supplier Return', bg: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400' };
      case 'damaged':
        return { label: 'Damaged Goods', bg: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400' };
      case 'lost':
        return { label: 'Lost / Discrepancy', bg: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400' };
      case 'initial':
        return { label: 'Initial Stock', bg: 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400' };
      case 'manual_adjustment':
      default:
        return { label: 'Manual Adjustment', bg: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' };
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Inventory & Valuation Ledger
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
              {selectedMethod} Active
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Audit-grade inventory tracking supporting FIFO (First-In, First-Out), LIFO (Last-In, First-Out), and Weighted Average Cost.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsAdjustModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Adjust Stock Balance
          </button>
        </div>
      </div>

      {/* Valuation Method Quick Switcher */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-600" />
              Inventory Costing & Valuation Method
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              Select valuation method to recalculate balance sheet inventory assets and inspect batch cost layers.
            </p>
          </div>

          <div className="inline-flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold self-start sm:self-auto">
            <button
              onClick={() => handleSetDefaultMethod('FIFO')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                selectedMethod === 'FIFO'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <span>FIFO (First In, First Out)</span>
            </button>
            <button
              onClick={() => handleSetDefaultMethod('LIFO')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                selectedMethod === 'LIFO'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <span>LIFO (Last In, First Out)</span>
            </button>
            <button
              onClick={() => handleSetDefaultMethod('WAC')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                selectedMethod === 'WAC'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <span>WAC (Average Cost)</span>
            </button>
          </div>
        </div>

        {/* Informative Explanation Banner */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 text-[11px] flex items-start gap-2 text-slate-600 dark:text-slate-300">
          <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 leading-relaxed">
            {selectedMethod === 'FIFO' && (
              <span>
                <strong>FIFO Method Active:</strong> Earliest acquired goods are considered sold first. Ending warehouse inventory of <strong>{totalStockUnits} units</strong> is valued at the latest purchase batch costs (<strong>{formatCurrency(valuationSummary.fifoTotalValuation, settings.currency)}</strong>).
              </span>
            )}
            {selectedMethod === 'LIFO' && (
              <span>
                <strong>LIFO Method Active:</strong> Most recently acquired goods are considered sold first. Ending warehouse inventory of <strong>{totalStockUnits} units</strong> retains the earliest base acquisition costs (<strong>{formatCurrency(valuationSummary.lifoTotalValuation, settings.currency)}</strong>).
              </span>
            )}
            {selectedMethod === 'WAC' && (
              <span>
                <strong>WAC Method Active:</strong> Warehouse ending inventory of <strong>{totalStockUnits} units</strong> is valued using the blended weighted average cost per unit (<strong>{formatCurrency(valuationSummary.wacTotalValuation, settings.currency)}</strong>).
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">
            {selectedMethod} Total Valuation
          </span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(valuationSummary.activeMethodTotalValuation, settings.currency)}
          </div>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
            Active Accounting Valuation
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">
            LIFO Reserve (FIFO - LIFO)
          </span>
          <div className="text-xl font-bold font-mono-numbers text-blue-600 dark:text-blue-400">
            {formatCurrency(valuationSummary.lifoReserve, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">
            Valuation variance across methods
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Stock in Hand</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {totalStockUnits} units
          </div>
          <span className="text-[10px] text-slate-400">Across {products.length} catalog items</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Stock Status Warnings</span>
          <div className="flex items-center gap-3">
            <div>
              <span className="text-xl font-bold font-mono-numbers text-amber-600">{lowStockCount}</span>
              <span className="text-[10px] text-slate-400 block">Low</span>
            </div>
            <div className="w-px h-6 bg-slate-200 dark:bg-slate-700"></div>
            <div>
              <span className="text-xl font-bold font-mono-numbers text-rose-600">{outOfStockCount}</span>
              <span className="text-[10px] text-slate-400 block">Out of stock</span>
            </div>
          </div>
        </div>
      </div>

      {/* View Switcher: Movements Ledger vs FIFO/LIFO Costing Matrix */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveViewMode('movements')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              activeViewMode === 'movements'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Stock Movements Ledger ({filteredMovements.length})
          </button>

          <button
            onClick={() => setActiveViewMode('costing')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              activeViewMode === 'costing'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            FIFO vs LIFO Cost Layers Matrix
          </button>
        </div>

        <div className="text-xs text-slate-400 hidden sm:block">
          {activeViewMode === 'costing' ? 'Side-by-side inventory costing by batch' : 'Audit-grade physical movements'}
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder={activeViewMode === 'movements' 
                ? "Search movements by Product Name, Ref ID (Order/PO), or Notes..." 
                : "Search products by Name or SKU..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {activeViewMode === 'movements' ? (
            <div className="sm:col-span-4">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="all">All Movement Types</option>
                <option value="purchase_receipt">Purchase Receipts (Stock In)</option>
                <option value="sale">Customer Sales (Stock Out)</option>
                <option value="customer_return">Customer Returns</option>
                <option value="damaged">Damaged Goods</option>
                <option value="lost">Lost / Discrepancy</option>
                <option value="manual_adjustment">Manual Adjustment</option>
                <option value="initial">Initial Stock</option>
              </select>
            </div>
          ) : (
            <div className="sm:col-span-4 flex items-center justify-end">
              <span className="text-xs text-slate-500">
                Comparing {filteredCostings.length} active catalog products
              </span>
            </div>
          )}
        </div>
      </div>

      {/* VIEW 1: Movements Table */}
      {activeViewMode === 'movements' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <tr>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Product Name</th>
                  <th className="py-3 px-4">Movement Type</th>
                  <th className="py-3 px-4 text-center">Change Qty</th>
                  <th className="py-3 px-4 text-center">Balance After</th>
                  <th className="py-3 px-4 text-right">Unit Cost</th>
                  <th className="py-3 px-4">Reference</th>
                  <th className="py-3 px-4">Logged By / Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredMovements.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      No movements matching filter.
                    </td>
                  </tr>
                ) : (
                  filteredMovements.map((mov) => {
                    const badge = getMovementBadge(mov.type);
                    const isPositive = mov.quantity > 0;

                    return (
                      <tr key={mov.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                        <td className="py-3 px-4 text-slate-500 font-mono-numbers">
                          {new Date(mov.date).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </td>

                        <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                          {mov.productName}
                        </td>

                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${badge.bg}`}>
                            {badge.label}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-center font-bold font-mono-numbers">
                          <span className={isPositive ? 'text-emerald-600' : 'text-rose-600'}>
                            {isPositive ? `+${mov.quantity}` : mov.quantity}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-center font-bold font-mono-numbers text-slate-800 dark:text-slate-200">
                          {mov.balanceAfter}
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers text-slate-600 dark:text-slate-400">
                          {formatCurrency(mov.unitCost, settings.currency)}
                        </td>

                        <td className="py-3 px-4 font-mono-numbers text-slate-600 dark:text-slate-400">
                          {mov.referenceId || '-'}
                        </td>

                        <td className="py-3 px-4 text-slate-500">
                          <div className="truncate max-w-xs">{mov.notes || '-'}</div>
                          <div className="text-[10px] text-slate-400">By {mov.createdBy}</div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW 2: FIFO vs LIFO Cost Layers Matrix */}
      {activeViewMode === 'costing' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Product & SKU</th>
                    <th className="py-3 px-4 text-center">Stock on Hand</th>
                    <th className="py-3 px-4 text-right">FIFO Valuation</th>
                    <th className="py-3 px-4 text-right">LIFO Valuation</th>
                    <th className="py-3 px-4 text-right">WAC Valuation</th>
                    <th className="py-3 px-4 text-right">LIFO Reserve</th>
                    <th className="py-3 px-4 text-center">Batches</th>
                    <th className="py-3 px-4 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCostings.map((costing) => {
                    const hasReserve = costing.lifoReserve !== 0;
                    return (
                      <tr key={costing.productId} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white">
                            {costing.productName}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono-numbers">
                            {costing.sku} • Base Cost: {formatCurrency(costing.costPrice, settings.currency)}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-center font-bold font-mono-numbers text-slate-900 dark:text-white">
                          {costing.currentStock} units
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers">
                          <div className="font-bold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(costing.fifoValuation, settings.currency)}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Avg: {formatCurrency(costing.fifoUnitCost, settings.currency)}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers">
                          <div className="font-bold text-blue-600 dark:text-blue-400">
                            {formatCurrency(costing.lifoValuation, settings.currency)}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Avg: {formatCurrency(costing.lifoUnitCost, settings.currency)}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers">
                          <div className="font-bold text-purple-600 dark:text-purple-400">
                            {formatCurrency(costing.wacValuation, settings.currency)}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Avg: {formatCurrency(costing.wacUnitCost, settings.currency)}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers">
                          <span className={`px-2 py-0.5 rounded-md font-bold text-xs ${
                            hasReserve 
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400 border border-amber-200 dark:border-amber-800' 
                              : 'text-slate-400'
                          }`}>
                            {hasReserve ? formatCurrency(costing.lifoReserve, settings.currency) : '৳0.00'}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-center text-slate-500 font-mono-numbers">
                          {costing.batches.length} inbound
                        </td>

                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => setInspectProduct(costing)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Inspect Layers
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Product Batch & Layers Inspection Modal */}
      {inspectProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                  <Layers className="w-5 h-5 text-emerald-600" />
                  Costing Layers: {inspectProduct.productName}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  SKU: {inspectProduct.sku} • Stock on Hand: {inspectProduct.currentStock} units
                </p>
              </div>
              <button 
                onClick={() => setInspectProduct(null)} 
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Comparison Bar */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs">
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold block">
                  FIFO Ending Valuation
                </span>
                <div className="text-base font-bold font-mono-numbers text-emerald-800 dark:text-emerald-300">
                  {formatCurrency(inspectProduct.fifoValuation, settings.currency)}
                </div>
                <span className="text-[10px] text-emerald-600">
                  Avg: {formatCurrency(inspectProduct.fifoUnitCost, settings.currency)}/unit
                </span>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs">
                <span className="text-[10px] text-blue-700 dark:text-blue-400 font-bold block">
                  LIFO Ending Valuation
                </span>
                <div className="text-base font-bold font-mono-numbers text-blue-800 dark:text-blue-300">
                  {formatCurrency(inspectProduct.lifoValuation, settings.currency)}
                </div>
                <span className="text-[10px] text-blue-600">
                  Avg: {formatCurrency(inspectProduct.lifoUnitCost, settings.currency)}/unit
                </span>
              </div>

              <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 text-xs">
                <span className="text-[10px] text-purple-700 dark:text-purple-400 font-bold block">
                  LIFO Reserve (Variance)
                </span>
                <div className="text-base font-bold font-mono-numbers text-purple-800 dark:text-purple-300">
                  {formatCurrency(inspectProduct.lifoReserve, settings.currency)}
                </div>
                <span className="text-[10px] text-purple-600">
                  FIFO - LIFO gap
                </span>
              </div>
            </div>

            {/* Inbound Batches History */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Inbound Purchase Batches (Chronological)
              </h4>
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold">
                    <tr>
                      <th className="py-2 px-3">Date</th>
                      <th className="py-2 px-3">Batch / PO Ref</th>
                      <th className="py-2 px-3 text-center">Batch Qty</th>
                      <th className="py-2 px-3 text-right">Unit Cost</th>
                      <th className="py-2 px-3 text-right">Total Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {inspectProduct.batches.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="py-2 px-3 font-mono-numbers text-slate-500">
                          {new Date(b.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                        </td>
                        <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200">
                          {b.source}
                        </td>
                        <td className="py-2 px-3 text-center font-mono-numbers font-bold">
                          {b.quantity}
                        </td>
                        <td className="py-2 px-3 text-right font-mono-numbers">
                          {formatCurrency(b.unitCost, settings.currency)}
                        </td>
                        <td className="py-2 px-3 text-right font-mono-numbers font-bold">
                          {formatCurrency(b.totalCost, settings.currency)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* FIFO vs LIFO Layer Depletion Comparison */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-bold text-emerald-700 dark:text-emerald-400 flex items-center justify-between">
                  <span>FIFO Ending Stock Layers</span>
                  <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/40 px-1.5 py-0.5 rounded">Newest Batches</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Under FIFO, the {inspectProduct.currentStock} units in your warehouse come from the most recent receipts:
                </p>
                <div className="space-y-1.5 pt-1">
                  {inspectProduct.fifoEndingBatches.map((layer, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[11px] font-mono-numbers bg-white dark:bg-slate-800 p-1.5 rounded-lg border border-slate-100 dark:border-slate-700">
                      <span>{layer.quantity} units @ {formatCurrency(layer.unitCost, settings.currency)}</span>
                      <span className="font-bold text-emerald-600">{formatCurrency(layer.totalCost, settings.currency)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="font-bold text-blue-700 dark:text-blue-400 flex items-center justify-between">
                  <span>LIFO Ending Stock Layers</span>
                  <span className="text-[10px] bg-blue-100 dark:bg-blue-900/40 px-1.5 py-0.5 rounded">Oldest Base Layers</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Under LIFO, the {inspectProduct.currentStock} units in your warehouse retain early baseline receipt costs:
                </p>
                <div className="space-y-1.5 pt-1">
                  {inspectProduct.lifoEndingBatches.map((layer, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[11px] font-mono-numbers bg-white dark:bg-slate-800 p-1.5 rounded-lg border border-slate-100 dark:border-slate-700">
                      <span>{layer.quantity} units @ {formatCurrency(layer.unitCost, settings.currency)}</span>
                      <span className="font-bold text-blue-600">{formatCurrency(layer.totalCost, settings.currency)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setInspectProduct(null)}
                className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold rounded-xl cursor-pointer"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Stock Adjustment Modal */}
      {isAdjustModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Manual Stock Adjustment
              </h3>
              <button onClick={() => setIsAdjustModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAdjustSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Select Product *</label>
                <select
                  value={adjustProductId}
                  onChange={(e) => setAdjustProductId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current Stock: {p.stock})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Adjustment Reason / Type *</label>
                <select
                  value={adjustType}
                  onChange={(e) => setAdjustType(e.target.value as MovementType)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="manual_adjustment">Physical Count Audit Adjustment</option>
                  <option value="damaged">Damaged Goods (Defective / Transit Breakage)</option>
                  <option value="lost">Lost / Misplaced Items</option>
                  <option value="customer_return">Customer Restocking Return</option>
                  <option value="supplier_return">Return to Supplier</option>
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">
                  Quantity Change (+ to add, - to subtract) *
                </label>
                <input
                  type="number"
                  required
                  value={adjustQuantityChange || ''}
                  onChange={(e) => setAdjustQuantityChange(parseInt(e.target.value) || 0)}
                  placeholder="e.g. -2 for damage, or +5 for restock"
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Negative stock is {settings.allowNegativeStock ? 'permitted' : 'blocked'} in settings.
                </span>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Audit Notes & Explanation</label>
                <textarea
                  rows={2}
                  value={adjustNotes}
                  onChange={(e) => setAdjustNotes(e.target.value)}
                  placeholder="e.g. Monthly stock count discrepancy or box crushed during delivery."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(false)}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Record Movement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
