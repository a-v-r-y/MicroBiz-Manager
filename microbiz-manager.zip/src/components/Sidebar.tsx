import React from 'react';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Calculator, 
  Package, 
  Boxes, 
  Receipt, 
  Users, 
  Truck, 
  WalletCards, 
  BarChart3, 
  Settings,
  X,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export type NavTab = 
  | 'dashboard'
  | 'orders'
  | 'calculator'
  | 'products'
  | 'inventory'
  | 'expenses'
  | 'customers'
  | 'suppliers'
  | 'payments'
  | 'reports'
  | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile
}) => {
  const { orders, products, user } = useApp();

  const pendingOrders = orders.filter(o => o.orderStatus === 'pending').length;
  const lowStockItems = products.filter(p => p.stock <= p.minStockAlert && p.status !== 'archived').length;

  // Role permissions check for navigation
  const isSalesOnly = user.role === 'sales';
  const isInventoryOnly = user.role === 'inventory';

  const navItems: Array<{
    id: NavTab;
    label: string;
    icon: React.ElementType;
    badge?: number;
    badgeColor?: string;
    highlight?: boolean;
    hidden?: boolean;
  }> = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      hidden: false
    },
    {
      id: 'calculator',
      label: 'Profit Calculator',
      icon: Calculator,
      highlight: true
    },
    {
      id: 'orders',
      label: 'Orders',
      icon: ShoppingCart,
      badge: pendingOrders > 0 ? pendingOrders : undefined,
      badgeColor: 'bg-amber-500'
    },
    {
      id: 'products',
      label: 'Products',
      icon: Package
    },
    {
      id: 'inventory',
      label: 'Inventory',
      icon: Boxes,
      badge: lowStockItems > 0 ? lowStockItems : undefined,
      badgeColor: 'bg-rose-500',
      hidden: isSalesOnly
    },
    {
      id: 'expenses',
      label: 'Expenses',
      icon: Receipt,
      hidden: isSalesOnly || isInventoryOnly
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
      hidden: isInventoryOnly
    },
    {
      id: 'suppliers',
      label: 'Suppliers & POs',
      icon: Truck,
      hidden: isSalesOnly
    },
    {
      id: 'payments',
      label: 'Payments & Cash',
      icon: WalletCards,
      hidden: isSalesOnly || isInventoryOnly
    },
    {
      id: 'reports',
      label: 'Reports & Testing',
      icon: BarChart3,
      hidden: isSalesOnly || isInventoryOnly
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      hidden: isSalesOnly || isInventoryOnly
    }
  ];

  const handleSelect = (tab: NavTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed md:sticky top-0 md:top-[57px] left-0 h-full md:h-[calc(100vh-57px)] w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-50 md:z-10 flex flex-col transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Mobile Header in Drawer */}
        <div className="flex md:hidden items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <span className="font-bold text-slate-900 dark:text-white">MicroBiz Manager</span>
          </div>
          <button 
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 dark:text-slate-500 uppercase">
            Management
          </div>

          {navItems.filter(item => !item.hidden).map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all group cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-white font-semibold shadow-xs dark:bg-emerald-600'
                    : item.highlight
                    ? 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 bg-indigo-50/50 dark:bg-indigo-950/20'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4.5 h-4.5 transition-colors ${
                    isActive 
                      ? 'text-white' 
                      : item.highlight 
                      ? 'text-indigo-600 dark:text-indigo-400' 
                      : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200'
                  }`} />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold text-white ${item.badgeColor || 'bg-slate-500'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom User / Quick Info Pill */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 shadow-2xs">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-xs">
              {user.avatar || 'OP'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{user.name}</p>
              <p className="text-[10px] text-slate-400 capitalize">{user.role} role</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
