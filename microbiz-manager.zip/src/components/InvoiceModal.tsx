import React from 'react';
import { X, Printer, Download, CheckCircle, Clock, ArrowLeft } from 'lucide-react';
import { Order } from '../types';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../utils/calculations';

interface InvoiceModalProps {
  order: Order | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, onClose }) => {
  const { settings } = useApp();

  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const balanceDue = Math.max(0, order.totalAmount - (order.amountPaid || 0));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8">
        {/* Modal Controls Bar (hidden during printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            {/* Backward / Return Button */}
            <button
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition cursor-pointer group shadow-2xs"
              title="Return / Go back"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
              <span>Back / Return</span>
            </button>

            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900 dark:text-white text-sm">
                Official Invoice: {order.orderNumber}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                order.paymentStatus === 'paid' 
                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' 
                  : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
              }`}>
                {order.paymentStatus.toUpperCase()}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              title="Close invoice view"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document Body */}
        <div className="p-8 sm:p-12 text-slate-900 dark:text-white bg-white dark:bg-slate-900 space-y-8">
          {/* Header & Logo */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xl">
                  {settings.businessName.charAt(0) || 'M'}
                </div>
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                    {settings.businessName}
                  </h2>
                  <p className="text-xs text-slate-500">{settings.businessCategory}</p>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-2 max-w-sm">
                {settings.address} <br />
                Email: {settings.contactEmail} | Tel: {settings.contactPhone}
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                INVOICE
              </span>
              <h3 className="text-xl font-extrabold font-mono-numbers text-slate-900 dark:text-white">
                {order.orderNumber}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Date: {new Date(order.date).toLocaleDateString()}
              </p>
              {order.trackingNumber && (
                <p className="text-xs text-slate-500 font-mono-numbers">
                  Tracking: {order.trackingNumber} ({order.carrier})
                </p>
              )}
            </div>
          </div>

          {/* Bill To & Fulfillment Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Billed & Shipped To:
              </span>
              <p className="font-bold text-sm text-slate-900 dark:text-white">{order.customerName}</p>
              <p className="text-slate-600 dark:text-slate-400 mt-0.5">Phone: {order.customerPhone}</p>
              {order.customerAddress && (
                <p className="text-slate-600 dark:text-slate-400 mt-0.5 whitespace-pre-line">
                  {order.customerAddress}
                </p>
              )}
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Payment Details:
              </span>
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Method: {order.paymentMethod || 'Cash on Delivery'}
              </p>
              <p className="text-slate-600 dark:text-slate-400 mt-0.5">
                Payment Status: <span className="font-bold capitalize">{order.paymentStatus}</span>
              </p>
              <p className="text-slate-600 dark:text-slate-400 mt-0.5">
                Fulfillment Status: <span className="font-bold capitalize">{order.orderStatus}</span>
              </p>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <tr>
                  <th className="py-2.5 px-3">Item Description</th>
                  <th className="py-2.5 px-3 text-center">SKU</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3 text-right">Price</th>
                  <th className="py-2.5 px-3 text-right">Discount</th>
                  <th className="py-2.5 px-3 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono-numbers">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-medium font-sans text-slate-900 dark:text-white">
                      {item.productName}
                    </td>
                    <td className="py-3 px-3 text-center text-slate-400">{item.sku}</td>
                    <td className="py-3 px-3 text-center">{item.quantity}</td>
                    <td className="py-3 px-3 text-right">{formatCurrency(item.unitPrice, settings.currency)}</td>
                    <td className="py-3 px-3 text-right text-rose-500">
                      {item.discount ? `-${formatCurrency(item.discount, settings.currency)}` : '-'}
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-slate-900 dark:text-white">
                      {formatCurrency(item.total, settings.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Breakdown */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pt-2">
            <div className="sm:max-w-xs space-y-2 text-xs text-slate-500">
              <p className="font-semibold text-slate-700 dark:text-slate-300">Terms & Notes:</p>
              <p className="leading-relaxed">{settings.invoiceNotes || 'Thank you for your business!'}</p>
              {order.internalNotes && (
                <div className="p-2 rounded bg-amber-50/50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 text-[11px]">
                  <strong>Order Note:</strong> {order.internalNotes}
                </div>
              )}
            </div>

            <div className="w-full sm:w-64 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Subtotal:</span>
                <span className="font-mono-numbers">{formatCurrency(order.subtotal, settings.currency)}</span>
              </div>

              {order.discount > 0 && (
                <div className="flex justify-between text-rose-600 dark:text-rose-400">
                  <span>Order Promo Discount:</span>
                  <span className="font-mono-numbers">-{formatCurrency(order.discount, settings.currency)}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Delivery Charge:</span>
                <span className="font-mono-numbers">+{formatCurrency(order.deliveryChargeCollected, settings.currency)}</span>
              </div>

              {order.taxAmount > 0 && (
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>VAT / Tax:</span>
                  <span className="font-mono-numbers">+{formatCurrency(order.taxAmount, settings.currency)}</span>
                </div>
              )}

              <div className="flex justify-between py-2 border-t border-b border-slate-200 dark:border-slate-800 font-bold text-base text-slate-900 dark:text-white">
                <span>Total Payable:</span>
                <span className="font-mono-numbers text-emerald-600 dark:text-emerald-400">
                  {formatCurrency(order.totalAmount, settings.currency)}
                </span>
              </div>

              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Amount Paid:</span>
                <span className="font-mono-numbers">{formatCurrency(order.amountPaid || 0, settings.currency)}</span>
              </div>

              {balanceDue > 0 && (
                <div className="flex justify-between font-bold text-rose-600">
                  <span>Balance Due:</span>
                  <span className="font-mono-numbers">{formatCurrency(balanceDue, settings.currency)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Return Bar (hidden during printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <button
            onClick={onClose}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer group shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
            <span>← Return to Order Summary</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
