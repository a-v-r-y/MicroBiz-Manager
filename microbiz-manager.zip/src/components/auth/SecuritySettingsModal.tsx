import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Key, 
  Smartphone, 
  Laptop, 
  Lock, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Check, 
  LogOut, 
  RefreshCw, 
  Mail, 
  User, 
  Clock,
  Sparkles,
  QrCode
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { calculateTotpCode } from '../../utils/cryptoAuth';

export const SecuritySettingsModal: React.FC = () => {
  const {
    isSecuritySettingsOpen,
    closeSecuritySettings,
    currentUser,
    currentSession,
    allSessions,
    logoutOtherSessions,
    revokeSession,
    start2FASetup,
    confirmEnable2FA,
    disable2FA,
    changePassword,
    deleteAccount,
    sendVerificationEmail,
    openAuthModal,
    updateProfile
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'profile' | '2fa' | 'sessions' | 'password' | 'danger'>('profile');

  // 2FA Setup State
  const [setup2FAData, setSetup2FAData] = useState<{ secret: string; otpauthUri: string; backupCodes: string[] } | null>(null);
  const [candidate2FACode, setCandidate2FACode] = useState('');
  const [disable2FAPassword, setDisable2FAPassword] = useState('');
  const [copiedSecret, setCopiedSecret] = useState(false);
  const [copiedCodes, setCopiedCodes] = useState(false);
  const [liveTestCode, setLiveTestCode] = useState('');
  const [secondsRemaining, setSecondsRemaining] = useState(30);

  // Password Change State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Account Deletion State
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteConfirmationText, setDeleteConfirmationText] = useState('');

  // Status feedback
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Clear messages when tab changes
  useEffect(() => {
    setErrorMessage('');
    setSuccessMessage('');
  }, [activeTab]);

  // Compute live TOTP helper when setting up 2FA
  useEffect(() => {
    if (setup2FAData?.secret) {
      const updateCode = async () => {
        try {
          const gen = await calculateTotpCode(setup2FAData.secret);
          setLiveTestCode(gen);
          const epoch = Math.floor(Date.now() / 1000);
          setSecondsRemaining(30 - (epoch % 30));
        } catch (e) {
          console.error(e);
        }
      };
      updateCode();
      const interval = setInterval(updateCode, 1000);
      return () => clearInterval(interval);
    }
  }, [setup2FAData]);

  if (!isSecuritySettingsOpen || !currentUser) return null;

  // 1. Handle Start 2FA Setup
  const handleBegin2FASetup = () => {
    const data = start2FASetup();
    setSetup2FAData(data);
    setCandidate2FACode('');
    setErrorMessage('');
  };

  // 2. Confirm Enable 2FA
  const handleConfirmEnable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!setup2FAData) return;
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await confirmEnable2FA(setup2FAData.secret, candidate2FACode, setup2FAData.backupCodes);
      if (res.success) {
        setSuccessMessage('Two-Factor Authentication activated successfully!');
        setSetup2FAData(null);
      } else {
        setErrorMessage(res.error || 'Failed to verify code.');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Error enabling 2FA');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Disable 2FA
  const handleDisable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await disable2FA(disable2FAPassword);
      if (res.success) {
        setSuccessMessage('Two-Factor Authentication has been disabled.');
        setDisable2FAPassword('');
      } else {
        setErrorMessage(res.error || 'Failed to disable 2FA.');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Error disabling 2FA');
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Handle Password Change
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      setErrorMessage('New passwords do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setErrorMessage('New password must be at least 8 characters long.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await changePassword(currentPassword, newPassword);
      if (res.success) {
        setSuccessMessage('Password changed successfully! All other sessions terminated.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
      } else {
        setErrorMessage(res.error || 'Failed to change password.');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Error changing password');
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Handle Account Deletion
  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (deleteConfirmationText !== 'DELETE') {
      setErrorMessage('Please type DELETE to confirm account removal.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await deleteAccount(deletePassword);
      if (!res.success) {
        setErrorMessage(res.error || 'Account deletion failed.');
      }
    } catch (e: any) {
      setErrorMessage(e.message || 'Error deleting account');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopySecret = () => {
    if (setup2FAData?.secret) {
      navigator.clipboard.writeText(setup2FAData.secret);
      setCopiedSecret(true);
      setTimeout(() => setCopiedSecret(false), 2000);
    }
  };

  const handleCopyBackupCodes = () => {
    if (setup2FAData?.backupCodes) {
      navigator.clipboard.writeText(setup2FAData.backupCodes.join('\n'));
      setCopiedCodes(true);
      setTimeout(() => setCopiedCodes(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 pb-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-linear-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xs font-bold text-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Security & Account Settings
              </h3>
              <p className="text-xs text-slate-500">
                Manage your credentials, two-factor authentication, active sessions, and access control
              </p>
            </div>
          </div>

          <button
            onClick={closeSecuritySettings}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 shrink-0 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-3 border-b-2 transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'profile'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Account Overview
          </button>

          <button
            onClick={() => setActiveTab('2fa')}
            className={`py-3 px-3 border-b-2 transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === '2fa'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Two-Factor Auth (2FA)
            {currentUser.twoFactorEnabled && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('sessions')}
            className={`py-3 px-3 border-b-2 transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'sessions'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            Active Sessions ({allSessions.length})
          </button>

          <button
            onClick={() => setActiveTab('password')}
            className={`py-3 px-3 border-b-2 transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'password'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            Change Password
          </button>

          <button
            onClick={() => setActiveTab('danger')}
            className={`py-3 px-3 border-b-2 transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'danger'
                ? 'border-rose-600 text-rose-600 dark:text-rose-400'
                : 'border-transparent text-slate-500 hover:text-rose-600'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete Account
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* Status Banners */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* TAB 1: PROFILE & VERIFICATION */}
          {activeTab === 'profile' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-linear-to-tr from-emerald-600 to-teal-500 text-white font-bold flex items-center justify-center text-lg">
                    {currentUser.avatar || currentUser.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      {currentUser.name}
                    </h4>
                    <p className="text-slate-500 text-xs">{currentUser.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 capitalize">
                        Role: {currentUser.role}
                      </span>

                      {currentUser.isEmailVerified ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          <CheckCircle2 className="w-3 h-3" />
                          Email Verified
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                          <AlertTriangle className="w-3 h-3" />
                          Unverified Email
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {!currentUser.isEmailVerified && (
                  <button
                    onClick={() => {
                      sendVerificationEmail();
                      openAuthModal('verify_email');
                    }}
                    className="px-3 py-1.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
                  >
                    Verify Email Now
                  </button>
                )}
              </div>

              {/* Security Status Checklist */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                  Security Defense Posture
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-semibold block text-slate-800 dark:text-slate-200">PBKDF2 Password Hashing</span>
                      <span className="text-[10px] text-slate-400">100,000 SHA-256 iterations with unique salt</span>
                    </div>
                    <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                      Active
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-semibold block text-slate-800 dark:text-slate-200">Two-Factor Auth (TOTP)</span>
                      <span className="text-[10px] text-slate-400">RFC 6238 time-based authenticator codes</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                      currentUser.twoFactorEnabled 
                        ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300' 
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                    }`}>
                      {currentUser.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TWO-FACTOR AUTHENTICATION */}
          {activeTab === '2fa' && (
            <div className="space-y-4">
              {currentUser.twoFactorEnabled ? (
                /* 2FA Active View */
                <div className="p-5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-emerald-900 dark:text-emerald-200">
                        Two-Factor Authentication is Active
                      </h4>
                      <p className="text-emerald-700 dark:text-emerald-300 text-xs">
                        Your account requires a 6-digit verification code from your authenticator app on every new login.
                      </p>
                    </div>
                  </div>

                  {currentUser.twoFactorBackupCodes && currentUser.twoFactorBackupCodes.length > 0 && (
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-emerald-800/60 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 dark:text-white">
                          Emergency Backup Codes ({currentUser.twoFactorBackupCodes.length} remaining)
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(currentUser.twoFactorBackupCodes!.join('\n'));
                            setCopiedCodes(true);
                            setTimeout(() => setCopiedCodes(false), 2000);
                          }}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 cursor-pointer"
                        >
                          {copiedCodes ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          Copy Codes
                        </button>
                      </div>
                      <div className="grid grid-cols-4 gap-2 font-mono-numbers text-center text-xs">
                        {currentUser.twoFactorBackupCodes.map((code, idx) => (
                          <div key={idx} className="p-1 rounded bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold">
                            {code}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Disable 2FA Form */}
                  <form onSubmit={handleDisable2FA} className="pt-2 border-t border-emerald-200 dark:border-emerald-800 space-y-2">
                    <span className="font-bold text-slate-900 dark:text-white block">Disable Two-Factor Authentication</span>
                    <p className="text-slate-500 text-[11px]">
                      Enter your current password to turn off 2FA protection.
                    </p>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        required
                        value={disable2FAPassword}
                        onChange={(e) => setDisable2FAPassword(e.target.value)}
                        placeholder="Current password"
                        className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                      />
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="px-4 py-2 rounded-xl font-bold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer disabled:opacity-50"
                      >
                        Disable 2FA
                      </button>
                    </div>
                  </form>
                </div>
              ) : setup2FAData ? (
                /* 2FA Setup Flow */
                <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      Step 1: Link your Authenticator App
                    </h4>
                    <span className="text-[11px] text-slate-400">Google Authenticator / Authy / 1Password</span>
                  </div>

                  {/* Secret Key Display */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                    <span className="text-slate-500 block text-[11px]">Manual Secret Key (Base32):</span>
                    <div className="flex items-center justify-between gap-2">
                      <code className="font-mono-numbers text-sm font-bold tracking-widest text-emerald-600 dark:text-emerald-400 select-all">
                        {setup2FAData.secret}
                      </code>
                      <button
                        onClick={handleCopySecret}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                      >
                        {copiedSecret ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        Copy Secret
                      </button>
                    </div>
                  </div>

                  {/* Backup Codes */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 dark:text-white text-xs">
                        Step 2: Save Emergency Recovery Codes
                      </span>
                      <button
                        onClick={handleCopyBackupCodes}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 cursor-pointer"
                      >
                        {copiedCodes ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        Copy All Codes
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Store these 8 one-time backup codes safely in case you lose access to your authenticator phone.
                    </p>
                    <div className="grid grid-cols-4 gap-2 font-mono-numbers text-center text-xs">
                      {setup2FAData.backupCodes.map((c, i) => (
                        <div key={i} className="p-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold">
                          {c}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Live Testing Helper */}
                  {liveTestCode && (
                    <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs flex items-center justify-between">
                      <div>
                        <span className="text-emerald-700 dark:text-emerald-300 font-semibold block">
                          Testing Assistant (Current TOTP Code):
                        </span>
                        <span className="font-mono-numbers font-bold text-base text-emerald-900 dark:text-emerald-200 tracking-wider">
                          {liveTestCode}
                        </span>
                        <span className="text-[10px] text-slate-400 block">Changes in {secondsRemaining}s</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setCandidate2FACode(liveTestCode)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold cursor-pointer text-xs"
                      >
                        Auto-Fill
                      </button>
                    </div>
                  )}

                  {/* Step 3: Confirm Code */}
                  <form onSubmit={handleConfirmEnable2FA} className="space-y-3 pt-2">
                    <label className="font-bold text-slate-900 dark:text-white block">
                      Step 3: Enter 6-digit code to activate 2FA
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        required
                        value={candidate2FACode}
                        onChange={(e) => setCandidate2FACode(e.target.value.trim())}
                        placeholder="123456"
                        className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-center font-mono-numbers text-sm font-bold tracking-widest"
                      />
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="px-5 py-2 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs cursor-pointer disabled:opacity-50"
                      >
                        Confirm & Activate
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                /* 2FA Not Setup: CTA */
                <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 mx-auto flex items-center justify-center">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    Protect your Business with Two-Factor Authentication
                  </h4>
                  <p className="text-slate-500 text-xs max-w-md mx-auto">
                    Add an extra layer of cryptographic defense. When enabled, signing in requires both your password and an RFC 6238 time-based verification code.
                  </p>
                  <button
                    onClick={handleBegin2FASetup}
                    className="px-5 py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
                  >
                    Enable Two-Factor Authentication
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ACTIVE SESSIONS */}
          {activeTab === 'sessions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">Active Device Sessions</h4>
                  <p className="text-[11px] text-slate-500">
                    Review and revoke active sign-ins across computers, tablets, and phones.
                  </p>
                </div>
                {allSessions.length > 1 && (
                  <button
                    onClick={logoutOtherSessions}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Log Out All Other Devices
                  </button>
                )}
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                {allSessions.map((sess) => (
                  <div key={sess.id} className="p-4 bg-white dark:bg-slate-900 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        sess.isCurrent 
                          ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400' 
                          : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
                      }`}>
                        <Laptop className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{sess.device}</span>
                          {sess.isCurrent && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
                              Current Session
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {sess.browser} • IP: <span className="font-mono-numbers">{sess.ip}</span>
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" />
                          Signed in: {new Date(sess.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>

                    {!sess.isCurrent && (
                      <button
                        onClick={() => revokeSession(sess.id)}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: CHANGE PASSWORD */}
          {activeTab === 'password' && (
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Current Password *</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">New Password (8+ characters) *</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Confirm New Password *</label>
                <input
                  type="password"
                  required
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="py-2.5 px-5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                Update Password
              </button>
            </form>
          )}

          {/* TAB 5: DANGER ZONE (ACCOUNT DELETION) */}
          {activeTab === 'danger' && (
            <div className="p-5 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 space-y-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm text-rose-900 dark:text-rose-200">
                    Permanently Delete Your Account
                  </h4>
                  <p className="text-rose-700 dark:text-rose-300 text-xs mt-0.5">
                    This action is irreversible. All your login credentials, active sessions, and multi-factor authorizations will be permanently destroyed.
                  </p>
                </div>
              </div>

              <form onSubmit={handleDeleteAccount} className="space-y-3 pt-2 border-t border-rose-200 dark:border-rose-900/60">
                <div>
                  <label className="text-slate-700 dark:text-slate-300 block mb-1 font-medium">
                    Confirm your current password:
                  </label>
                  <input
                    type="password"
                    required
                    value={deletePassword}
                    onChange={(e) => setDeletePassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-slate-700 dark:text-slate-300 block mb-1 font-medium">
                    Type <span className="font-mono-numbers font-bold text-rose-600">DELETE</span> to confirm:
                  </label>
                  <input
                    type="text"
                    required
                    value={deleteConfirmationText}
                    onChange={(e) => setDeleteConfirmationText(e.target.value)}
                    placeholder="Type DELETE"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading || deleteConfirmationText !== 'DELETE'}
                  className="w-full py-2.5 rounded-xl font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                  Permanently Delete Account
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
