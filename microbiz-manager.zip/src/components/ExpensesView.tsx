import React, { useState } from 'react';
import { 
  Receipt, 
  Search, 
  Plus, 
  Download, 
  Calendar, 
  DollarSign, 
  Trash2, 
  FileText, 
  Repeat, 
  X,
  CreditCard,
  Building,
  Tag
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Expense, ExpenseCategory, ExpenseType } from '../types';
import { formatCurrency } from '../utils/calculations';

export const ExpensesView: React.FC = () => {
  const { expenses, accounts, settings, addExpense, deleteExpense } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State
  const [formAmount, setFormAmount] = useState<number>(0);
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [formCategory, setFormCategory] = useState<ExpenseCategory>('Advertising & Marketing');
  const [formType, setFormType] = useState<ExpenseType>('operating');
  const [formDescription, setFormDescription] = useState('');
  const [formPayee, setFormPayee] = useState('');
  const [formPaymentMethod, setFormPaymentMethod] = useState('Cash');
  const [formAccountId, setFormAccountId] = useState(accounts[0]?.id || '');
  const [formIsRecurring, setFormIsRecurring] = useState(false);
  const [formRecurringInterval, setFormRecurringInterval] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const [formReceiptName, setFormReceiptName] = useState('');

  const categories: ExpenseCategory[] = [
    'Advertising & Marketing',
    'Rent & Utilities',
    'Salaries & Wages',
    'Internet & Telephone',
    'Packaging & Supplies',
    'Transportation & Fuel',
    'Software & Subscriptions',
    'Repairs & Maintenance',
    'Professional Services',
    'Other Operating Expenses'
  ];

  // Totals
  const totalOperating = expenses
    .filter(e => e.type === 'operating')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalCapex = expenses
    .filter(e => e.type === 'capital_expenditure')
    .reduce((sum, e) => sum + e.amount, 0);

  const filteredExpenses = expenses.filter(e => {
    const matchesSearch = 
      e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.payee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || e.category === selectedCategory;
    const matchesType = selectedType === 'all' || e.type === selectedType;
    return matchesSearch && matchesCat && matchesType;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formAmount <= 0) {
      alert('Expense amount must be greater than zero.');
      return;
    }

    addExpense({
      date: new Date(formDate).toISOString(),
      amount: formAmount,
      category: formCategory,
      type: formType,
      description: formDescription || formCategory,
      payee: formPayee || 'General Payee',
      paymentMethod: formPaymentMethod,
      accountId: formAccountId || undefined,
      isRecurring: formIsRecurring,
      recurringInterval: formIsRecurring ? formRecurringInterval : undefined,
      receiptName: formReceiptName || undefined
    });

    setIsAddModalOpen(false);
    // Reset form
    setFormAmount(0);
    setFormDescription('');
    setFormPayee('');
    setFormReceiptName('');
  };

  const handleExportCSV = () => {
    const headers = ['Date', 'Category', 'Classification', 'Description', 'Payee', 'Amount', 'Payment Method', 'Recurring'];
    const rows = filteredExpenses.map(e => [
      new Date(e.date).toLocaleDateString(),
      `"${e.category}"`,
      e.type,
      `"${e.description}"`,
      `"${e.payee}"`,
      e.amount,
      e.paymentMethod,
      e.isRecurring ? 'Yes' : 'No'
    ].join(','));

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encoded = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encoded);
    link.setAttribute('download', `expenses_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Operating Expenses & Overhead
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Record operating expenses (OPEX), advertising costs, rent, utilities, and maintain strict separation from capital assets (CAPEX).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Record Expense
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Operating Overhead (OPEX)</span>
          <div className="text-xl font-bold font-mono-numbers text-rose-600">
            {formatCurrency(totalOperating, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Deducted from operating profit</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Capital Expenditures (CAPEX)</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-800 dark:text-slate-200">
            {formatCurrency(totalCapex, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Assets acquired (not P&L overhead)</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Entries Logged</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {expenses.length} records
          </div>
          <span className="text-[10px] text-slate-400">Receipts and disbursement audit</span>
        </div>
      </div>

      {/* Search and Category Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search expenses by payee, description, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Classifications</option>
              <option value="operating">Operating Expense (OPEX)</option>
              <option value="capital_expenditure">Capital Expenditure (CAPEX)</option>
              <option value="owner_draw">Owner Draw / Dividend</option>
            </select>
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Description & Payee</th>
                <th className="py-3 px-4 text-center">Classification</th>
                <th className="py-3 px-4">Payment Method</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No matching expenses found.
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 text-slate-500 font-mono-numbers">
                      {new Date(exp.date).toLocaleDateString()}
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {exp.category}
                      </span>
                      {exp.isRecurring && (
                        <span className="ml-1.5 inline-flex items-center gap-0.5 text-[10px] text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 px-1.5 py-0.5 rounded">
                          <Repeat className="w-2.5 h-2.5" />
                          {exp.recurringInterval}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="text-slate-900 dark:text-white font-medium">
                        {exp.description}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Paid to: {exp.payee}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        exp.type === 'operating' 
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400' 
                          : exp.type === 'capital_expenditure' 
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400' 
                          : 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400'
                      }`}>
                        {exp.type === 'operating' ? 'OPEX' : exp.type === 'capital_expenditure' ? 'CAPEX' : 'OWNER DRAW'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {exp.paymentMethod}
                    </td>

                    <td className="py-3 px-4 text-right font-bold font-mono-numbers text-rose-600 dark:text-rose-400">
                      -{formatCurrency(exp.amount, settings.currency)}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => {
                          if (confirm(`Delete this expense entry (${formatCurrency(exp.amount, settings.currency)})?`)) {
                            deleteExpense(exp.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                        title="Delete Expense"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Expense Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Record Business Expense
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">
                    Amount ({settings.currency}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={formAmount || ''}
                    onChange={(e) => setFormAmount(parseFloat(e.target.value) || 0)}
                    placeholder="e.g. 15000"
                    className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Expense Category *</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Accounting Classification *</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as ExpenseType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="operating">Operating Expense (OPEX — rent, ads, utility, salary)</option>
                    <option value="capital_expenditure">Capital Expenditure (CAPEX — laptop, furniture, equipment)</option>
                    <option value="owner_draw">Owner Withdrawal / Dividend</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Payee / Vendor</label>
                  <input
                    type="text"
                    value={formPayee}
                    onChange={(e) => setFormPayee(e.target.value)}
                    placeholder="e.g. Meta Ads, Landlord, DESCO"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Paid From Account</label>
                  <select
                    value={formAccountId}
                    onChange={(e) => setFormAccountId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {accounts.map(a => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({formatCurrency(a.balance, settings.currency)})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Description / Purpose</label>
                  <input
                    type="text"
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="e.g. Monthly high-speed fiber internet subscription"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Recurring Setting */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsRecurring}
                    onChange={(e) => setFormIsRecurring(e.target.checked)}
                  />
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Recurring Expense (e.g. Monthly rent or subscription)
                  </span>
                </label>

                {formIsRecurring && (
                  <div className="pl-6">
                    <select
                      value={formRecurringInterval}
                      onChange={(e) => setFormRecurringInterval(e.target.value as any)}
                      className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    >
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </select>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
