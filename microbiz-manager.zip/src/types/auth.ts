import { UserRole } from './index';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  passwordHash: string; // PBKDF2 SHA-256 hash (hex)
  passwordSalt: string; // Cryptographic salt (hex)
  isEmailVerified: boolean;
  emailVerificationCode?: string;
  emailVerificationExpiresAt?: number;
  twoFactorEnabled: boolean;
  twoFactorSecret?: string; // Base32 encoded secret key
  twoFactorBackupCodes?: string[]; // 8 one-time emergency codes
  createdAt: string;
  updatedAt: string;
}

export interface UserSession {
  id: string;
  userId: string;
  token: string;
  device: string;
  browser: string;
  ip: string;
  createdAt: string;
  lastActiveAt: string;
  expiresAt: string;
  isCurrent?: boolean;
}

export interface PasswordResetRecord {
  email: string;
  token: string;
  code: string; // 6-digit numeric code
  expiresAt: number;
}

export interface TwoFactorSetupData {
  secret: string;
  otpauthUri: string;
  backupCodes: string[];
}

export interface MockEmailNotice {
  id: string;
  type: 'verification' | 'password_reset' | 'security_alert';
  toEmail: string;
  subject: string;
  code?: string;
  token?: string;
  timestamp: string;
}
