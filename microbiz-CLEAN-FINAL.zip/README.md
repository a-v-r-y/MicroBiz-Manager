# MicroBiz Manager

All-in-one business management for small businesses and online sellers: order tracking, inventory ledger (FIFO / LIFO / weighted average), operating expenses, customer & supplier management, payments, financial reports, and a true profit calculator. Works fully offline — your data never leaves your device.

## Features

- **Dashboard** — net sales, COGS, expenses, profit, cash balances, receivables/payables, low-stock alerts, revenue trends with period-over-period comparisons
- **Orders** — create, track, and fulfill orders; partial & full refunds; sales-return flow with automatic restocking; barcode input
- **Profit calculator** — true per-order profit waterfall (delivery, packaging, payment fees, commissions, ad costs), convertible straight into an order
- **Inventory** — full movement ledger, stock adjustments, purchase orders, low-stock alerts, barcode lookup
- **Expenses** — operating expenses with recurring-expense engine (weekly/monthly/yearly auto-generation)
- **Customers & suppliers** — credit limits enforced at checkout, purchase orders, payables tracking
- **Payments** — cash/bank/mobile-wallet accounts, cash transactions ledger
- **Reports** — P&L, CSV export/import, PDF invoices, self-verifying calculation test suite
- **Team support** — owner creates staff accounts with roles (admin, sales, inventory, accountant, viewer); permissions enforced across the app
- **Security** — PBKDF2 password hashing, TOTP two-factor auth, AES-GCM encrypted secrets and backups, expiring sessions
- **Comfort** — first-run onboarding wizard, actionable empty states, dark mode, mobile-friendly layouts

## Run locally

**Prerequisites:** Node.js 18+

```bash
npm install
npm run dev
```

Then open http://localhost:3000. Register the first account — it becomes the **owner**. Create staff accounts from the Team tab.

Other scripts:

```bash
npm run build    # production build
npm run preview  # preview the production build
npm run lint     # typecheck (tsc --noEmit)
```

## Team usage

The app runs on a shared shop device: everyone logs in with their own account, and roles control what each person can see and do. The owner manages the team from the **Team** tab (create accounts, assign roles, deactivate, reset passwords).

## Data & backups

All data is stored locally in your browser (localStorage/IndexedDB) — nothing is uploaded anywhere. **Back up regularly:** Settings → Export encrypted backup. Keep the file somewhere safe; you can restore from it on any device.

## Tech stack

React 19 · TypeScript · Vite · Tailwind CSS 4 · jsPDF · Web Crypto API
