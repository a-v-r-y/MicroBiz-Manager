export type CurrencyCode = 'BDT' | 'USD' | 'EUR' | 'GBP' | 'INR' | 'CAD' | 'AED';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  minorUnitDigits: number;
  locale: string;
}

export type UserRole = 'owner' | 'admin' | 'sales' | 'inventory' | 'accountant' | 'viewer';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export type InventoryValuationMethod = 'FIFO' | 'LIFO' | 'WAC';

export interface BusinessSettings {
  businessName: string;
  businessCategory: string;
  country: string;
  currency: CurrencyCode;
  timezone: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  taxEnabled: boolean;
  taxRatePercent: number;
  inventoryTracking: boolean;
  financialStartDate: string;
  invoicePrefix: string;
  invoiceNotes: string;
  logoUrl?: string;
  allowNegativeStock: boolean;
  inventoryValuationMethod: InventoryValuationMethod; // FIFO (First In First Out), LIFO (Last In First Out), or WAC (Weighted Average Cost)
  /** Set once the first-run onboarding wizard has been completed or skipped. */
  onboardingCompleted?: boolean;
}

export interface ProductVariant {
  id: string;
  name: string;
  sku: string;
  costPrice: number;
  sellingPrice: number;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode?: string;
  description: string;
  category: string;
  brand: string;
  supplierId?: string;
  costPrice: number;
  sellingPrice: number;
  wholesalePrice?: number;
  stock: number;
  minStockAlert: number;
  unit: string;
  status: 'active' | 'archived';
  variants: ProductVariant[];
  imageUrl?: string;
  createdAt: string;
}

export type MovementType = 
  | 'initial' 
  | 'purchase_receipt' 
  | 'sale' 
  | 'customer_return' 
  | 'supplier_return' 
  | 'damaged' 
  | 'lost' 
  | 'manual_adjustment';

export interface InventoryMovement {
  id: string;
  productId: string;
  productName: string;
  variantId?: string;
  variantName?: string;
  date: string;
  type: MovementType;
  quantity: number; // positive for addition, negative for reduction
  unitCost: number;
  balanceAfter: number;
  referenceId?: string; // Order # or PO #
  notes?: string;
  createdBy: string;
}

export type OrderStatus = 
  | 'draft' 
  | 'pending' 
  | 'confirmed' 
  | 'processing' 
  | 'ready' 
  | 'shipped' 
  | 'delivered' 
  | 'cancelled' 
  | 'returned';

export type PaymentStatus = 
  | 'unpaid' 
  | 'partial' 
  | 'paid' 
  | 'refunded';

export interface OrderItem {
  productId: string;
  variantId?: string;
  productName: string;
  sku: string;
  quantity: number;
  returnedQuantity?: number; // units returned via the sales-return flow (A2)
  unitCostSnapshot: number; // Snapshot of cost at order time to preserve historical accounting
  unitPrice: number;
  discount: number;
  total: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  date: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  taxAmount: number;
  deliveryChargeCollected: number; // Paid by customer
  actualDeliveryExpense: number;   // Incurred by business
  packagingExpense: number;
  paymentFee: number;
  marketplaceCommission: number;
  adCostAllocated: number;
  otherExpenses: number;
  totalAmount: number;             // Gross invoice amount payable by customer
  amountPaid: number;
  paymentMethod: string;
  paymentAccountId?: string;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  carrier?: string;
  trackingNumber?: string;
  internalNotes?: string;
  refundAmount?: number;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  notes?: string;
  creditLimit?: number;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  productsSupplied?: string;
  paymentTerms?: string;
  createdAt: string;
}

export interface PurchaseOrderItem {
  productId: string;
  variantId?: string;
  productName: string;
  sku: string;
  quantityOrdered: number;
  quantityReceived: number;
  unitCost: number;
  total: number;
}

export type POStatus = 'draft' | 'ordered' | 'partially_received' | 'received' | 'cancelled';

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  date: string;
  status: POStatus;
  paymentStatus: PaymentStatus;
  items: PurchaseOrderItem[];
  totalAmount: number;
  amountPaid: number;
  notes?: string;
  createdAt: string;
}

export type ExpenseCategory = 
  | 'Advertising & Marketing'
  | 'Rent & Utilities'
  | 'Salaries & Wages'
  | 'Internet & Telephone'
  | 'Packaging & Supplies'
  | 'Transportation & Fuel'
  | 'Software & Subscriptions'
  | 'Repairs & Maintenance'
  | 'Professional Services'
  | 'Other Operating Expenses';

export type ExpenseType = 'operating' | 'inventory_purchase' | 'capital_expenditure' | 'owner_draw';

export interface Expense {
  id: string;
  date: string;
  amount: number;
  category: ExpenseCategory;
  type: ExpenseType;
  description: string;
  payee: string;
  paymentMethod: string;
  accountId?: string;
  isRecurring?: boolean;
  recurringInterval?: 'weekly' | 'monthly' | 'yearly';
  /** B1: set on auto-generated instances — points at the template expense */
  generatedFromTemplateId?: string;
  /** B1: on recurring templates — last date for which an instance was generated */
  lastGeneratedDate?: string;
  referenceOrderNumber?: string;
  receiptName?: string;
  createdAt: string;
}

export interface FinancialAccount {
  id: string;
  name: string;
  type: 'cash' | 'bank' | 'mobile_wallet';
  accountNumber?: string;
  institution?: string;
  balance: number;
  currency: CurrencyCode;
  isDefault?: boolean;
}

export type CashTransactionType = 
  | 'customer_payment' 
  | 'supplier_payment' 
  | 'expense' 
  | 'transfer' 
  | 'owner_contribution' 
  | 'owner_draw' 
  | 'loan_in' 
  | 'loan_repay'
  | 'refund';

export interface CashTransaction {
  id: string;
  date: string;
  type: CashTransactionType;
  amount: number;
  fee?: number;
  fromAccountId?: string;
  toAccountId?: string;
  reference?: string;
  description: string;
  isReconciled: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  entity: string;
  details: string;
}

export type NotificationType = 
  | 'inventory_low' 
  | 'inventory_out' 
  | 'order_pending' 
  | 'payment_due' 
  | 'security_alert' 
  | 'system_update'
  | 'order_placed';

export type NotificationCategory = 'all' | 'unread' | 'inventory' | 'orders' | 'financial' | 'system';

export type NotificationPriority = 'critical' | 'warning' | 'info' | 'success';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  priority: NotificationPriority;
  category: 'inventory' | 'orders' | 'financial' | 'system';
  targetTab?: 'dashboard' | 'orders' | 'calculator' | 'products' | 'inventory' | 'expenses' | 'customers' | 'suppliers' | 'payments' | 'reports' | 'settings';
  targetId?: string;
  actionLabel?: string;
}
