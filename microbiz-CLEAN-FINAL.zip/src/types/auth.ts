import { UserRole } from './index';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  passwordHash: string; // PBKDF2 SHA-256 hash (hex)
  passwordSalt: string; // Cryptographic salt (hex)
  isEmailVerified: boolean;
  emailVerificationCode?: string;
  emailVerificationExpiresAt?: number;
  twoFactorEnabled: boolean;
  // Encrypted at rest (AES-GCM, password-derived key). Decrypted into memory only after login.
  twoFactorSecretEnc?: string; // JSON payload: { v, salt, iv, data }
  twoFactorBackupCodesEnc?: string; // JSON payload of stringified string[]
  /** false = blocked at login by the owner (team management). Undefined (legacy) counts as active. */
  isActive: boolean;
  /** true = user must set a new password (forced screen) before using the app. */
  mustChangePassword?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserSession {
  id: string;
  userId: string;
  token: string;
  device: string;
  browser: string;
  ip: string;
  createdAt: string;
  lastActiveAt: string;
  expiresAt: string;
  isCurrent?: boolean;
}

export interface PasswordResetRecord {
  email: string;
  token: string;
  code: string; // 6-digit numeric code
  expiresAt: number;
}

export interface TwoFactorSetupData {
  secret: string;
  otpauthUri: string;
  backupCodes: string[];
}

export interface MockEmailNotice {
  id: string;
  type: 'verification' | 'password_reset' | 'security_alert';
  toEmail: string;
  subject: string;
  code?: string;
  token?: string;
  timestamp: string;
}
