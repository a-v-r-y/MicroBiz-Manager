import { 
  BusinessSettings, 
  Product, 
  Customer, 
  Supplier, 
  Order, 
  PurchaseOrder, 
  Expense, 
  FinancialAccount, 
  CashTransaction, 
  InventoryMovement,
  UserProfile
} from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'usr-1',
  name: 'Tanvir Hossain',
  email: 'tanvir@microbiz.com',
  role: 'owner',
  avatar: 'TH'
};

export const INITIAL_SETTINGS: BusinessSettings = {
  businessName: 'Aura Lifestyle & Gadgets',
  businessCategory: 'Retail & Social Commerce',
  country: 'Bangladesh',
  currency: 'BDT',
  timezone: 'Asia/Dhaka',
  contactEmail: 'contact@auralifestyle.bd',
  contactPhone: '+880 1711-234567',
  address: 'House 42, Road 11, Banani, Dhaka 1213',
  taxEnabled: true,
  taxRatePercent: 5.0,
  inventoryTracking: true,
  financialStartDate: '2026-01-01',
  invoicePrefix: 'INV-2026-',
  invoiceNotes: 'Thank you for supporting small local business! Goods sold in good condition are eligible for exchange within 7 days with invoice.',
  allowNegativeStock: false,
  inventoryValuationMethod: 'FIFO'
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Premium Pima Cotton Oversized T-Shirt',
    sku: 'TSH-OVR-01',
    barcode: '890123456701',
    description: '220 GSM combed compact organic cotton with anti-shrink enzyme wash.',
    category: 'Clothing & Fashion',
    brand: 'Aura Wear',
    supplierId: 'sup-1',
    costPrice: 420,
    sellingPrice: 950,
    wholesalePrice: 750,
    stock: 45,
    minStockAlert: 15,
    unit: 'pcs',
    status: 'active',
    variants: [
      { id: 'v-1', name: 'Black - L', sku: 'TSH-OVR-01-BLK-L', costPrice: 420, sellingPrice: 950, stock: 20 },
      { id: 'v-2', name: 'Black - XL', sku: 'TSH-OVR-01-BLK-XL', costPrice: 420, sellingPrice: 950, stock: 15 },
      { id: 'v-3', name: 'Olive Green - L', sku: 'TSH-OVR-01-OLV-L', costPrice: 420, sellingPrice: 950, stock: 10 }
    ],
    createdAt: '2026-01-10T10:00:00Z'
  },
  {
    id: 'prod-2',
    name: 'Wireless ANC Noise-Canceling Earbuds Pro',
    sku: 'EAR-ANC-PRO',
    barcode: '890123456702',
    description: 'Active noise cancellation with 32-hour battery life and low-latency gaming mode.',
    category: 'Electronics & Gadgets',
    brand: 'SoundWave',
    supplierId: 'sup-2',
    costPrice: 3000,
    sellingPrice: 4000,
    wholesalePrice: 3600,
    stock: 12,
    minStockAlert: 5,
    unit: 'pcs',
    status: 'active',
    variants: [],
    createdAt: '2026-01-15T10:00:00Z'
  },
  {
    id: 'prod-3',
    name: 'Handcrafted Genuine Leather Bifold Wallet',
    sku: 'WAL-LEA-BRN',
    barcode: '890123456703',
    description: 'Top-grain cow leather with RFID blocking foil and coin pocket.',
    category: 'Accessories',
    brand: 'Heritage Craft',
    supplierId: 'sup-1',
    costPrice: 650,
    sellingPrice: 1450,
    wholesalePrice: 1100,
    stock: 28,
    minStockAlert: 8,
    unit: 'pcs',
    status: 'active',
    variants: [],
    createdAt: '2026-01-20T10:00:00Z'
  },
  {
    id: 'prod-4',
    name: '65W GaN Fast Charger Multi-Port (2C+1A)',
    sku: 'CHG-GAN-65W',
    barcode: '890123456704',
    description: 'Compact gallium nitride charger suitable for laptops, iPads, and smartphones.',
    category: 'Electronics & Gadgets',
    brand: 'VoltMax',
    supplierId: 'sup-2',
    costPrice: 1150,
    sellingPrice: 2100,
    wholesalePrice: 1750,
    stock: 4, // Low stock!
    minStockAlert: 10,
    unit: 'pcs',
    status: 'active',
    variants: [],
    createdAt: '2026-02-01T10:00:00Z'
  },
  {
    id: 'prod-5',
    name: 'Anti-Theft Waterproof Urban Backpack (24L)',
    sku: 'BAG-URB-24L',
    barcode: '890123456705',
    description: 'Water-resistant Oxford fabric with padded 16-inch laptop compartment and hidden luggage strap.',
    category: 'Bags & Luggage',
    brand: 'Aura Gear',
    supplierId: 'sup-1',
    costPrice: 1200,
    sellingPrice: 2600,
    wholesalePrice: 2100,
    stock: 18,
    minStockAlert: 6,
    unit: 'pcs',
    status: 'active',
    variants: [],
    createdAt: '2026-02-10T10:00:00Z'
  },
  {
    id: 'prod-6',
    name: 'Smart Magnetic Phone Ring Stand & Grip',
    sku: 'ACC-MAG-RNG',
    barcode: '890123456706',
    description: 'Ultra-thin zinc alloy magnetic phone holder with 360-degree rotation.',
    category: 'Accessories',
    brand: 'VoltMax',
    supplierId: 'sup-2',
    costPrice: 180,
    sellingPrice: 450,
    wholesalePrice: 320,
    stock: 0, // Out of stock!
    minStockAlert: 15,
    unit: 'pcs',
    status: 'active',
    variants: [],
    createdAt: '2026-02-15T10:00:00Z'
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'Farhana Ahmed',
    phone: '01819-876543',
    email: 'farhana.ahmed@gmail.com',
    address: 'Flat 4B, Road 7, Dhanmondi, Dhaka',
    notes: 'Regular customer from Facebook page. Prefers Sundarban Courier or Pathao delivery.',
    creditLimit: 5000,
    createdAt: '2026-01-12T14:30:00Z'
  },
  {
    id: 'cust-2',
    name: 'Rashidul Karim',
    phone: '01712-349876',
    email: 'r.karim@chittagong.org',
    address: 'GEC Circle, Nasirabad, Chattogram',
    notes: 'Corporate orders for tech accessories.',
    creditLimit: 15000,
    createdAt: '2026-01-18T11:00:00Z'
  },
  {
    id: 'cust-3',
    name: 'Nusrat Jahan',
    phone: '01923-456789',
    email: 'nusrat.j@outlook.com',
    address: 'Sector 4, Uttara, Dhaka',
    notes: 'Fast delivery requested on weekend orders.',
    creditLimit: 3000,
    createdAt: '2026-02-05T09:15:00Z'
  },
  {
    id: 'cust-4',
    name: 'Kamrul Hasan',
    phone: '01678-901234',
    email: 'kamrul.hasan@yahoo.com',
    address: 'Zindabazar, Sylhet',
    notes: 'Wholesale buyer for college campus.',
    creditLimit: 20000,
    createdAt: '2026-02-14T16:20:00Z'
  }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1',
    name: 'Dhaka Garments & Leather Sourcing Co.',
    phone: '01711-002233',
    email: 'orders@dhakagarments.bd',
    address: 'Plot 18, BSCIC Industrial Area, Tongi, Gazipur',
    productsSupplied: 'Cotton T-shirts, Leather Wallets, Backpacks',
    paymentTerms: 'Net 15 days upon receipt',
    createdAt: '2026-01-05T08:00:00Z'
  },
  {
    id: 'sup-2',
    name: 'Apex Tech Imports BD',
    phone: '01811-998877',
    email: 'supply@apextech.bd',
    address: 'Multiplan Center, Level 8, Elephant Road, Dhaka',
    productsSupplied: 'Earbuds, Fast Chargers, Magnetic Mounts',
    paymentTerms: '50% advance, 50% on delivery',
    createdAt: '2026-01-08T09:00:00Z'
  },
  {
    id: 'sup-3',
    name: 'EcoPack Custom Boxes & Poly BD',
    phone: '01911-445566',
    email: 'sales@ecopackbd.com',
    address: 'Sadarghat Road, Old Dhaka',
    productsSupplied: 'Branded corrugated shipping boxes, bubble wraps, poly mailers',
    paymentTerms: 'Cash on Delivery',
    createdAt: '2026-01-12T10:00:00Z'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'ORD-1001',
    customerId: 'cust-1',
    customerName: 'Farhana Ahmed',
    customerPhone: '01819-876543',
    customerAddress: 'Flat 4B, Road 7, Dhanmondi, Dhaka',
    date: '2026-03-01T14:30:00Z',
    items: [
      {
        productId: 'prod-2',
        productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
        sku: 'EAR-ANC-PRO',
        quantity: 1,
        unitCostSnapshot: 3000,
        unitPrice: 4000,
        discount: 0,
        total: 4000
      }
    ],
    subtotal: 4000,
    discount: 100, // Special promo discount: Net merchandise sales = 3,900
    taxAmount: 0,
    deliveryChargeCollected: 150, // Customer paid 150
    actualDeliveryExpense: 120,   // Pathao courier fee 120
    packagingExpense: 30,         // Custom box 30
    paymentFee: 40,               // bKash gateway fee 40
    marketplaceCommission: 0,
    adCostAllocated: 0,
    otherExpenses: 0,
    totalAmount: 4050, // 4,000 - 100 + 150 = 4,050
    amountPaid: 4050,
    paymentMethod: 'bKash Merchant',
    paymentAccountId: 'acc-3',
    paymentStatus: 'paid',
    orderStatus: 'delivered',
    carrier: 'Pathao Courier',
    trackingNumber: 'PTH-8849201',
    internalNotes: 'Benchmark order matching the specification example (Gross Profit ৳900, Order Contribution ৳860)',
    createdAt: '2026-03-01T14:30:00Z'
  },
  {
    id: 'ord-1002',
    orderNumber: 'ORD-1002',
    customerId: 'cust-2',
    customerName: 'Rashidul Karim',
    customerPhone: '01712-349876',
    customerAddress: 'GEC Circle, Nasirabad, Chattogram',
    date: '2026-03-04T11:15:00Z',
    items: [
      {
        productId: 'prod-1',
        variantId: 'v-1',
        productName: 'Premium Pima Cotton Oversized T-Shirt (Black - L)',
        sku: 'TSH-OVR-01-BLK-L',
        quantity: 2,
        unitCostSnapshot: 420,
        unitPrice: 950,
        discount: 0,
        total: 1900
      },
      {
        productId: 'prod-3',
        productName: 'Handcrafted Genuine Leather Bifold Wallet',
        sku: 'WAL-LEA-BRN',
        quantity: 1,
        unitCostSnapshot: 650,
        unitPrice: 1450,
        discount: 50,
        total: 1400
      }
    ],
    subtotal: 3350,
    discount: 50,
    taxAmount: 0,
    deliveryChargeCollected: 150,
    actualDeliveryExpense: 140, // RedX inter-district delivery
    packagingExpense: 45,
    paymentFee: 35,
    marketplaceCommission: 0,
    adCostAllocated: 120, // Meta ad allocation
    otherExpenses: 0,
    totalAmount: 3450,
    amountPaid: 3450,
    paymentMethod: 'Bank Transfer (BRAC)',
    paymentAccountId: 'acc-2',
    paymentStatus: 'paid',
    orderStatus: 'delivered',
    carrier: 'RedX Express',
    trackingNumber: 'RDX-992384',
    internalNotes: 'Facebook messenger inquiry order. Both items packaged together.',
    createdAt: '2026-03-04T11:15:00Z'
  },
  {
    id: 'ord-1003',
    orderNumber: 'ORD-1003',
    customerId: 'cust-3',
    customerName: 'Nusrat Jahan',
    customerPhone: '01923-456789',
    customerAddress: 'Sector 4, Uttara, Dhaka',
    date: '2026-03-08T16:00:00Z',
    items: [
      {
        productId: 'prod-5',
        productName: 'Anti-Theft Waterproof Urban Backpack (24L)',
        sku: 'BAG-URB-24L',
        quantity: 1,
        unitCostSnapshot: 1200,
        unitPrice: 2600,
        discount: 0,
        total: 2600
      }
    ],
    subtotal: 2600,
    discount: 0,
    taxAmount: 0,
    deliveryChargeCollected: 100,
    actualDeliveryExpense: 90,
    packagingExpense: 30,
    paymentFee: 0,
    marketplaceCommission: 0,
    adCostAllocated: 150,
    otherExpenses: 0,
    totalAmount: 2700,
    amountPaid: 1000, // Partial payment advance via bKash, remaining 1700 COD!
    paymentMethod: 'Cash on Delivery + Advance',
    paymentAccountId: 'acc-3',
    paymentStatus: 'partial',
    orderStatus: 'shipped',
    carrier: 'SteadFast Courier',
    trackingNumber: 'STF-554411',
    internalNotes: '৳1,000 bKash booking advance paid. ৳1,700 collected via delivery agent on doorstep.',
    createdAt: '2026-03-08T16:00:00Z'
  },
  {
    id: 'ord-1004',
    orderNumber: 'ORD-1004',
    customerId: 'cust-4',
    customerName: 'Kamrul Hasan',
    customerPhone: '01678-901234',
    customerAddress: 'Zindabazar, Sylhet',
    date: '2026-03-10T10:30:00Z',
    items: [
      {
        productId: 'prod-4',
        productName: '65W GaN Fast Charger Multi-Port (2C+1A)',
        sku: 'CHG-GAN-65W',
        quantity: 3,
        unitCostSnapshot: 1150,
        unitPrice: 2000, // discounted wholesale rate
        discount: 0,
        total: 6000
      }
    ],
    subtotal: 6000,
    discount: 200,
    taxAmount: 0,
    deliveryChargeCollected: 200,
    actualDeliveryExpense: 180,
    packagingExpense: 60,
    paymentFee: 60,
    marketplaceCommission: 0,
    adCostAllocated: 0,
    otherExpenses: 0,
    totalAmount: 6000, // 6,000 - 200 + 200 = 6,000
    amountPaid: 6000,
    paymentMethod: 'Bank Transfer (BRAC)',
    paymentAccountId: 'acc-2',
    paymentStatus: 'paid',
    orderStatus: 'processing',
    carrier: 'Sundarban Courier',
    trackingNumber: 'SUN-781290',
    internalNotes: 'Special quantity order for campus gadget desk.',
    createdAt: '2026-03-10T10:30:00Z'
  },
  {
    id: 'ord-1005',
    orderNumber: 'ORD-1005',
    customerId: 'cust-1',
    customerName: 'Farhana Ahmed',
    customerPhone: '01819-876543',
    customerAddress: 'Flat 4B, Road 7, Dhanmondi, Dhaka',
    date: '2026-03-11T18:00:00Z',
    items: [
      {
        productId: 'prod-1',
        variantId: 'v-2',
        productName: 'Premium Pima Cotton Oversized T-Shirt (Black - XL)',
        sku: 'TSH-OVR-01-BLK-XL',
        quantity: 1,
        unitCostSnapshot: 420,
        unitPrice: 950,
        discount: 0,
        total: 950
      }
    ],
    subtotal: 950,
    discount: 0,
    taxAmount: 0,
    deliveryChargeCollected: 100,
    actualDeliveryExpense: 90,
    packagingExpense: 25,
    paymentFee: 0,
    marketplaceCommission: 0,
    adCostAllocated: 50,
    otherExpenses: 0,
    totalAmount: 1050,
    amountPaid: 0,
    paymentMethod: 'Cash on Delivery',
    paymentStatus: 'unpaid',
    orderStatus: 'pending',
    carrier: 'Pathao Courier',
    internalNotes: 'New order placed via Instagram DM. Awaiting dispatch confirmation.',
    createdAt: '2026-03-11T18:00:00Z'
  }
];

export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    id: 'po-201',
    poNumber: 'PO-2026-01',
    supplierId: 'sup-1',
    supplierName: 'Dhaka Garments & Leather Sourcing Co.',
    date: '2026-02-15T09:00:00Z',
    status: 'received',
    paymentStatus: 'paid',
    items: [
      {
        productId: 'prod-1',
        productName: 'Premium Pima Cotton Oversized T-Shirt',
        sku: 'TSH-OVR-01',
        quantityOrdered: 50,
        quantityReceived: 50,
        unitCost: 420,
        total: 21000
      },
      {
        productId: 'prod-3',
        productName: 'Handcrafted Genuine Leather Bifold Wallet',
        sku: 'WAL-LEA-BRN',
        quantityOrdered: 30,
        quantityReceived: 30,
        unitCost: 650,
        total: 19500
      }
    ],
    totalAmount: 40500,
    amountPaid: 40500,
    notes: 'Order received in full and inspected. High stitch quality verified.',
    createdAt: '2026-02-15T09:00:00Z'
  },
  {
    id: 'po-202',
    poNumber: 'PO-2026-02',
    supplierId: 'sup-2',
    supplierName: 'Apex Tech Imports BD',
    date: '2026-02-28T14:00:00Z',
    status: 'received',
    paymentStatus: 'partial',
    items: [
      {
        productId: 'prod-2',
        productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
        sku: 'EAR-ANC-PRO',
        quantityOrdered: 15,
        quantityReceived: 15,
        unitCost: 3000,
        total: 45000
      },
      {
        productId: 'prod-4',
        productName: '65W GaN Fast Charger Multi-Port (2C+1A)',
        sku: 'CHG-GAN-65W',
        quantityOrdered: 10,
        quantityReceived: 10,
        unitCost: 1150,
        total: 11500
      }
    ],
    totalAmount: 56500,
    amountPaid: 35000, // ৳21,500 outstanding payable!
    notes: 'Partial supplier payment made via BRAC Bank. Remaining balance due on 25th March.',
    createdAt: '2026-02-28T14:00:00Z'
  },
  {
    id: 'po-203',
    poNumber: 'PO-2026-03',
    supplierId: 'sup-2',
    supplierName: 'Apex Tech Imports BD',
    date: '2026-03-09T10:00:00Z',
    status: 'ordered', // Ordered but NOT yet received! (Does not increment stock yet)
    paymentStatus: 'unpaid',
    items: [
      {
        productId: 'prod-6',
        productName: 'Smart Magnetic Phone Ring Stand & Grip',
        sku: 'ACC-MAG-RNG',
        quantityOrdered: 50,
        quantityReceived: 0,
        unitCost: 180,
        total: 9000
      }
    ],
    totalAmount: 9000,
    amountPaid: 0,
    notes: 'Restock order for out-of-stock phone stands. Estimated delivery next week.',
    createdAt: '2026-03-09T10:00:00Z'
  }
];

export const INITIAL_EXPENSES: Expense[] = [
  {
    id: 'exp-1',
    date: '2026-03-01T10:00:00Z',
    amount: 15000,
    category: 'Rent & Utilities',
    type: 'operating',
    description: 'Showroom & packing workspace rent (March)',
    payee: 'Banani Commercial Property Management',
    paymentMethod: 'Bank Transfer (BRAC)',
    accountId: 'acc-2',
    isRecurring: true,
    recurringInterval: 'monthly',
    createdAt: '2026-03-01T10:00:00Z'
  },
  {
    id: 'exp-2',
    date: '2026-03-02T12:00:00Z',
    amount: 4500,
    category: 'Advertising & Marketing',
    type: 'operating',
    description: 'Facebook & Instagram sponsored ads campaign',
    payee: 'Meta Advertising',
    paymentMethod: 'Bank Card',
    accountId: 'acc-2',
    isRecurring: false,
    createdAt: '2026-03-02T12:00:00Z'
  },
  {
    id: 'exp-3',
    date: '2026-03-05T15:30:00Z',
    amount: 1200,
    category: 'Internet & Telephone',
    type: 'operating',
    description: 'High-speed fiber broadband connection',
    payee: 'Dot Internet BD',
    paymentMethod: 'bKash Merchant',
    accountId: 'acc-3',
    isRecurring: true,
    recurringInterval: 'monthly',
    createdAt: '2026-03-05T15:30:00Z'
  },
  {
    id: 'exp-4',
    date: '2026-03-06T11:00:00Z',
    amount: 3200,
    category: 'Packaging & Supplies',
    type: 'operating',
    description: 'Custom logo stickers, thermal printer labels & bubble wraps',
    payee: 'EcoPack BD',
    paymentMethod: 'Cash',
    accountId: 'acc-1',
    isRecurring: false,
    createdAt: '2026-03-06T11:00:00Z'
  },
  {
    id: 'exp-5',
    date: '2026-03-07T14:00:00Z',
    amount: 8000,
    category: 'Salaries & Wages',
    type: 'operating',
    description: 'Part-time packaging & dispatch assistant salary',
    payee: 'Arif Mia',
    paymentMethod: 'bKash Merchant',
    accountId: 'acc-3',
    isRecurring: true,
    recurringInterval: 'monthly',
    createdAt: '2026-03-07T14:00:00Z'
  }
];

export const INITIAL_ACCOUNTS: FinancialAccount[] = [
  {
    id: 'acc-1',
    name: 'Cash in Drawer / Petty Cash',
    type: 'cash',
    accountNumber: 'CASH-MAIN',
    institution: 'Physical Safe',
    balance: 14200,
    currency: 'BDT',
    isDefault: false
  },
  {
    id: 'acc-2',
    name: 'BRAC Bank Business Checking',
    type: 'bank',
    accountNumber: '1501-2049-88001',
    institution: 'BRAC Bank PLC',
    balance: 92450,
    currency: 'BDT',
    isDefault: true
  },
  {
    id: 'acc-3',
    name: 'bKash Merchant Account',
    type: 'mobile_wallet',
    accountNumber: '01811-334455',
    institution: 'bKash Limited',
    balance: 38750,
    currency: 'BDT',
    isDefault: false
  }
];

export const INITIAL_TRANSACTIONS: CashTransaction[] = [
  {
    id: 'tx-1',
    date: '2026-03-01T14:30:00Z',
    type: 'customer_payment',
    amount: 4050,
    fee: 40,
    toAccountId: 'acc-3',
    reference: 'ORD-1001',
    description: 'Payment received for Order ORD-1001 (bKash)',
    isReconciled: true,
    createdAt: '2026-03-01T14:30:00Z'
  },
  {
    id: 'tx-2',
    date: '2026-03-03T16:00:00Z',
    type: 'transfer',
    amount: 10000,
    fromAccountId: 'acc-3',
    toAccountId: 'acc-2',
    reference: 'TRF-BKASH-BRAC',
    description: 'Internal transfer from bKash Merchant to BRAC Bank Checking',
    isReconciled: true,
    createdAt: '2026-03-03T16:00:00Z'
  },
  {
    id: 'tx-3',
    date: '2026-03-04T11:15:00Z',
    type: 'customer_payment',
    amount: 3450,
    toAccountId: 'acc-2',
    reference: 'ORD-1002',
    description: 'Payment received for Order ORD-1002 (Bank Transfer)',
    isReconciled: true,
    createdAt: '2026-03-04T11:15:00Z'
  },
  {
    id: 'tx-4',
    date: '2026-03-05T10:00:00Z',
    type: 'supplier_payment',
    amount: 35000,
    fromAccountId: 'acc-2',
    reference: 'PO-2026-02',
    description: 'Partial payment to Apex Tech Imports for PO-2026-02',
    isReconciled: true,
    createdAt: '2026-03-05T10:00:00Z'
  },
  {
    id: 'tx-5',
    date: '2026-03-08T16:00:00Z',
    type: 'customer_payment',
    amount: 1000,
    toAccountId: 'acc-3',
    reference: 'ORD-1003',
    description: 'Partial advance payment for Order ORD-1003 (bKash)',
    isReconciled: false,
    createdAt: '2026-03-08T16:00:00Z'
  }
];

export const INITIAL_MOVEMENTS: InventoryMovement[] = [
  // Product 1: T-Shirt (Total 48 units on hand from 2 purchase batches)
  {
    id: 'mov-1a',
    productId: 'prod-1',
    productName: 'Premium Pima Cotton Oversized T-Shirt',
    date: '2026-02-10T10:00:00Z',
    type: 'purchase_receipt',
    quantity: 30,
    unitCost: 400,
    balanceAfter: 30,
    referenceId: 'PO-2026-01',
    notes: 'Initial factory batch delivery',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-1b',
    productId: 'prod-1',
    productName: 'Premium Pima Cotton Oversized T-Shirt',
    date: '2026-02-24T14:00:00Z',
    type: 'purchase_receipt',
    quantity: 20,
    unitCost: 450, // Cost increased due to cotton price index
    balanceAfter: 50,
    referenceId: 'PO-2026-03',
    notes: 'Restock batch (yarn price adjustment)',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-2',
    productId: 'prod-1',
    productName: 'Premium Pima Cotton Oversized T-Shirt',
    date: '2026-03-04T11:15:00Z',
    type: 'sale',
    quantity: -2,
    unitCost: 420,
    balanceAfter: 48,
    referenceId: 'ORD-1002',
    notes: 'Dispatched for Order ORD-1002',
    createdBy: 'Tanvir Hossain'
  },

  // Product 2: Earbuds Pro (Total 12 units on hand from 2 purchase batches)
  {
    id: 'mov-3a',
    productId: 'prod-2',
    productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
    date: '2026-02-12T11:00:00Z',
    type: 'purchase_receipt',
    quantity: 8,
    unitCost: 2800,
    balanceAfter: 8,
    referenceId: 'PO-2026-02A',
    notes: 'Initial tech import shipment',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-3b',
    productId: 'prod-2',
    productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
    date: '2026-02-28T16:00:00Z',
    type: 'purchase_receipt',
    quantity: 7,
    unitCost: 3200, // Tariff and component surcharge
    balanceAfter: 15,
    referenceId: 'PO-2026-02B',
    notes: 'Second import batch',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-4',
    productId: 'prod-2',
    productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
    date: '2026-03-01T14:30:00Z',
    type: 'sale',
    quantity: -1,
    unitCost: 3000,
    balanceAfter: 14,
    referenceId: 'ORD-1001',
    notes: 'Dispatched for Order ORD-1001',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-5',
    productId: 'prod-2',
    productName: 'Wireless ANC Noise-Canceling Earbuds Pro',
    date: '2026-03-05T09:00:00Z',
    type: 'damaged',
    quantity: -2,
    unitCost: 3000,
    balanceAfter: 12,
    referenceId: 'ADJ-DMG-01',
    notes: 'Water damage during courier transit return inspection',
    createdBy: 'Tanvir Hossain'
  },

  // Product 3: Magnetic Leather Wallet (Total 35 units on hand)
  {
    id: 'mov-7a',
    productId: 'prod-3',
    productName: 'Minimalist MagSafe Leather Card Wallet',
    date: '2026-01-20T10:00:00Z',
    type: 'purchase_receipt',
    quantity: 20,
    unitCost: 320,
    balanceAfter: 20,
    referenceId: 'PO-2026-04A',
    notes: 'Batch 1 acquisition',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-7b',
    productId: 'prod-3',
    productName: 'Minimalist MagSafe Leather Card Wallet',
    date: '2026-02-15T15:00:00Z',
    type: 'purchase_receipt',
    quantity: 20,
    unitCost: 380, // Leather material price change
    balanceAfter: 40,
    referenceId: 'PO-2026-04B',
    notes: 'Batch 2 restock',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-7c',
    productId: 'prod-3',
    productName: 'Minimalist MagSafe Leather Card Wallet',
    date: '2026-03-03T12:00:00Z',
    type: 'sale',
    quantity: -5,
    unitCost: 350,
    balanceAfter: 35,
    referenceId: 'ORD-1004',
    notes: 'Dispatched to retail customer',
    createdBy: 'Tanvir Hossain'
  },

  // Product 5: Anti-Theft Backpack (Total 18 units on hand)
  {
    id: 'mov-8a',
    productId: 'prod-5',
    productName: 'Anti-Theft Waterproof Urban Backpack (24L)',
    date: '2026-02-10T10:00:00Z',
    type: 'purchase_receipt',
    quantity: 10,
    unitCost: 1100,
    balanceAfter: 10,
    referenceId: 'PO-2026-05A',
    notes: 'Early supplier production run',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-8b',
    productId: 'prod-5',
    productName: 'Anti-Theft Waterproof Urban Backpack (24L)',
    date: '2026-02-22T14:30:00Z',
    type: 'purchase_receipt',
    quantity: 10,
    unitCost: 1300, // Increased nylon raw cost
    balanceAfter: 20,
    referenceId: 'PO-2026-05B',
    notes: 'Main production shipment',
    createdBy: 'Tanvir Hossain'
  },
  {
    id: 'mov-8c',
    productId: 'prod-5',
    productName: 'Anti-Theft Waterproof Urban Backpack (24L)',
    date: '2026-03-02T16:00:00Z',
    type: 'sale',
    quantity: -2,
    unitCost: 1200,
    balanceAfter: 18,
    referenceId: 'ORD-1005',
    notes: 'Corporate client purchase',
    createdBy: 'Tanvir Hossain'
  }
];
