import { useEffect, useRef } from 'react';

/**
 * Shared modal behavior: Escape-to-close (topmost modal only), backdrop-click
 * close, basic focus trap, autofocus of the first input, and body scroll-lock.
 *
 * Usage:
 *   const { backdropProps, panelProps } = useModalBehavior(isOpen, onClose, 'Add customer');
 *   {isOpen && (
 *     <div className="fixed inset-0 z-50 ..." {...backdropProps}>
 *       <div className="bg-white ..." {...panelProps}>
 *         ...
 *       </div>
 *     </div>
 *   )}
 */

// Module-level stack so only the topmost open modal handles Escape/Tab.
const openStack: string[] = [];
let scrollLockCount = 0;

function lockScroll() {
  scrollLockCount++;
  if (scrollLockCount === 1) {
    document.body.style.overflow = 'hidden';
  }
}

function unlockScroll() {
  scrollLockCount = Math.max(0, scrollLockCount - 1);
  if (scrollLockCount === 0) {
    document.body.style.overflow = '';
  }
}

const FOCUSABLE_SELECTOR =
  'button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])';

export function useModalBehavior(isOpen: boolean, onClose: () => void, label: string) {
  const panelRef = useRef<HTMLDivElement | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const idRef = useRef<string>('');
  if (!idRef.current) {
    idRef.current = `modal-${Math.random().toString(36).slice(2, 10)}`;
  }

  useEffect(() => {
    if (!isOpen) return;
    const id = idRef.current;
    openStack.push(id);
    lockScroll();

    const onKeyDown = (e: KeyboardEvent) => {
      // Only the topmost modal in the stack responds.
      if (openStack[openStack.length - 1] !== id) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
        return;
      }

      if (e.key === 'Tab') {
        const panel = panelRef.current;
        if (!panel) return;
        const focusables = Array.from(panel.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
          (el) => el.getClientRects().length > 0
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    document.addEventListener('keydown', onKeyDown, true);

    // Autofocus the first text-like input once the panel is mounted.
    const timer = window.setTimeout(() => {
      const target = panelRef.current?.querySelector<HTMLElement>(
        'input:not([disabled]):not([type="hidden"]):not([type="checkbox"]), select:not([disabled]), textarea:not([disabled])'
      );
      target?.focus({ preventScroll: true });
    }, 40);

    return () => {
      const idx = openStack.indexOf(id);
      if (idx >= 0) openStack.splice(idx, 1);
      unlockScroll();
      document.removeEventListener('keydown', onKeyDown, true);
      window.clearTimeout(timer);
    };
  }, [isOpen]);

  const onBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onCloseRef.current();
    }
  };

  return {
    backdropProps: { onClick: onBackdropClick } as const,
    panelProps: {
      ref: panelRef,
      role: 'dialog' as const,
      'aria-modal': true as const,
      'aria-label': label,
    },
  };
}
