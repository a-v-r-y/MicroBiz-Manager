import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Sun, 
  Moon, 
  ShieldCheck, 
  Plus, 
  Calculator, 
  Package, 
  Receipt, 
  ShoppingCart, 
  Bell,
  Menu,
  LogOut,
  Key,
  Shield,
  User as UserIcon,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Smartphone,
  Laptop
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { NotificationPanel } from './NotificationPanel';
import { NavTab } from './Sidebar';
import { UserRole } from '../types';

interface HeaderProps {
  onToggleSidebar: () => void;
  onOpenQuickAction: (action: 'order' | 'product' | 'expense' | 'calculator') => void;
  activeTab: string;
  onNavigate?: (tab: NavTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleSidebar, onOpenQuickAction, onNavigate }) => {
  const { settings, user, setUserRole, darkMode, toggleDarkMode } = useApp();
  const { 
    currentUser, 
    isAuthenticated, 
    isEmailVerified, 
    logout, 
    openAuthModal, 
    openSecuritySettings 
  } = useAuth();
  const { unreadCount, toggleNotifications, isOpen: isNotificationOpen } = useNotifications();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  // Escape closes the user dropdown
  useEffect(() => {
    if (!isUserMenuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => document.removeEventListener('keydown', onKey, true);
  }, [isUserMenuOpen]);

  const roles: { value: UserRole; label: string; desc: string }[] = [
    { value: 'owner', label: 'Owner (Full Access)', desc: 'Unrestricted business & accounting access' },
    { value: 'admin', label: 'Admin', desc: 'Manage operations & staff' },
    { value: 'sales', label: 'Sales Staff', desc: 'Orders & customers only' },
    { value: 'inventory', label: 'Inventory Staff', desc: 'Products & stock adjustments' },
    { value: 'accountant', label: 'Accountant', desc: 'Financial ledgers, payments & reports' },
    { value: 'viewer', label: 'Viewer (Read Only)', desc: 'Auditing and read-only access' }
  ];

  return (
    <header className="sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors shadow-xs">
      <div className="flex items-center justify-between px-4 sm:px-6 py-2.5">
        {/* Left: Mobile Toggle & Business Identity */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            aria-label="Toggle navigation"
            className="md:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-linear-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xs font-bold text-lg">
              {settings.businessName.charAt(0) || 'M'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 dark:text-white tracking-tight leading-none truncate max-w-[180px] sm:max-w-xs">
                  {settings.businessName}
                </h1>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50">
                  {settings.currency}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5">
                <Building2 className="w-3 h-3 text-slate-400" />
                <span className="truncate max-w-[140px] sm:max-w-none">{settings.businessCategory}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Right: Quick actions, notifications, role switcher, user account, theme toggle */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Create Dropdown / Buttons */}
          <div className="hidden sm:flex items-center gap-1.5">
            <button
              onClick={() => onOpenQuickAction('calculator')}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition cursor-pointer"
            >
              <Calculator className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              Profit Calc
            </button>
            <button
              onClick={() => onOpenQuickAction('order')}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              New Order
            </button>
          </div>

          {/* Quick Action Icon on Mobile */}
          <button
            onClick={() => onOpenQuickAction('order')}
            className="sm:hidden p-2 rounded-lg bg-emerald-600 text-white shadow-xs"
            title="Create Order"
          >
            <Plus className="w-4 h-4" />
          </button>

          {/* Unverified Email Warning Chip (if logged in and unverified) */}
          {isAuthenticated && !isEmailVerified && (
            <button
              onClick={() => openAuthModal('verify_email')}
              className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 cursor-pointer"
              title="Click to enter 6-digit verification code"
            >
              <AlertTriangle className="w-3 h-3 text-amber-500 animate-pulse" />
              <span>Verify Email</span>
            </button>
          )}

          {/* Fully Functional Interactive Notification Button & Center */}
          <div className="relative">
            <button
              id="header-bell-button"
              onClick={toggleNotifications}
              className={`p-2 rounded-lg transition relative cursor-pointer ${
                isNotificationOpen
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="System Alerts & Notifications"
              aria-label="Toggle notifications panel"
              aria-expanded={isNotificationOpen}
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-amber-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>

            {/* Notification Panel Popover */}
            <NotificationPanel onNavigate={onNavigate} />
          </div>

          {/* Role Simulator Switcher */}
          <div className="hidden xl:flex items-center gap-1.5 pl-2 border-l border-slate-200 dark:border-slate-800">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={user.role}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              className="text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 py-1 px-2 rounded-lg border border-transparent focus:border-emerald-500 focus:outline-none cursor-pointer"
              title="Simulate Role Permissions"
            >
              {roles.map(r => (
                <option key={r.value} value={r.value}>
                  Role: {r.label.split(' ')[0]}
                </option>
              ))}
            </select>
          </div>

          {/* User Account / Authentication Menu */}
          {isAuthenticated && currentUser ? (
            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer text-xs"
              >
                <div className="relative">
                  <div className="w-7 h-7 rounded-lg bg-linear-to-tr from-emerald-600 to-teal-500 text-white font-bold flex items-center justify-center text-xs">
                    {currentUser.avatar || currentUser.name.charAt(0)}
                  </div>
                  {currentUser.twoFactorEnabled && (
                    <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border border-white dark:border-slate-900 flex items-center justify-center text-[7px] text-white">
                      ✓
                    </span>
                  )}
                </div>

                <div className="text-left hidden sm:block">
                  <div className="font-semibold text-slate-900 dark:text-white leading-none truncate max-w-[100px]">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-slate-400 capitalize leading-none mt-0.5">
                    {currentUser.role}
                  </div>
                </div>

                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {/* User Dropdown Drawer */}
              {isUserMenuOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setIsUserMenuOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-2 w-64 p-2 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 text-xs z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="p-3 border-b border-slate-100 dark:border-slate-800">
                      <div className="font-bold text-slate-900 dark:text-white truncate">
                        {currentUser.name}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {currentUser.email}
                      </div>
                      <div className="flex items-center gap-1.5 mt-2">
                        {isEmailVerified ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            <CheckCircle2 className="w-2.5 h-2.5" /> Verified
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              openAuthModal('verify_email');
                            }}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 cursor-pointer"
                          >
                            <AlertTriangle className="w-2.5 h-2.5" /> Verify Email
                          </button>
                        )}

                        {currentUser.twoFactorEnabled && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                            <Smartphone className="w-2.5 h-2.5" /> 2FA Active
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          openSecuritySettings();
                        }}
                        className="w-full px-3 py-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>Security & 2FA Settings</span>
                      </button>

                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          openSecuritySettings();
                        }}
                        className="w-full px-3 py-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                      >
                        <Laptop className="w-4 h-4 text-blue-600" />
                        <span>Active Devices & Sessions</span>
                      </button>
                    </div>

                    <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          logout();
                        }}
                        className="w-full px-3 py-2 rounded-xl text-left hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center gap-2 transition cursor-pointer font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => openAuthModal('login')}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => openAuthModal('register')}
                className="hidden sm:inline-flex px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
              >
                Register
              </button>
            </div>
          )}

          {/* Theme Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            aria-label="Toggle theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>
      </div>
    </header>
  );
};
