import React, { useState } from 'react';
import { 
  Truck, 
  Search, 
  Plus, 
  Phone, 
  Mail, 
  CheckCircle2, 
  Clock, 
  Boxes, 
  DollarSign, 
  CreditCard, 
  X,
  FileCheck,
  PackageCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Supplier, PurchaseOrder, PurchaseOrderItem } from '../types';
import { formatCurrency } from '../utils/calculations';
import { useModalBehavior } from '../hooks/useModalBehavior';

export const SuppliersView: React.FC = () => {
  const { 
    suppliers, 
    purchaseOrders, 
    products, 
    accounts, 
    settings, 
    addSupplier, 
    addPurchaseOrder, 
    receivePurchaseOrder, 
    recordPOPayment 
  } = useApp();
  const { can } = useAuth();

  const [activeTab, setActiveTab] = useState<'pos' | 'directory'>('pos');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals
  const [isAddSupplierOpen, setIsAddSupplierOpen] = useState(false);
  const [isCreatePOOpen, setIsCreatePOOpen] = useState(false);
  const [paymentPO, setPaymentPO] = useState<PurchaseOrder | null>(null);
  const [supError, setSupError] = useState('');
  const [poError, setPoError] = useState('');

  const closeAddSupplier = () => {
    setIsAddSupplierOpen(false);
    setSupError('');
    setSupName('');
    setSupPhone('');
    setSupEmail('');
    setSupAddress('');
  };
  const closeCreatePO = () => {
    setIsCreatePOOpen(false);
    setPoError('');
  };

  const addSupplierModal = useModalBehavior(isAddSupplierOpen, closeAddSupplier, 'Add supplier');
  const createPOModal = useModalBehavior(isCreatePOOpen, closeCreatePO, 'Create purchase order');
  const paymentModal = useModalBehavior(!!paymentPO, () => setPaymentPO(null), 'Record supplier payment');

  // Supplier Form
  const [supName, setSupName] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supAddress, setSupAddress] = useState('');
  const [supProducts, setSupProducts] = useState('');
  const [supTerms, setSupTerms] = useState('Net 15 days');

  // PO Form
  const [poSupplierId, setPoSupplierId] = useState(suppliers[0]?.id || '');
  const [poItems, setPoItems] = useState<Array<{
    productId: string;
    productName: string;
    sku: string;
    quantityOrdered: number;
    unitCost: number;
  }>>([
    {
      productId: products[0]?.id || '',
      productName: products[0]?.name || '',
      sku: products[0]?.sku || '',
      quantityOrdered: 20,
      unitCost: products[0]?.costPrice || 0
    }
  ]);
  const [poNotes, setPoNotes] = useState('');

  // Payment Form
  const [payAmount, setPayAmount] = useState(0);
  const [payAccountId, setPayAccountId] = useState(accounts[0]?.id || '');

  // Calculate Payables Balance
  const totalPayables = purchaseOrders.reduce((sum, po) => {
    if (po.status !== 'cancelled') {
      const balance = po.totalAmount - (po.amountPaid || 0);
      return sum + Math.max(0, balance);
    }
    return sum;
  }, 0);

  const handleAddSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName.trim() || !supPhone.trim()) {
      setSupError('Supplier name and phone are required.');
      return;
    }
    setSupError('');

    addSupplier({
      name: supName.trim(),
      phone: supPhone.trim(),
      email: supEmail || undefined,
      address: supAddress || undefined,
      productsSupplied: supProducts || undefined,
      paymentTerms: supTerms
    });

    closeAddSupplier();
    setSupProducts('');
  };

  const handleCreatePOSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sup = suppliers.find(s => s.id === poSupplierId);
    if (!sup) {
      setPoError('Please select a supplier.');
      return;
    }
    setPoError('');

    const items: PurchaseOrderItem[] = poItems.map(i => ({
      ...i,
      quantityReceived: 0,
      total: i.quantityOrdered * i.unitCost
    }));

    const totalAmount = items.reduce((sum, i) => sum + i.total, 0);

    addPurchaseOrder({
      supplierId: sup.id,
      supplierName: sup.name,
      date: new Date().toISOString(),
      status: 'ordered', // Ordered, NOT yet received!
      paymentStatus: 'unpaid',
      items,
      totalAmount,
      amountPaid: 0,
      notes: poNotes || undefined
    });

    closeCreatePO();
    setPoNotes('');
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentPO || payAmount <= 0) return;
    recordPOPayment(paymentPO.id, payAmount, payAccountId);
    setPaymentPO(null);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Suppliers & Purchase Orders
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Strict separation between ordering and receiving stock. Payables calculated from supplier invoices minus disbursed payments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAddSupplierOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Supplier
          </button>
          <button
            onClick={() => setIsCreatePOOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <PackageCheck className="w-4 h-4" />
            Create Purchase Order
          </button>
        </div>
      </div>

      {/* KPI Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Outstanding Payables</span>
          <div className="text-xl font-bold font-mono-numbers text-rose-600">
            {formatCurrency(totalPayables, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Due to vendors for delivered stock</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Active Suppliers</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {suppliers.length} vendors
          </div>
          <span className="text-[10px] text-slate-400">Garment factories, tech importers, packaging</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Purchase Orders Logged</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {purchaseOrders.length} orders
          </div>
          <span className="text-[10px] text-slate-400">Receiving and payment tracking</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('pos')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeTab === 'pos'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Purchase Orders ({purchaseOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('directory')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeTab === 'directory'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Suppliers Directory ({suppliers.length})
        </button>
      </div>

      {/* POs Tab Content */}
      {activeTab === 'pos' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <tr>
                  <th className="py-3 px-4">PO Number</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4">Ordered Items</th>
                  <th className="py-3 px-4 text-center">Fulfillment Status</th>
                  <th className="py-3 px-4 text-center">Payment Status</th>
                  <th className="py-3 px-4 text-right">Total Invoice</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {purchaseOrders.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-8 text-center">
                      <p className="text-slate-400 text-xs">No purchase orders recorded yet.</p>
                      <button
                        onClick={() => setIsCreatePOOpen(true)}
                        className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> Create your first purchase order
                      </button>
                    </td>
                  </tr>
                ) : (
                  purchaseOrders.map((po) => {
                    const balanceDue = Math.max(0, po.totalAmount - (po.amountPaid || 0));

                    return (
                      <tr key={po.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                        <td className="py-3 px-4 font-bold font-mono-numbers text-slate-900 dark:text-white">
                          {po.poNumber}
                        </td>

                        <td className="py-3 px-4 text-slate-500">
                          {new Date(po.date).toLocaleDateString()}
                        </td>

                        <td className="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200">
                          {po.supplierName}
                        </td>

                        <td className="py-3 px-4">
                          <div className="text-slate-700 dark:text-slate-300">
                            {po.items.map(i => `${i.productName} (${i.quantityOrdered})`).join(', ')}
                          </div>
                        </td>

                        <td className="py-3 px-4 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            po.status === 'received'
                              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                              : po.status === 'ordered'
                              ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400'
                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}>
                            {po.status === 'received' ? 'GOODS RECEIVED' : 'ORDERED (AWAITING)'}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            po.paymentStatus === 'paid'
                              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                              : po.paymentStatus === 'partial'
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400'
                              : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                          }`}>
                            {po.paymentStatus.toUpperCase()}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right font-bold font-mono-numbers text-slate-900 dark:text-white">
                          {formatCurrency(po.totalAmount, settings.currency)}
                        </td>

                        <td className="py-3 px-4 text-right font-mono-numbers">
                          {balanceDue > 0 ? (
                            <span className="text-rose-600 font-bold">
                              {formatCurrency(balanceDue, settings.currency)}
                            </span>
                          ) : (
                            <span className="text-emerald-600 text-[11px]">Paid</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Goods Receipt Action */}
                            {po.status !== 'received' && (
                              <button
                                onClick={() => receivePurchaseOrder(po.id)}
                                disabled={!can('inventory.receive')}
                                className="px-2 py-1 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                                title={can('inventory.receive') ? 'Receive goods into inventory' : 'Your role cannot receive stock'}
                              >
                                Receive Stock
                              </button>
                            )}

                            {/* Pay Supplier Action */}
                            {balanceDue > 0 && (
                              <button
                                onClick={() => {
                                  setPaymentPO(po);
                                  setPayAmount(balanceDue);
                                }}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                                title="Record Supplier Payment"
                              >
                                <DollarSign className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Directory Tab Content */}
      {activeTab === 'directory' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {suppliers.map(sup => (
            <div 
              key={sup.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3"
            >
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">{sup.name}</h3>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                  <Phone className="w-3 h-3 text-slate-400" />
                  <span className="font-mono-numbers">{sup.phone}</span>
                </div>
              </div>

              {sup.productsSupplied && (
                <div className="text-xs text-slate-600 dark:text-slate-400">
                  <span className="font-semibold block text-[10px] text-slate-400 uppercase">Supplies:</span>
                  {sup.productsSupplied}
                </div>
              )}

              {sup.paymentTerms && (
                <div className="text-xs text-slate-500">
                  <span className="font-semibold block text-[10px] text-slate-400 uppercase">Terms:</span>
                  {sup.paymentTerms}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add Supplier Modal */}
      {isAddSupplierOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...addSupplierModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...addSupplierModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Add Supplier / Vendor
              </h3>
              <button onClick={closeAddSupplier} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSupplierSubmit} className="space-y-4 text-xs">
              {supError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {supError}
                </p>
              )}
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Supplier Company Name *</label>
                <input
                  type="text"
                  required
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  placeholder="e.g. Apex Tech Imports BD"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Phone Number *</label>
                <input
                  type="text"
                  required
                  value={supPhone}
                  onChange={(e) => setSupPhone(e.target.value)}
                  placeholder="e.g. 01711-002233"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Email</label>
                <input
                  type="email"
                  value={supEmail}
                  onChange={(e) => setSupEmail(e.target.value)}
                  placeholder="supply@vendor.com"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Products Supplied</label>
                <input
                  type="text"
                  value={supProducts}
                  onChange={(e) => setSupProducts(e.target.value)}
                  placeholder="e.g. Cotton T-shirts, Earbuds, Packaging"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Payment Terms</label>
                <input
                  type="text"
                  value={supTerms}
                  onChange={(e) => setSupTerms(e.target.value)}
                  placeholder="e.g. Net 15 days, 50% advance"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={closeAddSupplier}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create PO Modal */}
      {isCreatePOOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...createPOModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...createPOModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Create Purchase Order (PO)
              </h3>
              <button onClick={closeCreatePO} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePOSubmit} className="space-y-4 text-xs">
              {poError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {poError}
                </p>
              )}
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Select Supplier *</label>
                <select
                  value={poSupplierId}
                  onChange={(e) => setPoSupplierId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Product to Order *</label>
                <select
                  value={poItems[0].productId}
                  onChange={(e) => {
                    const prod = products.find(p => p.id === e.target.value);
                    if (prod) {
                      setPoItems([{
                        productId: prod.id,
                        productName: prod.name,
                        sku: prod.sku,
                        quantityOrdered: 20,
                        unitCost: prod.costPrice
                      }]);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>{p.name} (Cost: {p.costPrice})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Quantity to Order</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={poItems[0].quantityOrdered}
                    onChange={(e) => {
                      const val = Math.max(1, parseInt(e.target.value) || 1);
                      setPoItems(prev => [{ ...prev[0], quantityOrdered: val }]);
                    }}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Agreed Unit Cost</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={poItems[0].unitCost}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      setPoItems(prev => [{ ...prev[0], unitCost: val }]);
                    }}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex justify-between font-bold">
                <span>Total PO Commitment:</span>
                <span className="font-mono-numbers text-slate-900 dark:text-white">
                  {formatCurrency(poItems[0].quantityOrdered * poItems[0].unitCost, settings.currency)}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={closeCreatePO}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Issue Purchase Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record PO Payment Modal */}
      {paymentPO && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...paymentModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...paymentModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Pay Supplier for {paymentPO.poNumber}
              </h3>
              <button onClick={() => setPaymentPO(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">
                  Payment Amount ({settings.currency}) *
                </label>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Disburse From Account *</label>
                <select
                  value={payAccountId}
                  onChange={(e) => setPayAccountId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setPaymentPO(null)}
                  className="px-4 py-2 text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Confirm Supplier Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
