import React, { useState } from 'react';
import { 
  Settings, 
  Building2, 
  DollarSign, 
  ShieldCheck, 
  Upload, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Globe, 
  Percent, 
  FileText,
  UserCheck,
  History,
  Lock,
  Smartphone,
  Laptop
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { CurrencyCode, UserRole } from '../types';
import { CURRENCY_CONFIGS } from '../utils/calculations';
import { useModalBehavior } from '../hooks/useModalBehavior';
import { ConfirmDialog } from './ConfirmDialog';
import { useNotifications } from '../context/NotificationContext';

export const SettingsView: React.FC = () => {
  const { 
    currentUser, 
    isEmailVerified, 
    allSessions, 
    openSecuritySettings, 
    openAuthModal,
    can
  } = useAuth();
  const { 
    settings, 
    updateSettings, 
    user, 
    setUserRole, 
    auditLogs, 
    resetToSampleData, 
    exportEncryptedBackup, 
    importEncryptedBackup 
  } = useApp();

  const [formSettings, setFormSettings] = useState(settings);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [confirmResetDemo, setConfirmResetDemo] = useState(false);
  const { pushNotification } = useNotifications();

  const importModal = useModalBehavior(
    isImportModalOpen,
    () => { setIsImportModalOpen(false); setBackupError(''); },
    'Restore encrypted backup'
  );

  // Encrypted backup state (I11)
  const [backupPassword, setBackupPassword] = useState('');
  const [backupPasswordConfirm, setBackupPasswordConfirm] = useState('');
  const [importPassword, setImportPassword] = useState('');
  const [backupError, setBackupError] = useState('');
  const [isBackingUp, setIsBackingUp] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formSettings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleDownloadBackup = async () => {
    setBackupError('');
    if (!backupPassword || backupPassword.length < 8) {
      setBackupError('Backup password must be at least 8 characters long.');
      return;
    }
    if (backupPassword !== backupPasswordConfirm) {
      setBackupError('Backup passwords do not match.');
      return;
    }
    setIsBackingUp(true);
    try {
      const payload = await exportEncryptedBackup(backupPassword);
      const blob = new Blob([payload], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `microbiz_backup_${new Date().toISOString().slice(0, 10)}.encrypted.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setBackupPassword('');
      setBackupPasswordConfirm('');
    } catch (e: any) {
      setBackupError(e.message || 'Backup export failed.');
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleImportSubmit = async () => {
    if (!importJsonText.trim()) return;
    setBackupError('');
    if (!importPassword) {
      setBackupError('Enter the backup password to decrypt and restore.');
      return;
    }
    setIsBackingUp(true);
    try {
      const res = await importEncryptedBackup(importPassword, importJsonText);
      if (res.success) {
        setIsImportModalOpen(false);
        setImportJsonText('');
        setImportPassword('');
        pushNotification({
          type: 'system_update',
          title: 'Backup restored successfully',
          message: 'Your data has been restored from the encrypted backup. Please sign in again.',
          priority: 'success',
          category: 'system',
          targetTab: 'settings',
          actionLabel: 'Open settings',
        });
      } else {
        setBackupError(res.error || 'Restore failed.');
      }
    } catch (e: any) {
      setBackupError(e.message || 'Restore failed.');
    } finally {
      setIsBackingUp(false);
    }
  };

  const rolesList: Array<{ role: UserRole; title: string; description: string; permissions: string[] }> = [
    {
      role: 'owner',
      title: 'Business Owner',
      description: 'Complete unrestricted access to company financial records, tax settings, staff management, and ledgers.',
      permissions: ['Full business setup', 'Financial P&L statements', 'Cost of goods & profit margins', 'Data backup & restoration']
    },
    {
      role: 'admin',
      title: 'Administrator',
      description: 'Operations director with broad permissions over catalog, orders, and expenses.',
      permissions: ['Manage orders & fulfillments', 'Stock receipts & POs', 'Operational expenses', 'Customer management']
    },
    {
      role: 'sales',
      title: 'Sales & Delivery Staff',
      description: 'Frontline staff processing sales orders, customer deliveries, and logging order payments.',
      permissions: ['Create customer orders', 'Issue invoices', 'Record customer payments', 'Restricted from viewing profit margins']
    },
    {
      role: 'inventory',
      title: 'Inventory & Warehouse Staff',
      description: 'Logistics personnel managing stock receipts, damaged goods adjustments, and catalog items.',
      permissions: ['Receive supplier shipments', 'Adjust stock levels', 'Audit low inventory', 'Restricted from financial accounts']
    },
    {
      role: 'accountant',
      title: 'Accountant / Auditor',
      description: 'Financial professional reconciling cash flow ledgers, tax filings, and P&L statements.',
      permissions: ['Authoritative cash ledger', 'Accounts receivable / payable', 'Balance reconciliation', 'Financial tax reports']
    },
    {
      role: 'viewer',
      title: 'Auditor / Read-Only Viewer',
      description: 'Read-only visibility for external investors, tax auditors, or legal advisors.',
      permissions: ['View records without edit rights', 'Export compliance reports', 'Audit logs review']
    }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          Business Setup & Preferences
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          Configure business identity, default currency, tax rules, staff roles, and manage secure data backups.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (8 cols): Business Settings Form */}
        <div className="lg:col-span-8 space-y-6">
          <form onSubmit={handleSave} className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Company Profile & Localization
                </h3>
              </div>
              {saveSuccess && (
                <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Settings Saved
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Business Name *</label>
                <input
                  type="text"
                  required
                  value={formSettings.businessName}
                  onChange={(e) => setFormSettings({ ...formSettings, businessName: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Business Category</label>
                <input
                  type="text"
                  value={formSettings.businessCategory}
                  onChange={(e) => setFormSettings({ ...formSettings, businessCategory: e.target.value })}
                  placeholder="e.g. Retail, Fashion, Electronics, Food"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Operating Country</label>
                <input
                  type="text"
                  value={formSettings.country}
                  onChange={(e) => setFormSettings({ ...formSettings, country: e.target.value })}
                  placeholder="e.g. Bangladesh, USA, UK, India"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              {/* Currency Selector */}
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1 font-bold">
                  Primary Functional Currency *
                </label>
                <select
                  value={formSettings.currency}
                  onChange={(e) => setFormSettings({ ...formSettings, currency: e.target.value as CurrencyCode })}
                  className="w-full px-3 py-2 font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
                >
                  {Object.values(CURRENCY_CONFIGS).map(curr => (
                    <option key={curr.code} value={curr.code}>
                      {curr.code} ({curr.symbol}) — {curr.name}
                    </option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-400 block mt-1">
                  Default configuration supports Bangladeshi Taka (৳ BDT) alongside international currencies.
                </span>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Time Zone</label>
                <input
                  type="text"
                  value={formSettings.timezone}
                  onChange={(e) => setFormSettings({ ...formSettings, timezone: e.target.value })}
                  placeholder="Asia/Dhaka, America/New_York, UTC"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Contact Email</label>
                <input
                  type="email"
                  value={formSettings.contactEmail}
                  onChange={(e) => setFormSettings({ ...formSettings, contactEmail: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={formSettings.contactPhone}
                  onChange={(e) => setFormSettings({ ...formSettings, contactPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Store / Warehouse Address</label>
                <input
                  type="text"
                  value={formSettings.address}
                  onChange={(e) => setFormSettings({ ...formSettings, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Inventory & Tax Policy Settings */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <h4 className="font-bold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
                Inventory & Accounting Rules
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="sm:col-span-2 space-y-2">
                  <label className="text-slate-600 dark:text-slate-400 block font-medium">
                    Inventory Valuation & Costing Method
                  </label>
                  <select
                    value={formSettings.inventoryValuationMethod}
                    onChange={(e) => setFormSettings({ ...formSettings, inventoryValuationMethod: e.target.value as any })}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer font-medium"
                  >
                    <option value="FIFO">FIFO — First In, First Out (Recommended / Global Standard)</option>
                    <option value="LIFO">LIFO — Last In, First Out (Tax Management / US GAAP Standard)</option>
                    <option value="WAC">WAC — Weighted Average Cost (Blended Moving Average)</option>
                  </select>
                  
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-[11px] space-y-1 text-slate-600 dark:text-slate-300">
                    {formSettings.inventoryValuationMethod === 'FIFO' && (
                      <p>
                        <strong className="text-emerald-700 dark:text-emerald-400">FIFO Active:</strong> Oldest stock units purchased are assumed sold first. Warehouse ending inventory on your balance sheet reflects the most recent purchase prices.
                      </p>
                    )}
                    {formSettings.inventoryValuationMethod === 'LIFO' && (
                      <p>
                        <strong className="text-blue-700 dark:text-blue-400">LIFO Active:</strong> Newest stock units purchased are assumed sold first. Older base cost layers remain in warehouse inventory. In rising price periods, this increases recognized COGS and reduces taxable income.
                      </p>
                    )}
                    {formSettings.inventoryValuationMethod === 'WAC' && (
                      <p>
                        <strong className="text-purple-700 dark:text-purple-400">WAC Active:</strong> Inventory units are valued at the cumulative weighted average cost per unit across all purchase batches.
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">
                    Invoice Number Prefix
                  </label>
                  <input
                    type="text"
                    value={formSettings.invoicePrefix}
                    onChange={(e) => setFormSettings({ ...formSettings, invoicePrefix: e.target.value })}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2 space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formSettings.allowNegativeStock}
                      onChange={(e) => setFormSettings({ ...formSettings, allowNegativeStock: e.target.checked })}
                    />
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      Permit Negative Inventory Balances (Not recommended — triggers warnings)
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formSettings.taxEnabled}
                      onChange={(e) => setFormSettings({ ...formSettings, taxEnabled: e.target.checked })}
                    />
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      Enable Value Added Tax / Sales Tax
                    </span>
                  </label>

                  {/* I8: the rate is now actually editable (it was display-only before) */}
                  <div className="flex items-center gap-2 pl-6">
                    <label className="text-slate-500">Tax rate %:</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step="any"
                      value={formSettings.taxRatePercent}
                      onChange={(e) => setFormSettings({ ...formSettings, taxRatePercent: Math.max(0, parseFloat(e.target.value) || 0) })}
                      className="w-24 px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers"
                    />
                    <span className="text-[11px] text-slate-400">
                      Applied as (subtotal − discount) × rate on every new order when enabled.
                    </span>
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">
                    Invoice Terms & Notes Footer
                  </label>
                  <textarea
                    rows={2}
                    value={formSettings.invoiceNotes}
                    onChange={(e) => setFormSettings({ ...formSettings, invoiceNotes: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="submit"
                disabled={!can('settings.update')}
                title={can('settings.update') ? 'Save business profile' : 'Your role cannot change business settings'}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl shadow-xs transition cursor-pointer text-xs disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Save Business Profile
              </button>
            </div>
          </form>

          {/* Role Permissions Simulator Matrix */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Multi-User Roles & Permissions Simulator
                </h3>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Active: {user.role.toUpperCase()}
              </span>
            </div>

            <p className="text-xs text-slate-500">
              Switch roles instantly to preview how staff members (Sales, Warehouse, Accountant) see MicroBiz Manager.
              <span className="block mt-1 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                Preview only — tab visibility here is simulated too. All write permissions and the Team tab
                always follow your real signed-in account's role, never this simulator.
              </span>
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {rolesList.map(item => (
                <div
                  key={item.role}
                  onClick={() => setUserRole(item.role)}
                  className={`p-3.5 rounded-2xl border text-xs cursor-pointer transition ${
                    user.role === item.role
                      ? 'bg-indigo-50/60 dark:bg-indigo-950/30 border-indigo-500 ring-2 ring-indigo-500/20'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900 dark:text-white">{item.title}</span>
                    {user.role === item.role && (
                      <span className="text-[10px] font-bold text-indigo-600">Simulating</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed mb-2">{item.description}</p>
                  <ul className="space-y-0.5 text-[10px] text-slate-600 dark:text-slate-400">
                    {item.permissions.map((p, idx) => (
                      <li key={idx} className="flex items-center gap-1">
                        <span className="text-emerald-500">✓</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Security, Backup, Audit Logs & Reset */}
        <div className="lg:col-span-4 space-y-6">
          {/* Account Security & Authentication Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Account & Security
                </h3>
              </div>
              {currentUser?.twoFactorEnabled ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                  2FA Active
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                  Standard Auth
                </span>
              )}
            </div>

            {currentUser && (
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div className="font-semibold text-slate-900 dark:text-white">{currentUser.name}</div>
                  <div className="text-[11px] text-slate-500 truncate">{currentUser.email}</div>
                  <div className="flex items-center gap-2 mt-2">
                    {isEmailVerified ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="w-3 h-3" /> Email Verified
                      </span>
                    ) : (
                      <button
                        onClick={() => openAuthModal('verify_email')}
                        className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 hover:underline cursor-pointer"
                      >
                        <AlertTriangle className="w-3 h-3" /> Verify Email Now
                      </button>
                    )}
                    <span className="text-slate-300 dark:text-slate-700">•</span>
                    <span className="text-[10px] text-slate-400">
                      {allSessions.length} active session{allSessions.length === 1 ? '' : 's'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={openSecuritySettings}
                    className="py-2 px-3 rounded-xl text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>2FA & Sessions</span>
                  </button>

                  <button
                    onClick={openSecuritySettings}
                    className="py-2 px-3 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Password</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Data Backup & Restore Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Data Portability & Backup
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export all business transactions, products, customer balances, ledger entries, audit logs, and user
              accounts into a password-encrypted backup file (AES-GCM, PBKDF2 key derivation).
            </p>

            {backupError && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-[11px] text-rose-700 dark:text-rose-300">
                {backupError}
              </div>
            )}

            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="password"
                  value={backupPassword}
                  onChange={(e) => setBackupPassword(e.target.value)}
                  placeholder="Backup password (8+ chars)"
                  className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <input
                  type="password"
                  value={backupPasswordConfirm}
                  onChange={(e) => setBackupPasswordConfirm(e.target.value)}
                  placeholder="Confirm password"
                  className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                onClick={handleDownloadBackup}
                disabled={isBackingUp}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-4 h-4" />
                <span>{isBackingUp ? 'Encrypting…' : 'Download Encrypted Backup'}</span>
              </button>

              <button
                onClick={() => setIsImportModalOpen(true)}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Restore from Encrypted Backup</span>
              </button>

              <button
                onClick={() => setConfirmResetDemo(true)}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-800/60 hover:bg-rose-100 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset to Clean Demo Store</span>
              </button>
            </div>
          </div>

          {/* Audit Trail Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Immutable Audit Trail
              </h3>
            </div>
            <p className="text-[11px] text-slate-400">
              Last {Math.min(5, auditLogs.length)} security & financial ledger actions:
            </p>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {auditLogs.slice(0, 5).map(log => (
                <div key={log.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-[11px]">
                  <div className="flex justify-between font-semibold text-slate-800 dark:text-slate-200">
                    <span>{log.action}</span>
                    <span className="text-slate-400 font-mono-numbers">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="text-slate-500 mt-0.5 truncate">{log.details}</div>
                  <div className="text-[9px] text-slate-400 mt-1">Logged by {log.user}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Restore JSON Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...importModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...importModal.panelProps}>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Restore Encrypted Backup
            </h3>
            <p className="text-[11px] text-slate-500">
              Paste the encrypted backup content and enter its password. The schema is validated before
              anything is overwritten; mismatches are rejected with an error.
            </p>
            <input
              type="password"
              value={importPassword}
              onChange={(e) => setImportPassword(e.target.value)}
              placeholder="Backup password"
              className="w-full p-3 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
            <textarea
              rows={8}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder="Paste encrypted backup content here..."
              className="w-full p-3 font-mono text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsImportModalOpen(false)}
                className="px-4 py-2 text-xs text-slate-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleImportSubmit}
                disabled={isBackingUp}
                className="px-5 py-2 text-xs bg-emerald-600 text-white font-semibold rounded-xl disabled:opacity-50"
              >
                {isBackingUp ? 'Decrypting…' : 'Restore Database'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset-to-demo confirmation */}
      <ConfirmDialog
        isOpen={confirmResetDemo}
        title="Reset to demo store?"
        message="Reset the store back to the verified demo dataset? Your current data will be overwritten. This cannot be undone."
        confirmLabel="Reset data"
        onConfirm={() => {
          resetToSampleData();
          setConfirmResetDemo(false);
        }}
        onCancel={() => setConfirmResetDemo(false)}
      />
    </div>
  );
};
