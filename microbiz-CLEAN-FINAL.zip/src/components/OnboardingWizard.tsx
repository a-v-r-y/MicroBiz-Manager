import React, { useState } from 'react';
import { Store, Settings2, Rocket, ArrowRight, ArrowLeft, Database, Sparkles, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useNotifications } from '../context/NotificationContext';
import { CURRENCY_CONFIGS } from '../utils/calculations';
import { useModalBehavior } from '../hooks/useModalBehavior';

const BUSINESS_CATEGORIES = [
  'Retail & Social Commerce',
  'Fashion & Apparel',
  'Food & Beverage',
  'Grocery & Daily Needs',
  'Electronics & Gadgets',
  'Health & Beauty',
  'Wholesale & Distribution',
  'Manufacturing',
  'Services',
  'Other',
];

const COMMON_TIMEZONES = [
  'Asia/Dhaka',
  'Asia/Kolkata',
  'Asia/Dubai',
  'Asia/Singapore',
  'UTC',
  'Europe/London',
  'America/New_York',
];

const inputCls =
  'w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500';
const labelCls = 'block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1';

/**
 * First-run onboarding wizard. Shown once (BusinessSettings.onboardingCompleted)
 * to newly registered owners. Escape / "Skip for now" dismisses it permanently.
 */
export const OnboardingWizard: React.FC = () => {
  const { settings, updateSettings, resetToSampleData, clearAllData, products, orders, customers } = useApp();
  const { pushNotification } = useNotifications();
  const [step, setStep] = useState(0);
  const [confirmWipe, setConfirmWipe] = useState(false);

  const [businessName, setBusinessName] = useState(settings.businessName || '');
  const [businessCategory, setBusinessCategory] = useState(settings.businessCategory || BUSINESS_CATEGORIES[0]);
  const [contactPhone, setContactPhone] = useState(settings.contactPhone || '');
  const [address, setAddress] = useState(settings.address || '');
  const [currency, setCurrency] = useState(settings.currency || 'BDT');
  const [taxEnabled, setTaxEnabled] = useState(settings.taxEnabled);
  const [taxRatePercent, setTaxRatePercent] = useState(settings.taxRatePercent ?? 0);
  const [timezone, setTimezone] = useState(settings.timezone || 'Asia/Dhaka');
  const [stepError, setStepError] = useState('');

  const hasRealData = products.length > 0 || orders.length > 0 || customers.length > 0;

  const { backdropProps, panelProps } = useModalBehavior(true, handleSkip, 'Business setup wizard');

  function persistAndFinish(extra: Record<string, unknown>, welcomeMessage: string) {
    updateSettings({
      businessName: businessName.trim(),
      businessCategory,
      contactPhone: contactPhone.trim(),
      address: address.trim(),
      currency,
      taxEnabled,
      taxRatePercent: Number(taxRatePercent) || 0,
      timezone: timezone.trim() || 'Asia/Dhaka',
      onboardingCompleted: true,
      ...extra,
    } as never);
    pushNotification({
      type: 'system_update',
      title: `Welcome to MicroBiz Manager, ${businessName.trim() || 'owner'}!`,
      message: welcomeMessage,
      priority: 'success',
      category: 'system',
      targetTab: 'dashboard',
      actionLabel: 'Open dashboard',
    });
  }

  function handleSkip() {
    updateSettings({ onboardingCompleted: true } as never);
  }

  function handleContinue() {
    setStepError('');
    if (step === 0) {
      if (!businessName.trim()) {
        setStepError('Please give your business a name to continue.');
        return;
      }
      setStep(1);
    } else if (step === 1) {
      setStep(2);
    }
  }

  function handleExploreSample() {
    if (hasRealData && !confirmWipe) {
      setConfirmWipe(true);
      return;
    }
    resetToSampleData();
    persistAndFinish(
      {},
      'Sample store data is loaded. Explore freely — use Settings to reset or wipe it any time.'
    );
  }

  function handleStartFresh() {
    clearAllData();
    persistAndFinish(
      {
        businessName: businessName.trim(),
        businessCategory,
        contactPhone: contactPhone.trim(),
        address: address.trim(),
        currency,
        taxEnabled,
        taxRatePercent: Number(taxRatePercent) || 0,
        timezone: timezone.trim() || 'Asia/Dhaka',
      },
      'You are starting with a clean slate. Add your first product to begin.'
    );
  }

  const steps = [
    { icon: Store, label: 'Business profile' },
    { icon: Settings2, label: 'Preferences' },
    { icon: Rocket, label: 'Get started' },
  ];

  return (
    <div
      className="fixed inset-0 z-[60] overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
      {...backdropProps}
    >
      <div
        className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl"
        {...panelProps}
      >
        {/* Progress */}
        <div className="flex items-center gap-2 mb-6">
          {steps.map((s, i) => {
            const Icon = s.icon;
            const active = i === step;
            const done = i < step;
            return (
              <React.Fragment key={s.label}>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition ${
                      done
                        ? 'bg-emerald-600 text-white'
                        : active
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/40'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    {done ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                  </div>
                  <span
                    className={`text-[11px] font-semibold hidden sm:block ${
                      active ? 'text-slate-900 dark:text-white' : 'text-slate-400'
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
                {i < steps.length - 1 && <div className="flex-1 h-px bg-slate-200 dark:bg-slate-700" />}
              </React.Fragment>
            );
          })}
        </div>

        {step === 0 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Tell us about your business</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                This appears on invoices, reports, and your dashboard.
              </p>
            </div>
            <div>
              <label className={labelCls}>Business name *</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Rahim Traders"
                className={inputCls}
              />
            </div>
            <div>
              <label className={labelCls}>Category</label>
              <select value={businessCategory} onChange={(e) => setBusinessCategory(e.target.value)} className={inputCls}>
                {BUSINESS_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>Phone</label>
                <input
                  type="tel"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="+880 1XXX-XXXXXX"
                  className={inputCls}
                />
              </div>
              <div>
                <label className={labelCls}>Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Shop address"
                  className={inputCls}
                />
              </div>
            </div>
            {stepError && <p className="text-xs font-medium text-rose-600 dark:text-rose-400">{stepError}</p>}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Money preferences</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                You can change these any time in Settings.
              </p>
            </div>
            <div>
              <label className={labelCls}>Currency</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as never)}
                className={inputCls}
              >
                {Object.values(CURRENCY_CONFIGS).map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.symbol} — {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Charge tax on orders</div>
                <div className="text-[11px] text-slate-400">Applied automatically at checkout</div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={taxEnabled}
                onClick={() => setTaxEnabled((v) => !v)}
                className={`w-11 h-6 rounded-full transition relative cursor-pointer ${
                  taxEnabled ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${
                    taxEnabled ? 'left-[22px]' : 'left-0.5'
                  }`}
                />
              </button>
            </div>
            {taxEnabled && (
              <div>
                <label className={labelCls}>Tax rate %</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  step={0.1}
                  value={taxRatePercent}
                  onChange={(e) => setTaxRatePercent(Number(e.target.value))}
                  className={inputCls}
                />
              </div>
            )}
            <div>
              <label className={labelCls}>Timezone</label>
              <input
                type="text"
                list="onboarding-timezones"
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                placeholder="Asia/Dhaka"
                className={inputCls}
              />
              <datalist id="onboarding-timezones">
                {COMMON_TIMEZONES.map((tz) => (
                  <option key={tz} value={tz} />
                ))}
              </datalist>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">How do you want to start?</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Pick the path that suits you — you can reset or wipe data later in Settings.
              </p>
            </div>
            <button
              onClick={handleExploreSample}
              className="w-full p-4 rounded-2xl border-2 border-emerald-200 dark:border-emerald-800 bg-emerald-50/60 dark:bg-emerald-950/30 hover:border-emerald-500 transition text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-600 text-white shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">Explore with sample data</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    A demo store with products, orders & expenses so you can try every feature.
                  </div>
                </div>
              </div>
            </button>
            {confirmWipe && hasRealData && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs">
                <p className="font-semibold text-rose-700 dark:text-rose-300">
                  This will replace your current data with the sample dataset.
                </p>
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={handleExploreSample}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Yes, replace my data
                  </button>
                  <button
                    onClick={() => setConfirmWipe(false)}
                    className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer"
                  >
                    Keep my data
                  </button>
                </div>
              </div>
            )}
            <button
              onClick={handleStartFresh}
              className="w-full p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-500 transition text-left cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">Start fresh</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    Empty shelves — add your own products, customers, and orders.
                  </div>
                </div>
              </div>
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between mt-8 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={handleSkip}
            className="text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer"
          >
            Skip for now
          </button>
          <div className="flex gap-2">
            {step > 0 && (
              <button
                onClick={() => { setStepError(''); setStep(step - 1); }}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back
              </button>
            )}
            {step < 2 && (
              <button
                onClick={handleContinue}
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
              >
                Continue <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
