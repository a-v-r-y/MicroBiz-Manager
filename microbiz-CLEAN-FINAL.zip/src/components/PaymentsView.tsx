import React, { useState } from 'react';
import { 
  WalletCards, 
  ArrowRightLeft, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Smartphone, 
  Banknote, 
  Info, 
  X,
  CreditCard,
  DollarSign
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { FinancialAccount, CashTransaction } from '../types';
import { formatCurrency } from '../utils/calculations';
import { useModalBehavior } from '../hooks/useModalBehavior';

export const PaymentsView: React.FC = () => {
  const { 
    accounts, 
    transactions, 
    settings, 
    addAccount, 
    transferFunds, 
    reconcileTransaction 
  } = useApp();
  const { can } = useAuth();

  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);
  const [transferError, setTransferError] = useState('');
  const [accountError, setAccountError] = useState('');

  const closeTransferModal = () => {
    setIsTransferModalOpen(false);
    setTransferError('');
    setTransferAmount(0);
    setTransferFee(0);
    setTransferDesc('');
  };
  const closeAddAccountModal = () => {
    setIsAddAccountOpen(false);
    setAccountError('');
    setNewAccName('');
    setNewAccNumber('');
    setNewAccInstitution('');
    setNewAccBalance(0);
  };

  const transferModal = useModalBehavior(isTransferModalOpen, closeTransferModal, 'Transfer funds');
  const addAccountModal = useModalBehavior(isAddAccountOpen, closeAddAccountModal, 'Add financial account');

  // Transfer Form State
  const [fromAccId, setFromAccId] = useState(accounts[0]?.id || '');
  const [toAccId, setToAccId] = useState(accounts[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState<number>(0);
  const [transferFee, setTransferFee] = useState<number>(0);
  const [transferDesc, setTransferDesc] = useState('');

  // Add Account Form State
  const [newAccName, setNewAccName] = useState('');
  const [newAccType, setNewAccType] = useState<'cash' | 'bank' | 'mobile_wallet'>('bank');
  const [newAccNumber, setNewAccNumber] = useState('');
  const [newAccInstitution, setNewAccInstitution] = useState('');
  const [newAccBalance, setNewAccBalance] = useState<number>(0);

  // Cash Flow Calculations
  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);

  const totalInflow = transactions
    .filter(t => ['customer_payment', 'owner_contribution', 'loan_in'].includes(t.type))
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOutflow = transactions
    .filter(t => ['supplier_payment', 'expense', 'owner_draw', 'loan_repay', 'refund'].includes(t.type))
    .reduce((sum, t) => sum + t.amount + (t.fee || 0), 0);

  const totalTransfers = transactions
    .filter(t => t.type === 'transfer')
    .reduce((sum, t) => sum + t.amount, 0);

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (transferAmount <= 0) {
      setTransferError('Transfer amount must be greater than zero.');
      return;
    }
    setTransferError('');
    const success = transferFunds(fromAccId, toAccId, transferAmount, transferFee, transferDesc);
    if (success) {
      closeTransferModal();
    } else {
      setTransferError('Transfer failed. Check balances and accounts, then try again.');
    }
  };

  const handleAddAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccName.trim()) {
      setAccountError('Account name is required.');
      return;
    }
    setAccountError('');

    addAccount({
      name: newAccName.trim(),
      type: newAccType,
      accountNumber: newAccNumber || undefined,
      institution: newAccInstitution || undefined,
      balance: newAccBalance,
      currency: settings.currency,
      isDefault: accounts.length === 0
    });

    closeAddAccountModal();
  };

  const getAccountIcon = (type: FinancialAccount['type']) => {
    switch (type) {
      case 'bank':
        return <Building2 className="w-4 h-4 text-blue-600" />;
      case 'mobile_wallet':
        return <Smartphone className="w-4 h-4 text-emerald-600" />;
      case 'cash':
      default:
        return <Banknote className="w-4 h-4 text-amber-600" />;
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Payments, Accounts & Cash Flow
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Manage physical petty cash, bank checking accounts, and mobile wallets (bKash/Nagad). Neutral double-entry transfers and reconciliation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAddAccountOpen(true)}
            disabled={!can('accounts.manage')}
            title={can('accounts.manage') ? 'Add a business account' : 'Your role cannot manage accounts'}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
            Add Business Account
          </button>
          <button
            onClick={() => setIsTransferModalOpen(true)}
            disabled={!can('accounts.transfer')}
            title={can('accounts.transfer') ? 'Transfer funds between accounts' : 'Your role cannot transfer funds'}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ArrowRightLeft className="w-4 h-4" />
            Transfer Funds
          </button>
        </div>
      </div>

      {/* Cash Flow Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Available Cash</span>
          <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(totalBalance, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Across {accounts.length} business accounts</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Cash Inflows</span>
          <div className="text-xl font-bold font-mono-numbers text-emerald-600">
            +{formatCurrency(totalInflow, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Order collections & capital in</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Total Cash Outflows</span>
          <div className="text-xl font-bold font-mono-numbers text-rose-600">
            -{formatCurrency(totalOutflow, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Suppliers, expenses & refunds</span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 block mb-1">Internal Transfers</span>
          <div className="text-xl font-bold font-mono-numbers text-blue-600">
            {formatCurrency(totalTransfers, settings.currency)}
          </div>
          <span className="text-[10px] text-slate-400">Neutral to profit/loss</span>
        </div>
      </div>

      {/* Account Cards Grid */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
          Business Accounts & Balances
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {accounts.map(acc => (
            <div 
              key={acc.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between space-y-4"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                    {getAccountIcon(acc.type)}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">{acc.name}</h4>
                    <p className="text-[11px] text-slate-400 capitalize">{acc.type.replace('_', ' ')}</p>
                  </div>
                </div>

                {acc.isDefault && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    Primary
                  </span>
                )}
              </div>

              <div>
                <div className="text-2xl font-bold font-mono-numbers text-slate-900 dark:text-white">
                  {formatCurrency(acc.balance, settings.currency)}
                </div>
                {acc.accountNumber && (
                  <p className="text-[10px] text-slate-400 font-mono-numbers mt-1">
                    A/C: {acc.accountNumber} {acc.institution ? `(${acc.institution})` : ''}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Educational Callout: Profit vs Cash */}
      <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 text-xs space-y-2">
        <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-300">
          <Info className="w-4 h-4 text-amber-600" />
          <span>Accounting Principle: Why a Profitable Business Can Face Cash Shortages</span>
        </div>
        <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
          Recognizing a profitable order on the P&L statement does not instantly put cash in your bank account if the delivery is still in transit (Cash on Delivery) or customer credit is unpaid. Furthermore, acquiring large bulk inventory ties up liquidity in stock assets before they sell. MicroBiz Manager keeps accounting profit and actual cash movement strictly transparent.
        </p>
      </div>

      {/* Cash Transactions Ledger */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden space-y-3 p-5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Authoritative Cash Movement Ledger
          </h3>
          <span className="text-xs text-slate-400">{transactions.length} records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
              <tr>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Transaction Description</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Reference</th>
                <th className="py-2.5 px-3 text-right">Amount</th>
                <th className="py-2.5 px-3 text-center">Reconciled</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center">
                    <p className="text-slate-400 text-xs">No cash transactions recorded yet.</p>
                    <button
                      onClick={() => setIsTransferModalOpen(true)}
                      className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                    >
                      Record your first transfer
                    </button>
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => {
                  const isInflow = ['customer_payment', 'owner_contribution', 'loan_in'].includes(tx.type);
                  const isTransfer = tx.type === 'transfer';

                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3 px-3 text-slate-500 font-mono-numbers">
                        {new Date(tx.date).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-3 font-medium text-slate-800 dark:text-slate-200">
                        {tx.description}
                      </td>

                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isInflow
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                            : isTransfer
                            ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                        }`}>
                          {tx.type.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>

                      <td className="py-3 px-3 font-mono-numbers text-slate-500">
                        {tx.reference || '-'}
                      </td>

                      <td className="py-3 px-3 text-right font-bold font-mono-numbers">
                        <span className={
                          isInflow ? 'text-emerald-600' : isTransfer ? 'text-blue-600' : 'text-rose-600'
                        }>
                          {isInflow ? '+' : isTransfer ? '' : '-'}{formatCurrency(tx.amount, settings.currency)}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => reconcileTransaction(tx.id)}
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                            tx.isReconciled
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
                          }`}
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          {tx.isReconciled ? 'Reconciled' : 'Pending'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transfer Funds Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...transferModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...transferModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Internal Account Transfer
              </h3>
              <button onClick={closeTransferModal} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleTransferSubmit} className="space-y-4 text-xs">
              {transferError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {transferError}
                </p>
              )}
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Transfer From Account *</label>
                <select
                  value={fromAccId}
                  onChange={(e) => setFromAccId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} (Balance: {formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Transfer To Account *</label>
                <select
                  value={toAccId}
                  onChange={(e) => setToAccId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} (Balance: {formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">
                  Amount to Transfer ({settings.currency}) *
                </label>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={transferAmount || ''}
                  onChange={(e) => setTransferAmount(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 10000"
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Transfer Fee (if any)</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={transferFee}
                  onChange={(e) => setTransferFee(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 15"
                  className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Description / Notes</label>
                <input
                  type="text"
                  value={transferDesc}
                  onChange={(e) => setTransferDesc(e.target.value)}
                  placeholder="e.g. Sweep bKash earnings to BRAC bank"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={closeTransferModal}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Execute Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {isAddAccountOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...addAccountModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...addAccountModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Create Business Financial Account
              </h3>
              <button onClick={closeAddAccountModal} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddAccountSubmit} className="space-y-4 text-xs">
              {accountError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {accountError}
                </p>
              )}
              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Account Name *</label>
                <input
                  type="text"
                  required
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder="e.g. City Bank Checking or Nagad Merchant"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Account Type *</label>
                <select
                  value={newAccType}
                  onChange={(e) => setNewAccType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="bank">Bank Checking / Corporate Account</option>
                  <option value="mobile_wallet">Mobile Financial Service (bKash/Nagad/Rocket/Stripe)</option>
                  <option value="cash">Physical Cash in Drawer / Safe</option>
                </select>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Account Number / IBAN</label>
                <input
                  type="text"
                  value={newAccNumber}
                  onChange={(e) => setNewAccNumber(e.target.value)}
                  placeholder="e.g. 1501-2049-88001"
                  className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">Financial Institution</label>
                <input
                  type="text"
                  value={newAccInstitution}
                  onChange={(e) => setNewAccInstitution(e.target.value)}
                  placeholder="e.g. BRAC Bank PLC, bKash Ltd"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1">
                  Opening Balance ({settings.currency})
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={newAccBalance}
                  onChange={(e) => setNewAccBalance(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={closeAddAccountModal}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
