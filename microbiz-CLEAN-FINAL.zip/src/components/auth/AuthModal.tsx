import React, { useState, useEffect } from 'react';
import { 
  X, 
  Lock, 
  Mail, 
  User, 
  ShieldCheck, 
  Key, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Smartphone,
  ChevronLeft
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useModalBehavior } from '../../hooks/useModalBehavior';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    authModalView,
    closeAuthModal,
    openAuthModal,
    login,
    register,
    verify2FALogin,
    cancel2FALogin,
    requestPasswordReset,
    resetPassword,
    verifyEmail,
    sendVerificationEmail,
    currentUser,
    isAuthenticated,
    twoFactorPending,
    latestEmailNotice
  } = useAuth();

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  // Verification & reset code states
  const [code, setCode] = useState('');
  const [resetTokenOrCode, setResetTokenOrCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Status & feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Sync email from pending 2FA or currentUser
  useEffect(() => {
    if (twoFactorPending?.user?.email) {
      setEmail(twoFactorPending.user.email);
    } else if (currentUser?.email) {
      setEmail(currentUser.email);
    }
  }, [twoFactorPending, currentUser]);

  // Reset errors when view changes
  useEffect(() => {
    setErrorMessage('');
    setSuccessMessage('');
  }, [authModalView]);

  // Handle countdown timer for resending
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const { backdropProps, panelProps } = useModalBehavior(
    isAuthModalOpen,
    closeAuthModal,
    authModalView === 'login' ? 'Sign in' : authModalView === 'register' ? 'Create account' : 'Account security'
  );

  if (!isAuthModalOpen) return null;

  // Password strength calculation
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: '', color: 'bg-slate-200' };
    let score = 0;
    if (pass.length >= 8) score++;
    if (pass.length >= 12) score++;
    if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++;
    if (/\d/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    if (score <= 2) return { score, label: 'Weak', color: 'bg-rose-500' };
    if (score <= 4) return { score, label: 'Good', color: 'bg-amber-500' };
    return { score, label: 'Strong', color: 'bg-emerald-500' };
  };

  const passwordStrength = getPasswordStrength(password);

  // 1. Submit Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await login(email, password, rememberMe);
      if (!res.success) {
        setErrorMessage(res.error || 'Authentication failed.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Submit Register
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (password.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await register(name, email, password);
      if (!res.success) {
        setErrorMessage(res.error || 'Registration failed.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Submit 2FA Code
  const handle2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code) {
      setErrorMessage('Please enter the 6-digit code or backup code.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await verify2FALogin(code);
      if (!res.success) {
        setErrorMessage(res.error || 'Invalid two-factor code.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Verification error.');
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Request Password Reset
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMessage('Please enter your email address.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await requestPasswordReset(email);
      if (res.success) {
        setSuccessMessage(`Reset code sent to ${email}. Check your email.`);
        setTimeout(() => {
          openAuthModal('reset_password');
        }, 1200);
      } else {
        setErrorMessage(res.error || 'Failed to send reset code.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error requesting reset.');
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Submit Password Reset
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      setErrorMessage('New passwords do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await resetPassword(resetTokenOrCode, newPassword);
      if (res.success) {
        setSuccessMessage('Password reset successfully! You are now logged in.');
      } else {
        setErrorMessage(res.error || 'Failed to reset password.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Password reset error.');
    } finally {
      setIsLoading(false);
    }
  };

  // 6. Verify Email
  const handleVerifyEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await verifyEmail(code);
      if (res.success) {
        setSuccessMessage('Email verified successfully!');
      } else {
        setErrorMessage(res.error || 'Invalid or expired code.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Verification error.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerificationCode = async () => {
    if (resendCooldown > 0) return;
    try {
      const res = await sendVerificationEmail();
      if (res.success) {
        setResendCooldown(60);
        setSuccessMessage('Fresh verification code sent!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Quick fill code from mock notice
  const handleAutoFillNoticeCode = () => {
    if (latestEmailNotice?.code) {
      if (authModalView === 'verify_email') {
        setCode(latestEmailNotice.code);
      } else if (authModalView === 'reset_password') {
        setResetTokenOrCode(latestEmailNotice.code);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4" {...backdropProps}>
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-200" {...panelProps}>
        
        {/* Header bar */}
        <div className="flex items-center justify-between p-6 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-linear-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xs font-bold text-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {authModalView === 'login' && 'Sign in to MicroBiz'}
                {authModalView === 'register' && 'Create your Account'}
                {authModalView === 'two_factor' && 'Two-Factor Authentication'}
                {authModalView === 'forgot_password' && 'Reset your Password'}
                {authModalView === 'reset_password' && 'Set New Password'}
                {authModalView === 'verify_email' && 'Verify your Email'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {authModalView === 'login' && 'Enter your credentials to access business records'}
                {authModalView === 'register' && 'The first account created becomes the business owner'}
                {authModalView === 'two_factor' && 'Enter 6-digit TOTP code from your authenticator app'}
                {authModalView === 'forgot_password' && 'We will send a 6-digit recovery code to your email'}
                {authModalView === 'reset_password' && 'Enter verification code and choose a secure password'}
                {authModalView === 'verify_email' && `Enter code sent to ${currentUser?.email || email}`}
              </p>
            </div>
          </div>

          {/* Allow close button if user is already logged in */}
          {isAuthenticated && (
            <button
              onClick={closeAuthModal}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Status Alerts */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* 1. LOGIN VIEW */}
        {authModalView === 'login' && (
          <form onSubmit={handleLoginSubmit} className="p-6 space-y-4 text-xs">
            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@business.com"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-600 dark:text-slate-400 font-medium">Password</label>
                <button
                  type="button"
                  onClick={() => openAuthModal('forgot_password')}
                  className="text-emerald-600 dark:text-emerald-400 hover:underline text-[11px] font-semibold cursor-pointer"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-9 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-400">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Stay signed in for 30 days</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
              Sign In
            </button>

            <div className="text-center text-slate-500 text-[11px] pt-1">
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => openAuthModal('register')}
                className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
              >
                Create Account
              </button>
            </div>
          </form>
        )}

        {/* 2. REGISTER VIEW */}
        {authModalView === 'register' && (
          <form onSubmit={handleRegisterSubmit} className="p-6 space-y-3.5 text-xs">
            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Full Name *</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ayesha Rahman"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Email Address *</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ayesha@boutique.com"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Password (8+ chars) *</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create secure password"
                  className="w-full pl-9 pr-9 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Password strength meter */}
              {password && (
                <div className="mt-1.5 space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-slate-500">Security Strength:</span>
                    <span className="font-semibold">{passwordStrength.label}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex gap-1">
                    <div className={`h-full flex-1 rounded-full ${passwordStrength.score >= 1 ? passwordStrength.color : 'bg-slate-200 dark:bg-slate-700'}`} />
                    <div className={`h-full flex-1 rounded-full ${passwordStrength.score >= 3 ? passwordStrength.color : 'bg-slate-200 dark:bg-slate-700'}`} />
                    <div className={`h-full flex-1 rounded-full ${passwordStrength.score >= 5 ? passwordStrength.color : 'bg-slate-200 dark:bg-slate-700'}`} />
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Confirm Password *</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat password"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-2"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
              Create Business Account
            </button>

            <div className="text-center text-slate-500 text-[11px] pt-1">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
              >
                Sign In
              </button>
            </div>
          </form>
        )}

        {/* 3. TWO-FACTOR AUTHENTICATION CHALLENGE VIEW */}
        {authModalView === 'two_factor' && (
          <form onSubmit={handle2FASubmit} className="p-6 space-y-4 text-xs">
            <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-start gap-3">
              <Smartphone className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold text-slate-900 dark:text-white block">Authenticator Code Required</span>
                <p className="text-[11px] text-slate-600 dark:text-slate-300">
                  Open your Google Authenticator, Authy, or compatible 2FA app and enter the 6-digit verification code.
                </p>
              </div>
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">
                6-Digit TOTP Code or Backup Code
              </label>
              <input
                type="text"
                required
                autoFocus
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. 123456 or XXXX-XXXX"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-center font-mono-numbers text-base tracking-widest focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={cancel2FALogin}
                className="flex-1 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 transition cursor-pointer"
              >
                Back to Login
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-2 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                Verify & Login
              </button>
            </div>
          </form>
        )}

        {/* 4. FORGOT PASSWORD VIEW */}
        {authModalView === 'forgot_password' && (
          <form onSubmit={handleForgotPasswordSubmit} className="p-6 space-y-4 text-xs">
            <p className="text-slate-600 dark:text-slate-400">
              Enter your registered business email address. We will generate and dispatch a secure 6-digit password recovery code.
            </p>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Registered Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your-account@domain.com"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              Send Recovery Code
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="text-slate-500 hover:text-slate-900 dark:hover:text-white inline-flex items-center gap-1 text-[11px] cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> Back to Sign In
              </button>
            </div>
          </form>
        )}

        {/* 5. RESET PASSWORD VIEW */}
        {authModalView === 'reset_password' && (
          <form onSubmit={handleResetPasswordSubmit} className="p-6 space-y-3.5 text-xs">
            {latestEmailNotice?.code && (
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs">
                <span className="text-emerald-700 dark:text-emerald-300">
                  Received code: <strong>{latestEmailNotice.code}</strong>
                </span>
                <button
                  type="button"
                  onClick={handleAutoFillNoticeCode}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-600 text-white cursor-pointer"
                >
                  Insert Code
                </button>
              </div>
            )}

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">6-Digit Recovery Code *</label>
              <input
                type="text"
                required
                value={resetTokenOrCode}
                onChange={(e) => setResetTokenOrCode(e.target.value.trim())}
                placeholder="123456"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers text-center text-sm tracking-wider"
              />
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">New Password (8+ characters) *</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
              />
            </div>

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">Confirm New Password *</label>
              <input
                type="password"
                required
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
              Set New Password & Log In
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="text-slate-500 hover:text-slate-900 dark:hover:text-white text-[11px] cursor-pointer"
              >
                Cancel and return to Sign In
              </button>
            </div>
          </form>
        )}

        {/* 6. VERIFY EMAIL VIEW */}
        {authModalView === 'verify_email' && (
          <form onSubmit={handleVerifyEmailSubmit} className="p-6 space-y-4 text-xs">
            <p className="text-slate-600 dark:text-slate-400">
              We dispatched an activation code to <strong>{currentUser?.email || email}</strong>. Please enter the 6-digit code below to confirm ownership.
            </p>

            {latestEmailNotice?.code && (
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs">
                <span className="text-emerald-700 dark:text-emerald-300">
                  Inbox Code: <strong>{latestEmailNotice.code}</strong>
                </span>
                <button
                  type="button"
                  onClick={handleAutoFillNoticeCode}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-600 text-white cursor-pointer"
                >
                  Insert Code
                </button>
              </div>
            )}

            <div>
              <label className="text-slate-600 dark:text-slate-400 block mb-1 font-medium">6-Digit Verification Code</label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value.trim())}
                placeholder="123456"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers text-center text-base tracking-widest"
              />
            </div>

            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500">Didn't receive the email?</span>
              <button
                type="button"
                disabled={resendCooldown > 0}
                onClick={handleResendVerificationCode}
                className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline disabled:opacity-50 cursor-pointer"
              >
                {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend Code'}
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              Verify Account
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
