import React, { useState } from 'react';
import { LockKeyhole, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

/**
 * Forced password-change gate. Rendered by App.tsx instead of the main
 * layout when the signed-in user has `mustChangePassword` set (owner-issued
 * temporary passwords). The user cannot reach the app until they choose
 * their own password.
 */
export const ForceChangePassword: React.FC = () => {
  const { currentUser, changePassword, logout } = useAuth();
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (newPw !== confirmPw) {
      setError('The new passwords do not match.');
      return;
    }
    if (newPw === currentPw) {
      setError('Your new password must be different from the temporary one.');
      return;
    }
    setBusy(true);
    const res = await changePassword(currentPw, newPw);
    setBusy(false);
    if (!res.success) {
      setError(res.error || 'Could not change your password.');
    }
    // On success mustChangePasswordNow flips false and App renders the layout.
  };

  const firstName = currentUser?.name?.split(' ')[0] || 'there';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4">
      <form
        onSubmit={submit}
        className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-6 sm:p-8 space-y-4"
      >
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600">
            <LockKeyhole className="w-6 h-6" />
          </div>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">Set your own password</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Hi {firstName} — your owner gave you a temporary password. Choose a personal one
            to continue into MicroBiz Manager.
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-medium text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        <div className="space-y-3">
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Temporary password
            </label>
            <input
              type="password"
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              autoComplete="current-password"
              className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              New password
            </label>
            <input
              type="password"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              autoComplete="new-password"
              placeholder="Min. 8 characters"
              className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Confirm new password
            </label>
            <input
              type="password"
              value={confirmPw}
              onChange={(e) => setConfirmPw(e.target.value)}
              autoComplete="new-password"
              className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={busy}
          className="w-full py-2.5 rounded-xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition disabled:opacity-50 cursor-pointer"
        >
          {busy ? 'Saving…' : 'Set password & continue'}
        </button>

        <button
          type="button"
          onClick={logout}
          className="w-full inline-flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign in with a different account
        </button>
      </form>
    </div>
  );
};
