import React from 'react';
import { Mail, Key, ShieldCheck, X, Check, Copy } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const EmailNoticeToast: React.FC = () => {
  const { latestEmailNotice, dismissEmailNotice } = useAuth();
  const [copied, setCopied] = React.useState(false);

  if (!latestEmailNotice) return null;

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm w-full bg-white dark:bg-slate-900 border border-emerald-500/30 dark:border-emerald-500/30 rounded-2xl p-4 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-start justify-between gap-3">
        <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-200 dark:border-emerald-800">
          <Mail className="w-4 h-4" />
        </div>

        <div className="flex-1 text-xs">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="font-bold text-slate-900 dark:text-white">Email Notification Dispatched</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
              Mock Inbox
            </span>
          </div>

          <p className="text-slate-600 dark:text-slate-400 truncate mb-1">
            To: <span className="font-medium text-slate-900 dark:text-slate-200">{latestEmailNotice.toEmail}</span>
          </p>

          <p className="text-slate-700 dark:text-slate-300 font-medium">
            {latestEmailNotice.subject}
          </p>

          {latestEmailNotice.code && (
            <div className="mt-2 flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] text-slate-500">Security Code:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono-numbers font-bold text-sm text-emerald-600 dark:text-emerald-400 tracking-wider">
                  {latestEmailNotice.code}
                </span>
                <button
                  onClick={() => handleCopyCode(latestEmailNotice.code!)}
                  className="p-1 rounded text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                  title="Copy Code"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => dismissEmailNotice(latestEmailNotice.id)}
          className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
