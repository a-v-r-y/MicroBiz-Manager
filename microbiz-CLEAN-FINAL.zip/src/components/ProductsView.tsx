import React, { useState } from 'react';
import { 
  Package, 
  Search, 
  Plus, 
  Download, 
  Upload, 
  AlertTriangle, 
  Archive, 
  Edit, 
  CheckCircle, 
  X,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Product, ProductVariant } from '../types';
import { formatCurrency, roundToMinorUnits } from '../utils/calculations';
import { downloadCsv, parseCsv } from '../utils/csv';
import { useModalBehavior } from '../hooks/useModalBehavior';
import { ConfirmDialog } from './ConfirmDialog';
import { useNotifications } from '../context/NotificationContext';

export const ProductsView: React.FC = () => {
  const { products, suppliers, settings, addProduct, updateProduct, archiveProduct, bulkImportProducts } = useApp();
  const { can } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importCsvText, setImportCsvText] = useState('');
  const [formError, setFormError] = useState('');
  const [importError, setImportError] = useState('');
  const [pendingArchive, setPendingArchive] = useState<Product | null>(null);
  const { pushNotification } = useNotifications();

  const closeAddModal = () => {
    setIsAddModalOpen(false);
    setFormError('');
    setEditingProduct(null);
  };
  const closeImportModal = () => {
    setIsImportModalOpen(false);
    setImportError('');
    setImportCsvText('');
  };

  const addEditModal = useModalBehavior(isAddModalOpen, closeAddModal, editingProduct ? 'Edit product' : 'Add product');
  const importModal = useModalBehavior(isImportModalOpen, closeImportModal, 'Import products from CSV');

  // Form State
  const [formName, setFormName] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formCategory, setFormCategory] = useState('Clothing & Fashion');
  const [formBrand, setFormBrand] = useState('');
  const [formSupplierId, setFormSupplierId] = useState('');
  const [formCostPrice, setFormCostPrice] = useState(0);
  const [formSellingPrice, setFormSellingPrice] = useState(0);
  const [formWholesalePrice, setFormWholesalePrice] = useState(0);
  const [formStock, setFormStock] = useState(0);
  const [formMinAlert, setFormMinAlert] = useState(5);
  const [formUnit, setFormUnit] = useState('pcs');
  const [formDescription, setFormDescription] = useState('');

  // Categories list
  const categories = Array.from(new Set(products.map(p => p.category)));

  // Filter products
  const filteredProducts = products.filter(p => {
    if (p.status === 'archived') return false;
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.barcode && p.barcode.includes(searchQuery));
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const openAddModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormBarcode('');
    setFormCategory('Clothing & Fashion');
    setFormBrand('');
    setFormSupplierId(suppliers[0]?.id || '');
    setFormCostPrice(0);
    setFormSellingPrice(0);
    setFormWholesalePrice(0);
    setFormStock(0);
    setFormMinAlert(5);
    setFormUnit('pcs');
    setFormDescription('');
    setIsAddModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name);
    setFormSku(p.sku);
    setFormBarcode(p.barcode || '');
    setFormCategory(p.category);
    setFormBrand(p.brand);
    setFormSupplierId(p.supplierId || '');
    setFormCostPrice(p.costPrice);
    setFormSellingPrice(p.sellingPrice);
    setFormWholesalePrice(p.wholesalePrice || 0);
    setFormStock(p.stock);
    setFormMinAlert(p.minStockAlert);
    setFormUnit(p.unit);
    setFormDescription(p.description);
    setIsAddModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formName.trim() || !formSku.trim()) {
      setFormError('Product name and unique SKU are required.');
      return;
    }

    // Check SKU duplicate
    const skuExists = products.some(p => p.sku.toLowerCase() === formSku.trim().toLowerCase() && p.id !== editingProduct?.id);
    if (skuExists) {
      setFormError(`SKU "${formSku.trim()}" already exists. Each product must have a unique SKU.`);
      return;
    }
    setFormError('');

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: formName,
        sku: formSku,
        barcode: formBarcode,
        category: formCategory,
        brand: formBrand,
        supplierId: formSupplierId,
        costPrice: formCostPrice,
        sellingPrice: formSellingPrice,
        wholesalePrice: formWholesalePrice,
        stock: formStock,
        minStockAlert: formMinAlert,
        unit: formUnit,
        description: formDescription
      });
    } else {
      addProduct({
        name: formName,
        sku: formSku,
        barcode: formBarcode,
        category: formCategory,
        brand: formBrand,
        supplierId: formSupplierId,
        costPrice: formCostPrice,
        sellingPrice: formSellingPrice,
        wholesalePrice: formWholesalePrice,
        stock: formStock,
        minStockAlert: formMinAlert,
        unit: formUnit,
        description: formDescription,
        status: 'active',
        variants: []
      });
    }

    closeAddModal();
  };

  const handleExportCSV = () => {
    const headers = ['Name', 'SKU', 'Barcode', 'Category', 'Brand', 'Cost Price', 'Selling Price', 'Stock', 'Min Alert', 'Unit'];
    const rows = filteredProducts.map(p => [
      p.name,
      p.sku,
      p.barcode || '',
      p.category,
      p.brand,
      p.costPrice,
      p.sellingPrice,
      p.stock,
      p.minStockAlert,
      p.unit
    ]);
    // I7: proper serialization — fields with commas/quotes/newlines are quoted
    downloadCsv(`products_catalog_${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
  };

  const handleImportSubmit = () => {
    if (!importCsvText.trim()) return;
    // I7: proper parser — handles quoted fields, escaped quotes, embedded newlines
    const rows = parseCsv(importCsvText.trim());
    if (rows.length === 0) {
      setImportError('Could not parse any rows from the CSV input.');
      return;
    }
    setImportError('');

    let startIdx = 0;
    if (rows[0].some(cell => cell.toLowerCase().includes('name'))) startIdx = 1; // header row

    const existingBySku = new Map(products.map(p => [p.sku.trim().toLowerCase(), p]));
    const toAdd: Array<Omit<Product, 'id' | 'createdAt'>> = [];
    let added = 0, updated = 0, skipped = 0;

    for (let idx = startIdx; idx < rows.length; idx++) {
      const parts = rows[idx].map(s => s.trim());
      if (parts.length < 3 || !parts[0] || !parts[1]) { skipped++; continue; }
      const skuKey = parts[1].toLowerCase();
      const productData = {
        name: parts[0],
        sku: parts[1],
        barcode: parts[2] || '',
        category: parts[3] || 'General',
        brand: parts[4] || 'Generic',
        costPrice: parseFloat(parts[5]) || 0,
        sellingPrice: parseFloat(parts[6]) || 0,
        stock: parseInt(parts[7]) || 0,
        minStockAlert: parseInt(parts[8]) || 5,
        unit: parts[9] || 'pcs',
        description: '',
        status: 'active' as const,
        variants: []
      };
      const existing = existingBySku.get(skuKey);
      if (existing) {
        // I7: duplicate SKU — update the existing product instead of duplicating
        updateProduct(existing.id, {
          name: productData.name,
          barcode: productData.barcode,
          category: productData.category,
          brand: productData.brand,
          costPrice: productData.costPrice,
          sellingPrice: productData.sellingPrice,
          minStockAlert: productData.minStockAlert,
          unit: productData.unit
        });
        updated++;
      } else {
        toAdd.push(productData);
        existingBySku.set(skuKey, { ...productData, id: '', createdAt: '' } as Product);
        added++;
      }
    }

    if (toAdd.length > 0) bulkImportProducts(toAdd);
    closeImportModal();
    pushNotification({
      type: 'system_update',
      title: 'CSV import complete',
      message: `${added} new product(s) added, ${updated} existing SKU(s) updated${skipped > 0 ? `, ${skipped} row(s) skipped (invalid)` : ''}.`,
      priority: 'success',
      category: 'inventory',
      targetTab: 'products',
      actionLabel: 'View products',
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Product Catalog
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Manage product master data, variants, cost prices, selling margins, and inventory thresholds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsImportModalOpen(true)}
            disabled={!can('products.import')}
            title={can('products.import') ? 'Import products from CSV' : 'Your role cannot import products'}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            Import CSV
          </button>
          <button
            onClick={handleExportCSV}
            disabled={!can('reports.export')}
            title={can('reports.export') ? 'Export catalog to CSV' : 'Your role cannot export reports'}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={openAddModal}
            disabled={!can('products.create')}
            title={can('products.create') ? 'Add a new product' : 'Your role cannot create products'}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
            Add Product
          </button>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search products by Name, SKU, or Barcode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Product Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Products Table (desktop) / Cards (mobile) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto hidden sm:block">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
              <tr>
                <th className="py-3 px-4">Product & SKU</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Cost Price</th>
                <th className="py-3 px-4 text-right">Selling Price</th>
                <th className="py-3 px-4 text-right">Markup Margin</th>
                <th className="py-3 px-4 text-center">Current Stock</th>
                <th className="py-3 px-4 text-right">Inventory Value</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center">
                    <p className="text-slate-400 text-xs">No products found in this category.</p>
                    <button
                      onClick={openAddModal}
                      className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add your first product
                    </button>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => {
                  const profitMargin = product.sellingPrice > 0 
                    ? roundToMinorUnits(((product.sellingPrice - product.costPrice) / product.sellingPrice) * 100, 1) 
                    : 0;
                  const isMarginNegative = product.sellingPrice < product.costPrice;
                  const isLowStock = product.stock <= product.minStockAlert && product.stock > 0;
                  const isOutOfStock = product.stock <= 0;
                  const inventoryValuation = product.stock * product.costPrice;

                  return (
                    <tr key={product.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {product.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-numbers">
                          SKU: {product.sku} {product.barcode ? `| Barcode: ${product.barcode}` : ''}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[11px]">
                          {product.category}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers text-slate-600 dark:text-slate-400">
                        {formatCurrency(product.costPrice, settings.currency)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers font-semibold text-slate-900 dark:text-white">
                        {formatCurrency(product.sellingPrice, settings.currency)}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isMarginNegative
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                            : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                        }`}>
                          {profitMargin}%
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold font-mono-numbers ${
                          isOutOfStock 
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400' 
                            : isLowStock 
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400' 
                            : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                        }`}>
                          {isOutOfStock && <AlertTriangle className="w-3 h-3" />}
                          {product.stock} {product.unit}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers text-slate-700 dark:text-slate-300">
                        {formatCurrency(inventoryValuation, settings.currency)}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => openEditModal(product)}
                            disabled={!can('products.update')}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                            title={can('products.update') ? 'Edit Product' : 'Your role cannot edit products'}
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setPendingArchive(product)}
                            disabled={!can('products.delete')}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                            title={can('products.delete') ? 'Archive Product' : 'Your role cannot archive products'}
                          >
                            <Archive className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile card list */}
        <div className="sm:hidden divide-y divide-slate-100 dark:divide-slate-800">
          {filteredProducts.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-slate-400 text-xs">No products found in this category.</p>
              <button
                onClick={openAddModal}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add your first product
              </button>
            </div>
          ) : (
            filteredProducts.map((product) => {
              const isOutOfStock = product.stock <= 0;
              const isLowStock = product.stock <= product.minStockAlert && product.stock > 0;
              return (
                <div key={product.id} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 dark:text-white truncate">{product.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono-numbers mt-0.5">{product.sku} • {product.category}</div>
                    </div>
                    <span className={`shrink-0 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold font-mono-numbers ${
                      isOutOfStock
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                        : isLowStock
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
                        : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                    }`}>
                      {product.stock} {product.unit}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-sm font-bold font-mono-numbers text-slate-900 dark:text-white">
                      {formatCurrency(product.sellingPrice, settings.currency)}
                      <span className="ml-2 text-[10px] font-medium text-slate-400">
                        Cost {formatCurrency(product.costPrice, settings.currency)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => openEditModal(product)}
                        disabled={!can('products.update')}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                        aria-label={`Edit ${product.name}`}
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setPendingArchive(product)}
                        disabled={!can('products.delete')}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                        aria-label={`Archive ${product.name}`}
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...addEditModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8" {...addEditModal.panelProps}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h3>
              </div>
              <button
                onClick={closeAddModal}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
              {formError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {formError}
                </p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Leather Bifold Wallet"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Unique SKU *</label>
                  <input
                    type="text"
                    required
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    placeholder="e.g. WAL-LEA-01"
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Barcode / UPC</label>
                  <input
                    type="text"
                    value={formBarcode}
                    onChange={(e) => setFormBarcode(e.target.value)}
                    placeholder="e.g. 890123456789"
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Category</label>
                  <input
                    type="text"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    placeholder="e.g. Accessories"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Brand Name</label>
                  <input
                    type="text"
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    placeholder="e.g. Aura Wear"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Supplier</label>
                  <select
                    value={formSupplierId}
                    onChange={(e) => setFormSupplierId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="">None / Self Manufactured</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Unit of Measure</label>
                  <input
                    type="text"
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    placeholder="pcs, box, kg"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                {/* Pricing Fields */}
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">
                    Acquisition Cost ({settings.currency}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formCostPrice}
                    onChange={(e) => setFormCostPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">
                    Retail Selling Price ({settings.currency}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formSellingPrice}
                    onChange={(e) => setFormSellingPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                {/* Stock Controls */}
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Initial / Current Stock</label>
                  <input
                    type="number"
                    min="0"
                    value={formStock}
                    onChange={(e) => setFormStock(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1">Low Stock Alert Threshold</label>
                  <input
                    type="number"
                    min="0"
                    value={formMinAlert}
                    onChange={(e) => setFormMinAlert(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {formSellingPrice > 0 && formCostPrice > formSellingPrice && (
                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                  <span>
                    Warning: Selling price is lower than cost. You will lose margin on each unit sold.
                  </span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={closeAddModal}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white font-semibold rounded-xl shadow-xs"
                >
                  {editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CSV Bulk Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...importModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...importModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Bulk CSV Product Import
              </h3>
              <button onClick={closeImportModal} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Paste CSV text in the format: <br />
              <code className="text-[11px] bg-slate-100 dark:bg-slate-800 p-1 rounded font-mono block mt-1">
                Name,SKU,Barcode,Category,Brand,CostPrice,SellingPrice,Stock,MinAlert,Unit
              </code>
            </p>

            <textarea
              rows={6}
              value={importCsvText}
              onChange={(e) => setImportCsvText(e.target.value)}
              placeholder="e.g. Cotton Cap,CAP-01,89001,Accessories,Aura,150,350,20,5,pcs"
              className="w-full p-3 font-mono text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />

            {importError && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                {importError}
              </p>
            )}

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={closeImportModal}
                className="px-3 py-1.5 text-xs text-slate-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleImportSubmit}
                className="px-4 py-1.5 text-xs bg-emerald-600 text-white font-semibold rounded-xl"
              >
                Parse & Import
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Archive confirmation */}
      <ConfirmDialog
        isOpen={!!pendingArchive}
        title="Archive product?"
        message={
          pendingArchive
            ? `Archive "${pendingArchive.name}"? Past orders will remain intact. You can restore it later.`
            : ''
        }
        confirmLabel="Archive"
        onConfirm={() => {
          if (pendingArchive) archiveProduct(pendingArchive.id);
          setPendingArchive(null);
        }}
        onCancel={() => setPendingArchive(null)}
      />
    </div>
  );
};
