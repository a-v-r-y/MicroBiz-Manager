import React, { useState } from 'react';
import { 
  Calculator, 
  HelpCircle, 
  RotateCcw, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  DollarSign, 
  Info, 
  Layers, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, roundToMinorUnits } from '../utils/calculations';

interface ProfitCalculatorProps {
  onConvertToOrder?: (calculatorData: any) => void;
}

export const ProfitCalculatorView: React.FC<ProfitCalculatorProps> = ({ onConvertToOrder }) => {
  const { settings } = useApp();

  // Inputs
  const [productName, setProductName] = useState('Wireless ANC Noise-Canceling Earbuds Pro');
  const [unitCost, setUnitCost] = useState(3000);
  const [sellingPrice, setSellingPrice] = useState(4000);
  const [quantity, setQuantity] = useState(1);
  const [discount, setDiscount] = useState(100);
  const [deliveryChargeCollected, setDeliveryChargeCollected] = useState(150);
  const [actualDeliveryExpense, setActualDeliveryExpense] = useState(120);
  const [packagingExpense, setPackagingExpense] = useState(30);
  const [paymentFee, setPaymentFee] = useState(40);
  const [marketplaceCommissionRate, setMarketplaceCommissionRate] = useState(0); // in percent
  const [adCostAllocated, setAdCostAllocated] = useState(0);
  const [otherExpenses, setOtherExpenses] = useState(0);
  const [refundAmount, setRefundAmount] = useState(0);

  // Calculations
  const grossMerchandiseSales = roundToMinorUnits(sellingPrice * quantity);
  const totalDiscount = roundToMinorUnits(discount);
  const netMerchandiseSales = roundToMinorUnits(Math.max(0, grossMerchandiseSales - totalDiscount - refundAmount));
  const netRevenue = roundToMinorUnits(netMerchandiseSales + deliveryChargeCollected);
  const cogs = roundToMinorUnits(unitCost * quantity);
  const grossProfit = roundToMinorUnits(netMerchandiseSales - cogs);
  const grossMarginPercent = netMerchandiseSales > 0 ? roundToMinorUnits((grossProfit / netMerchandiseSales) * 100, 1) : 0;

  const commissionAmount = roundToMinorUnits((netMerchandiseSales * marketplaceCommissionRate) / 100);
  const totalDirectVariableCosts = roundToMinorUnits(
    actualDeliveryExpense + packagingExpense + paymentFee + commissionAmount + adCostAllocated + otherExpenses
  );

  const netOrderContribution = roundToMinorUnits(netRevenue - cogs - totalDirectVariableCosts);
  const contributionMarginPercent = netRevenue > 0 ? roundToMinorUnits((netOrderContribution / netRevenue) * 100, 1) : 0;

  // Delivery logistics spread
  const deliverySpread = roundToMinorUnits(deliveryChargeCollected - actualDeliveryExpense);

  // Cash movement: Customer paid (Net Sales + Delivery) minus immediate operational disbursements
  const customerCashIn = roundToMinorUnits(grossMerchandiseSales - totalDiscount + deliveryChargeCollected);
  const directDisbursements = roundToMinorUnits(actualDeliveryExpense + packagingExpense + paymentFee + commissionAmount + otherExpenses);
  const estimatedOrderCashMovement = roundToMinorUnits(customerCashIn - directDisbursements);

  // Quick preset loaders
  const loadSpecBenchmark = () => {
    setProductName('Specification Benchmark Earbuds');
    setUnitCost(3000);
    setSellingPrice(4000);
    setQuantity(1);
    setDiscount(100);
    setDeliveryChargeCollected(150);
    setActualDeliveryExpense(120);
    setPackagingExpense(30);
    setPaymentFee(40);
    setMarketplaceCommissionRate(0);
    setAdCostAllocated(0);
    setOtherExpenses(0);
    setRefundAmount(0);
  };

  const loadClothingPreset = () => {
    setProductName('Organic Cotton Hoodie');
    setUnitCost(550);
    setSellingPrice(1350);
    setQuantity(2);
    setDiscount(150);
    setDeliveryChargeCollected(100);
    setActualDeliveryExpense(110); // slight subsidy
    setPackagingExpense(40);
    setPaymentFee(25);
    setMarketplaceCommissionRate(0);
    setAdCostAllocated(120); // Meta ad cost per purchase
    setOtherExpenses(0);
    setRefundAmount(0);
  };

  const loadMarketplacePreset = () => {
    setProductName('Smart Magnetic Car Mount');
    setUnitCost(450);
    setSellingPrice(1100);
    setQuantity(1);
    setDiscount(50);
    setDeliveryChargeCollected(80);
    setActualDeliveryExpense(80);
    setPackagingExpense(20);
    setPaymentFee(20);
    setMarketplaceCommissionRate(8); // 8% marketplace take
    setAdCostAllocated(80);
    setOtherExpenses(0);
    setRefundAmount(0);
  };

  const resetAll = () => {
    setProductName('');
    setUnitCost(0);
    setSellingPrice(0);
    setQuantity(1);
    setDiscount(0);
    setDeliveryChargeCollected(0);
    setActualDeliveryExpense(0);
    setPackagingExpense(0);
    setPaymentFee(0);
    setMarketplaceCommissionRate(0);
    setAdCostAllocated(0);
    setOtherExpenses(0);
    setRefundAmount(0);
  };

  const handleCreateOrderFromCalc = () => {
    if (onConvertToOrder) {
      onConvertToOrder({
        productName: productName || 'Custom Product',
        unitCost,
        sellingPrice,
        quantity,
        discount,
        deliveryChargeCollected,
        actualDeliveryExpense,
        packagingExpense,
        paymentFee,
        marketplaceCommissionRate,
        adCostAllocated,
        otherExpenses
      });
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Presets Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <Calculator className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Advanced True Profit Calculator
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Calculate your actual merchandise sales, direct variable costs, delivery margins, and real order contribution.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Presets:</span>
          <button
            onClick={loadSpecBenchmark}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition cursor-pointer"
          >
            ★ Spec Benchmark (৳860)
          </button>
          <button
            onClick={loadClothingPreset}
            className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            Social Apparel
          </button>
          <button
            onClick={loadMarketplacePreset}
            className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            Marketplace Sale
          </button>
          <button
            onClick={resetAll}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Reset form"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs Column (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Section: Product & Sales Price */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              1. Product & Pricing
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Product / Item Name
                </label>
                <input
                  type="text"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="e.g. Oversized Cotton Hoodie"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Purchase Acquisition Cost ({settings.currency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={unitCost || ''}
                    onChange={(e) => setUnitCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400">/ unit</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Selling Price Per Unit ({settings.currency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={sellingPrice || ''}
                    onChange={(e) => setSellingPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400">/ unit</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Quantity Sold
                </label>
                <input
                  type="number"
                  min="1"
                  value={quantity || 1}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Customer Discount / Promo ({settings.currency})
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={discount || ''}
                  onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>

            {sellingPrice > 0 && unitCost > sellingPrice && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <span>
                  <strong>Negative Margin Warning:</strong> The selling price ({formatCurrency(sellingPrice, settings.currency)}) is lower than the acquisition cost ({formatCurrency(unitCost, settings.currency)}).
                </span>
              </div>
            )}
          </div>

          {/* Section: Delivery Logistics & Packaging */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                2. Delivery & Packaging Expenses
              </h3>
              <span className="text-[11px] text-slate-400">
                Delivery margin: {deliverySpread >= 0 ? '+' : ''}{formatCurrency(deliverySpread, settings.currency)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Delivery Paid by Customer
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={deliveryChargeCollected || ''}
                  onChange={(e) => setDeliveryChargeCollected(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 150"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">Charged to customer</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Actual Courier / Delivery Cost
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={actualDeliveryExpense || ''}
                  onChange={(e) => setActualDeliveryExpense(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 120"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">Paid to courier</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Packaging & Poly Mailer
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={packagingExpense || ''}
                  onChange={(e) => setPackagingExpense(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 30"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">Box, bubble wrap, tape</span>
              </div>
            </div>
          </div>

          {/* Section: Payment Fees, Commissions & Ads */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-500"></span>
              3. Processing, Ad Spend & Other Transaction Costs
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Payment Gateway / COD Fee
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={paymentFee || ''}
                  onChange={(e) => setPaymentFee(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 40"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">e.g. bKash / Stripe / COD</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Platform Commission (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="any"
                  value={marketplaceCommissionRate || ''}
                  onChange={(e) => setMarketplaceCommissionRate(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 5"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  {commissionAmount > 0 ? `= ${formatCurrency(commissionAmount, settings.currency)}` : 'Daraz / Amazon %'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Ad Spend Allocation
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={adCostAllocated || ''}
                  onChange={(e) => setAdCostAllocated(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 100"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">Meta / TikTok ad cost</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Other Direct Costs
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={otherExpenses || ''}
                  onChange={(e) => setOtherExpenses(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 20"
                  className="w-full px-3 py-2 text-sm font-mono-numbers rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">Handling / freebies</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Output Column (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Main Profit Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Calculated Order Result
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Order Contribution
                </h3>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60">
                  {contributionMarginPercent}% Margin
                </span>
              </div>
            </div>

            {/* Giant Metric Highlight */}
            <div className={`p-4 rounded-xl text-center border ${
              netOrderContribution >= 0 
                ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40 text-emerald-700 dark:text-emerald-300' 
                : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300'
            }`}>
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Net Order Contribution (True Profit)
              </div>
              <div className="text-3xl sm:text-4xl font-extrabold font-mono-numbers">
                {formatCurrency(netOrderContribution, settings.currency)}
              </div>
              <div className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                Contribution after all product costs, courier, packing, and payment fees
              </div>
            </div>

            {/* Step-by-Step Waterfall Breakdown */}
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60">
                <span className="text-slate-600 dark:text-slate-400">Gross Merchandise Sales ({quantity} × {sellingPrice}):</span>
                <span className="font-semibold font-mono-numbers text-slate-900 dark:text-white">{formatCurrency(grossMerchandiseSales, settings.currency)}</span>
              </div>

              {totalDiscount > 0 && (
                <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-rose-600 dark:text-rose-400">
                  <span>(-) Customer Discount:</span>
                  <span className="font-semibold font-mono-numbers">-{formatCurrency(totalDiscount, settings.currency)}</span>
                </div>
              )}

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 font-medium bg-slate-50 dark:bg-slate-800/40 px-2 rounded-lg">
                <span className="text-slate-700 dark:text-slate-300">Net Merchandise Sales:</span>
                <span className="font-bold font-mono-numbers text-slate-900 dark:text-white">{formatCurrency(netMerchandiseSales, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-rose-600 dark:text-rose-400">
                <span>(-) Cost of Goods Sold (COGS):</span>
                <span className="font-semibold font-mono-numbers">-{formatCurrency(cogs, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 font-medium bg-emerald-50/40 dark:bg-emerald-950/20 px-2 rounded-lg">
                <span className="text-emerald-800 dark:text-emerald-300">Gross Profit (Gross Margin {grossMarginPercent}%):</span>
                <span className="font-bold font-mono-numbers text-emerald-700 dark:text-emerald-400">{formatCurrency(grossProfit, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-blue-600 dark:text-blue-400">
                <span>(+) Delivery Collected from Customer:</span>
                <span className="font-semibold font-mono-numbers">+{formatCurrency(deliveryChargeCollected, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                <span>(-) Actual Delivery Expense:</span>
                <span className="font-mono-numbers text-rose-500">-{formatCurrency(actualDeliveryExpense, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                <span>(-) Packaging Expense:</span>
                <span className="font-mono-numbers text-rose-500">-{formatCurrency(packagingExpense, settings.currency)}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                <span>(-) Payment Fee & Gateway:</span>
                <span className="font-mono-numbers text-rose-500">-{formatCurrency(paymentFee, settings.currency)}</span>
              </div>

              {commissionAmount > 0 && (
                <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                  <span>(-) Marketplace Commission ({marketplaceCommissionRate}%):</span>
                  <span className="font-mono-numbers text-rose-500">-{formatCurrency(commissionAmount, settings.currency)}</span>
                </div>
              )}

              {adCostAllocated > 0 && (
                <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                  <span>(-) Allocated Ad Spend:</span>
                  <span className="font-mono-numbers text-rose-500">-{formatCurrency(adCostAllocated, settings.currency)}</span>
                </div>
              )}

              {otherExpenses > 0 && (
                <div className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 text-slate-500">
                  <span>(-) Other Direct Expenses:</span>
                  <span className="font-mono-numbers text-rose-500">-{formatCurrency(otherExpenses, settings.currency)}</span>
                </div>
              )}
            </div>

            {/* Cash Flow vs Accounting Profit Distinction */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                  Estimated Order Cash Flow:
                </span>
                <span className="font-mono-numbers text-slate-900 dark:text-white">
                  {formatCurrency(estimatedOrderCashMovement, settings.currency)}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                Customer pays {formatCurrency(customerCashIn, settings.currency)}, immediate cash outflows: {formatCurrency(directDisbursements, settings.currency)}. (Product cost was previously disbursed when inventory was acquired).
              </p>
            </div>

            {/* Convert Button */}
            {onConvertToOrder && (
              <button
                onClick={handleCreateOrderFromCalc}
                className="w-full py-2.5 px-4 rounded-xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Save & Create Formal Order</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Educational Accounting Card */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 text-xs space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-indigo-900 dark:text-indigo-300">
              <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              Why Order Contribution Matters
            </div>
            <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
              Customer delivery charges are <strong>not profit</strong> by themselves; you must deduct actual courier fees. Similarly, discounts reduce revenue directly. Order contribution is the amount that goes toward covering business overhead (rent, salaries, web hosting) before net business profit is realized.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
