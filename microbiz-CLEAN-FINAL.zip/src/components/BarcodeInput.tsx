import React, { useState, useRef, useEffect } from 'react';
import { ScanBarcode, CheckCircle2, XCircle } from 'lucide-react';
import { Product } from '../types';

interface BarcodeInputProps {
  products: Product[];
  onSelect: (product: Product) => void;
  placeholder?: string;
  autoFocus?: boolean;
}

/**
 * A3: fast barcode / SKU / name lookup. Matches in priority order:
 * exact barcode → exact SKU → first name-substring match (active products only).
 * Inline "no match" feedback; Enter or the button submits.
 */
export const BarcodeInput: React.FC<BarcodeInputProps> = ({
  products,
  onSelect,
  placeholder = 'Scan or type barcode / SKU / product name…',
  autoFocus = false
}) => {
  const [value, setValue] = useState('');
  const [noMatch, setNoMatch] = useState<string | null>(null);
  const [justMatched, setJustMatched] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (autoFocus) inputRef.current?.focus();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [autoFocus]);

  const flash = (setter: (v: string | null) => void, text: string) => {
    setter(text);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setter(null), 2600);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = value.trim().toLowerCase();
    if (!q) return;
    const active = products.filter(p => p.status !== 'archived');

    const byBarcode = active.find(p => (p.barcode || '').toLowerCase() === q);
    const bySku = !byBarcode && active.find(p => p.sku.toLowerCase() === q);
    const byName = !byBarcode && !bySku && active.find(p => p.name.toLowerCase().includes(q));
    const match = byBarcode || bySku || byName;

    if (match) {
      onSelect(match);
      flash(setJustMatched, match.name);
      setValue('');
      setNoMatch(null);
      inputRef.current?.focus();
    } else {
      flash(setNoMatch, `No product matches "${value.trim()}"`);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <div className="relative flex-1">
          <ScanBarcode className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          />
        </div>
        <button
          type="submit"
          className="px-3 py-2 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
        >
          Find
        </button>
      </form>
      {noMatch && (
        <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-medium text-rose-600 dark:text-rose-400">
          <XCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{noMatch}</span>
        </div>
      )}
      {justMatched && !noMatch && (
        <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
          <span>Added “{justMatched}”</span>
        </div>
      )}
    </div>
  );
};
