import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Search, 
  Filter, 
  Plus, 
  FileText, 
  DollarSign, 
  RotateCcw, 
  Trash2, 
  Truck, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Download, 
  Eye, 
  X,
  CreditCard,
  User,
  Package,
  ArrowLeft,
  Undo2
} from 'lucide-react';
import { useApp, ReturnLineInput } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Order, OrderItem, OrderStatus, PaymentStatus, Product, Customer } from '../types';
import { calculateOrderProfit, formatCurrency, roundToMinorUnits, calculateCustomerOutstanding } from '../utils/calculations';
import { downloadCsv, toCsvRow } from '../utils/csv';
import { InvoiceModal } from './InvoiceModal';
import { BarcodeInput } from './BarcodeInput';
import { useModalBehavior } from '../hooks/useModalBehavior';

export const OrdersView: React.FC = () => {
  const { 
    orders, 
    products, 
    customers, 
    accounts, 
    settings, 
    user,
    addOrder, 
    addCustomer,
    updateOrderStatus, 
    recordOrderPayment, 
    refundOrder,
    returnOrderItems,
    logAuditEvent
  } = useApp();
  const { can } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState<string>('all');
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [paymentOrder, setPaymentOrder] = useState<Order | null>(null);
  const [refundOrderTarget, setRefundOrderTarget] = useState<Order | null>(null);
  const [selectedOrderIdForSummary, setSelectedOrderIdForSummary] = useState<string | null>(null);

  // New Order Form State
  const [customerMode, setCustomerMode] = useState<'existing' | 'new'>('existing');
  const [selectedCustomerId, setSelectedCustomerId] = useState(customers[0]?.id || '');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerAddress, setNewCustomerAddress] = useState('');

  const [orderItems, setOrderItems] = useState<Array<{
    productId: string;
    variantId?: string;
    productName: string;
    sku: string;
    quantity: number;
    unitCostSnapshot: number;
    unitPrice: number;
    discount: number;
  }>>([
    {
      productId: products[0]?.id || '',
      productName: products[0]?.name || '',
      sku: products[0]?.sku || '',
      quantity: 1,
      unitCostSnapshot: products[0]?.costPrice || 0,
      unitPrice: products[0]?.sellingPrice || 0,
      discount: 0
    }
  ]);

  const [orderDiscount, setOrderDiscount] = useState(0);
  const [deliveryChargeCollected, setDeliveryChargeCollected] = useState(100);
  const [actualDeliveryExpense, setActualDeliveryExpense] = useState(90);
  const [packagingExpense, setPackagingExpense] = useState(30);
  const [paymentFee, setPaymentFee] = useState(0);
  const [adCostAllocated, setAdCostAllocated] = useState(0);
  const [otherExpenses, setOtherExpenses] = useState(0);
  const [initialAmountPaid, setInitialAmountPaid] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');
  const [paymentAccountId, setPaymentAccountId] = useState(accounts[0]?.id || '');
  const [carrier, setCarrier] = useState('Pathao Courier');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [internalNotes, setInternalNotes] = useState('');

  // Payment Recording Modal State
  const [payAmount, setPayAmount] = useState(0);
  const [payAccountId, setPayAccountId] = useState(accounts[0]?.id || '');
  const [payMethod, setPayMethod] = useState('Cash');

  // Refund Modal State
  const [refundAmt, setRefundAmt] = useState(0);
  const [refundAccId, setRefundAccId] = useState(accounts[0]?.id || '');
  const [refundIsFullReturn, setRefundIsFullReturn] = useState(false);

  // A1: credit-limit override state
  const [overrideLimit, setOverrideLimit] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');

  // A2: sales-return flow state
  const [returnTarget, setReturnTarget] = useState<Order | null>(null);
  const [returnLines, setReturnLines] = useState<Array<{ productId: string; variantId?: string; quantity: number }>>([]);
  const [returnRefundAmt, setReturnRefundAmt] = useState(0);
  const [returnAccountId, setReturnAccountId] = useState(accounts[0]?.id || '');
  const [orderError, setOrderError] = useState('');
  const [returnError, setReturnError] = useState('');

  const closeReturnModal = () => {
    setReturnTarget(null);
    setReturnError('');
    setReturnLines([]);
    setReturnRefundAmt(0);
  };

  const orderModal = useModalBehavior(isAddModalOpen, () => { setIsAddModalOpen(false); setOrderError(''); }, 'Create order');
  const paymentModal = useModalBehavior(!!paymentOrder, () => setPaymentOrder(null), 'Record payment');
  const refundModal = useModalBehavior(!!refundOrderTarget, () => setRefundOrderTarget(null), 'Issue refund');
  const returnModal = useModalBehavior(!!returnTarget, closeReturnModal, 'Process return');

  // Calculate live preview metrics for the new order
  const calculatedItems = orderItems.map(item => ({
    ...item,
    total: (item.quantity * item.unitPrice) - item.discount
  }));
  const subtotal = calculatedItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const itemDiscounts = calculatedItems.reduce((sum, item) => sum + item.discount, 0);
  // I8: tax = (subtotal − discounts) × rate when enabled; part of the payable total
  const taxableBase = Math.max(0, subtotal - itemDiscounts - orderDiscount);
  const taxAmount = settings.taxEnabled
    ? roundToMinorUnits((taxableBase * settings.taxRatePercent) / 100)
    : 0;
  const totalPayable = Math.max(0, taxableBase + deliveryChargeCollected + taxAmount);

  // A1: credit-limit enforcement — computed live for the selected existing customer
  const selectedCustomer: Customer | undefined =
    customerMode === 'existing' ? customers.find(c => c.id === selectedCustomerId) : undefined;
  const customerOutstanding = selectedCustomer ? calculateCustomerOutstanding(orders, selectedCustomer) : 0;
  const customerCreditLimit = selectedCustomer?.creditLimit || 0;
  const projectedExposure = customerOutstanding + totalPayable;
  const creditBreach = customerCreditLimit > 0 && projectedExposure > customerCreditLimit;
  const creditOverage = creditBreach ? projectedExposure - customerCreditLimit : 0;
  const creditOverrideValid = overrideLimit && overrideReason.trim().length > 0;
  const orderSubmitBlocked = creditBreach && !creditOverrideValid;

  const previewBreakdown = calculateOrderProfit({
    items: orderItems,
    discount: orderDiscount,
    deliveryChargeCollected,
    actualDeliveryExpense,
    packagingExpense,
    paymentFee,
    adCostAllocated,
    otherExpenses
  });

  // Filter orders
  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customerPhone.includes(searchQuery) ||
      (order.trackingNumber && order.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = selectedStatus === 'all' || order.orderStatus === selectedStatus;
    const matchesPayment = selectedPaymentStatus === 'all' || order.paymentStatus === selectedPaymentStatus;

    return matchesSearch && matchesStatus && matchesPayment;
  });

  const handleAddItemRow = () => {
    const defaultProd = products[0];
    if (!defaultProd) return;
    setOrderItems(prev => [
      ...prev,
      {
        productId: defaultProd.id,
        productName: defaultProd.name,
        sku: defaultProd.sku,
        quantity: 1,
        unitCostSnapshot: defaultProd.costPrice,
        unitPrice: defaultProd.sellingPrice,
        discount: 0
      }
    ]);
  };

  const handleRemoveItemRow = (index: number) => {
    if (orderItems.length <= 1) return;
    setOrderItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleProductSelect = (index: number, productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    setOrderItems(prev => prev.map((item, i) => {
      if (i === index) {
        return {
          ...item,
          productId: prod.id,
          productName: prod.name,
          sku: prod.sku,
          unitCostSnapshot: prod.costPrice,
          unitPrice: prod.sellingPrice
        };
      }
      return item;
    }));
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();

    let custName = newCustomerName;
    let custPhone = newCustomerPhone;
    let custAddress = newCustomerAddress;
    let custId = selectedCustomerId;

    if (customerMode === 'existing') {
      const found = customers.find(c => c.id === selectedCustomerId);
      if (found) {
        custName = found.name;
        custPhone = found.phone;
        custAddress = found.address || '';
      }
    } else {
      if (!custName.trim() || !custPhone.trim()) {
        setOrderError('Customer name and contact phone are required.');
        return;
      }
      // I4: persist the new customer instead of minting a throwaway id
      const created = addCustomer({
        name: custName,
        phone: custPhone,
        address: custAddress
      });
      if (!created) return; // permission denied (alert already shown by guard)
      custId = created.id;
    }

    if (!custName.trim() || !custPhone.trim()) {
      setOrderError('Customer name and contact phone are required.');
      return;
    }
    setOrderError('');

    const items: OrderItem[] = orderItems.map(i => ({
      ...i,
      total: (i.quantity * i.unitPrice) - i.discount
    }));

    const finalPaymentStatus: PaymentStatus = 
      initialAmountPaid >= totalPayable 
        ? 'paid' 
        : initialAmountPaid > 0 
        ? 'partial' 
        : 'unpaid';

    // A1: the submit button is disabled while the breach is un-overridden (see
    // orderSubmitBlocked), so this guard is unreachable — the banner explains it.
    if (creditBreach && !creditOverrideValid) {
      return;
    }

    const finalNotes = creditBreach && creditOverrideValid
      ? `${internalNotes}${internalNotes ? ' | ' : ''}Credit limit overridden: ${overrideReason.trim()}`
      : internalNotes;

    const createdOrder = addOrder({
      customerId: custId,
      customerName: custName,
      customerPhone: custPhone,
      customerAddress: custAddress,
      date: new Date().toISOString(),
      items,
      subtotal,
      discount: orderDiscount,
      taxAmount,
      deliveryChargeCollected,
      actualDeliveryExpense,
      packagingExpense,
      paymentFee,
      marketplaceCommission: 0,
      adCostAllocated,
      otherExpenses,
      totalAmount: totalPayable,
      amountPaid: initialAmountPaid,
      paymentMethod,
      paymentAccountId: initialAmountPaid > 0 ? paymentAccountId : undefined,
      paymentStatus: finalPaymentStatus,
      orderStatus: 'confirmed',
      carrier,
      trackingNumber,
      internalNotes: finalNotes
    });

    if (!createdOrder) return; // permission denied (alert already shown by guard)

    // A1: credit-limit overrides are written to the audit log
    if (creditBreach && creditOverrideValid && selectedCustomer) {
      logAuditEvent(
        'Credit Limit Override',
        'Order',
        `Order ${createdOrder.orderNumber} for ${custName}: projected exposure ${formatCurrency(projectedExposure, settings.currency)} exceeded credit limit ${formatCurrency(customerCreditLimit, settings.currency)} by ${formatCurrency(creditOverage, settings.currency)}. Reason: ${overrideReason.trim()}`
      );
    }

    setIsAddModalOpen(false);
    // Reset defaults
    setOrderItems([{
      productId: products[0]?.id || '',
      productName: products[0]?.name || '',
      sku: products[0]?.sku || '',
      quantity: 1,
      unitCostSnapshot: products[0]?.costPrice || 0,
      unitPrice: products[0]?.sellingPrice || 0,
      discount: 0
    }]);
    setInitialAmountPaid(0);
    setNewCustomerName('');
    setNewCustomerPhone('');
    setOverrideLimit(false);
    setOverrideReason('');
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentOrder || payAmount <= 0) return;
    recordOrderPayment(paymentOrder.id, payAmount, payAccountId, payMethod);
    setPaymentOrder(null);
  };

  const handleRefundSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundOrderTarget || refundAmt <= 0) return;
    refundOrder(refundOrderTarget.id, refundAmt, refundAccId, refundIsFullReturn);
    setRefundOrderTarget(null);
    setRefundIsFullReturn(false);
  };

  // A2: sales-return flow
  const returnableQty = (item: OrderItem) =>
    Math.max(0, item.quantity - (item.returnedQuantity || 0));

  const canProcessReturn = (order: Order) =>
    can('orders.refund') &&
    !['cancelled', 'returned', 'draft'].includes(order.orderStatus) &&
    order.items.some(i => returnableQty(i) > 0);

  const openReturn = (order: Order) => {
    setReturnTarget(order);
    setReturnLines(order.items.map(i => ({
      productId: i.productId,
      variantId: i.variantId,
      quantity: 0
    })));
    setReturnRefundAmt(0);
    setReturnAccountId(accounts[0]?.id || '');
  };

  const suggestedReturnRefund = (order: Order, lines: Array<{ productId: string; variantId?: string; quantity: number }>) =>
    roundToMinorUnits(lines.reduce((sum, l) => {
      const item = order.items.find(i =>
        i.productId === l.productId && (i.variantId || undefined) === (l.variantId || undefined));
      return sum + (item ? l.quantity * item.unitPrice : 0);
    }, 0));

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnTarget) return;
    const lines: ReturnLineInput[] = returnLines.filter(l => l.quantity > 0);
    if (lines.length === 0) {
      setReturnError('Select at least one item quantity to return.');
      return;
    }
    if (returnRefundAmt < 0) {
      setReturnError('Refund amount cannot be negative.');
      return;
    }
    setReturnError('');
    returnOrderItems(returnTarget.id, lines, returnRefundAmt, returnAccountId || undefined);
    closeReturnModal();
  };

  // A3: barcode selection in order creation — bump qty if the product is
  // already a line, otherwise append a new line
  const handleBarcodeSelect = (prod: Product) => {
    setOrderItems(prev => {
      const idx = prev.findIndex(i => i.productId === prod.id);
      if (idx >= 0) {
        return prev.map((it, i) => i === idx ? { ...it, quantity: it.quantity + 1 } : it);
      }
      return [...prev, {
        productId: prod.id,
        productName: prod.name,
        sku: prod.sku,
        quantity: 1,
        unitCostSnapshot: prod.costPrice,
        unitPrice: prod.sellingPrice,
        discount: 0
      }];
    });
  };

  const exportOrdersCSV = () => {
    const headers = ['Order Number', 'Date', 'Customer', 'Phone', 'Items Count', 'Gross Sales', 'Discount', 'Delivery Collected', 'Total Payable', 'Amount Paid', 'Payment Status', 'Order Status', 'Contribution'];
    const rows = filteredOrders.map(o => {
      const breakdown = calculateOrderProfit(o);
      return [
        o.orderNumber,
        new Date(o.date).toLocaleDateString(),
        o.customerName,
        o.customerPhone,
        o.items.reduce((s, i) => s + i.quantity, 0),
        breakdown.grossMerchandiseSales,
        breakdown.totalDiscounts,
        o.deliveryChargeCollected,
        o.totalAmount,
        o.amountPaid,
        o.paymentStatus,
        o.orderStatus,
        breakdown.netOrderContribution
      ];
    });

    // I7: proper RFC-4180 serialization (quotes fields with commas/quotes/newlines)
    downloadCsv(`orders_export_${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
  };

  const activeSummaryOrder = selectedOrderIdForSummary 
    ? orders.find(o => o.id === selectedOrderIdForSummary) 
    : null;

  if (activeSummaryOrder) {
    const summaryBreakdown = calculateOrderProfit(activeSummaryOrder);
    const balanceDue = Math.max(0, activeSummaryOrder.totalAmount - (activeSummaryOrder.amountPaid || 0));

    return (
      <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto space-y-6">
        {/* Top Header & Backward Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedOrderIdForSummary(null)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-2xs transition cursor-pointer group"
              title="Return to order list"
            >
              <ArrowLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
              <span>Back to Orders</span>
            </button>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-bold font-mono-numbers text-slate-900 dark:text-white">
                  Order Summary: {activeSummaryOrder.orderNumber}
                </h1>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  activeSummaryOrder.paymentStatus === 'paid'
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60'
                    : activeSummaryOrder.paymentStatus === 'partial'
                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800/60'
                    : activeSummaryOrder.paymentStatus === 'refunded'
                    ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400 border border-purple-200 dark:border-purple-800/60'
                    : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200 dark:border-rose-800/60'
                }`}>
                  {activeSummaryOrder.paymentStatus.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Recorded on {new Date(activeSummaryOrder.date).toLocaleDateString([], { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setInvoiceOrder(activeSummaryOrder)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer shadow-2xs"
            >
              <FileText className="w-4 h-4 text-slate-500" />
              <span>Print / PDF Invoice</span>
            </button>

            {balanceDue > 0 && (
              <button
                onClick={() => {
                  setPaymentOrder(activeSummaryOrder);
                  setPayAmount(balanceDue);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
              >
                <DollarSign className="w-4 h-4" />
                <span>Record Payment ({formatCurrency(balanceDue, settings.currency)})</span>
              </button>
            )}

            {activeSummaryOrder.paymentStatus === 'paid' && (
              <button
                onClick={() => {
                  setRefundOrderTarget(activeSummaryOrder);
                  setRefundAmt(activeSummaryOrder.totalAmount);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/60 hover:bg-purple-100 transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Issue Refund</span>
              </button>
            )}

            {canProcessReturn(activeSummaryOrder) && (
              <button
                onClick={() => openReturn(activeSummaryOrder)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/60 hover:bg-teal-100 transition cursor-pointer"
              >
                <Undo2 className="w-3.5 h-3.5" />
                <span>Process Return</span>
              </button>
            )}
          </div>
        </div>

        {/* Overview Information Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Customer & Destination */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Customer & Recipient
            </span>
            <div className="font-bold text-sm text-slate-900 dark:text-white">
              {activeSummaryOrder.customerName}
            </div>
            <div className="text-xs text-slate-500 font-mono-numbers">
              Tel: {activeSummaryOrder.customerPhone}
            </div>
            {activeSummaryOrder.customerAddress && (
              <div className="text-xs text-slate-600 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800">
                {activeSummaryOrder.customerAddress}
              </div>
            )}
          </div>

          {/* Fulfillment & Tracking */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Fulfillment & Logistics
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500">Status:</span>
              <select
                value={activeSummaryOrder.orderStatus}
                onChange={(e) => updateOrderStatus(activeSummaryOrder.id, e.target.value as OrderStatus)}
                className={`text-xs font-semibold py-1 px-2.5 rounded-lg border focus:outline-none cursor-pointer ${
                  activeSummaryOrder.orderStatus === 'delivered'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
                    : activeSummaryOrder.orderStatus === 'cancelled'
                    ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800'
                    : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/50 dark:text-blue-300 dark:border-blue-800'
                }`}
              >
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            <div className="text-xs text-slate-500 pt-1">
              <span>Carrier: </span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">{activeSummaryOrder.carrier || 'Not assigned'}</span>
            </div>
            {activeSummaryOrder.trackingNumber && (
              <div className="text-xs text-slate-500 font-mono-numbers">
                Tracking #: <span className="font-bold text-slate-800 dark:text-slate-200">{activeSummaryOrder.trackingNumber}</span>
              </div>
            )}
          </div>

          {/* Payment & Liquidity */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Payment Settlement
            </span>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">Total Invoice:</span>
              <span className="font-bold font-mono-numbers text-slate-900 dark:text-white">
                {formatCurrency(activeSummaryOrder.totalAmount, settings.currency)}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">Collected Cash:</span>
              <span className="font-bold font-mono-numbers text-emerald-600">
                {formatCurrency(activeSummaryOrder.amountPaid || 0, settings.currency)}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-100 dark:border-slate-800 font-semibold">
              <span className="text-slate-500">Balance Due:</span>
              <span className={`font-mono-numbers ${balanceDue > 0 ? 'text-amber-600 font-bold' : 'text-slate-400'}`}>
                {balanceDue > 0 ? formatCurrency(balanceDue, settings.currency) : 'Settled in full'}
              </span>
            </div>
          </div>
        </div>

        {/* Ordered Product Line Items Table */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden space-y-2 p-5">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">
            Ordered Line Items & Snapshot Costs
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <tr>
                  <th className="py-2.5 px-3">Item Description</th>
                  <th className="py-2.5 px-3 text-center">SKU</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3 text-right">Selling Price</th>
                  <th className="py-2.5 px-3 text-right">Acquisition Cost (COGS)</th>
                  <th className="py-2.5 px-3 text-right">Line Discount</th>
                  <th className="py-2.5 px-3 text-right">Line Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono-numbers">
                {activeSummaryOrder.items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-900 dark:text-white">
                      {item.productName}
                    </td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{item.sku}</td>
                    <td className="py-2.5 px-3 text-center font-bold">
                      {item.quantity}
                      {(item.returnedQuantity || 0) > 0 && (
                        <div className="text-[10px] font-sans font-medium text-teal-600 dark:text-teal-400">
                          {item.returnedQuantity} returned
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">{formatCurrency(item.unitPrice, settings.currency)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-500">{formatCurrency(item.unitCostSnapshot, settings.currency)}</td>
                    <td className="py-2.5 px-3 text-right text-rose-500">
                      {item.discount ? `-${formatCurrency(item.discount, settings.currency)}` : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900 dark:text-white">
                      {formatCurrency(item.total, settings.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Financial Waterfall & Contribution Margin Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Waterfall Accounting Breakdown */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Financial Waterfall & True Profit Breakdown
            </h3>
            <div className="space-y-2 text-xs font-mono-numbers">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400">
                <span>Gross Merchandise Sales:</span>
                <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(summaryBreakdown.grossMerchandiseSales, settings.currency)}</span>
              </div>
              {summaryBreakdown.totalDiscounts > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-rose-600">
                  <span>Less: Total Customer Discounts:</span>
                  <span>-{formatCurrency(summaryBreakdown.totalDiscounts, settings.currency)}</span>
                </div>
              )}
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 font-semibold text-slate-900 dark:text-white">
                <span>Net Merchandise Sales:</span>
                <span>{formatCurrency(summaryBreakdown.netMerchandiseSales, settings.currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-blue-600">
                <span>Add: Customer Delivery Fee:</span>
                <span>+{formatCurrency(summaryBreakdown.deliveryChargeCollected, settings.currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-rose-600">
                <span>Less: Direct Product Cost (COGS):</span>
                <span>-{formatCurrency(summaryBreakdown.cogs, settings.currency)}</span>
              </div>
              <div className="flex justify-between py-1.5 px-2 rounded-lg bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 font-bold">
                <span>Gross Profit (Gross Margin: {summaryBreakdown.grossMarginPercent}%):</span>
                <span>{formatCurrency(summaryBreakdown.grossProfit, settings.currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                <span>Less: Actual Courier Delivery Expense:</span>
                <span className="text-rose-500">-{formatCurrency(summaryBreakdown.actualDeliveryExpense, settings.currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                <span>Less: Packaging & Mailer Expense:</span>
                <span className="text-rose-500">-{formatCurrency(summaryBreakdown.packagingExpense, settings.currency)}</span>
              </div>
              {summaryBreakdown.paymentFee > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                  <span>Less: Gateway / Processing Fee:</span>
                  <span className="text-rose-500">-{formatCurrency(summaryBreakdown.paymentFee, settings.currency)}</span>
                </div>
              )}
              {summaryBreakdown.adCostAllocated > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                  <span>Less: Allocated Marketing / Ad Spend:</span>
                  <span className="text-rose-500">-{formatCurrency(summaryBreakdown.adCostAllocated, settings.currency)}</span>
                </div>
              )}
              {summaryBreakdown.otherExpenses > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                  <span>Less: Other Transaction Expenses:</span>
                  <span className="text-rose-500">-{formatCurrency(summaryBreakdown.otherExpenses, settings.currency)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Net Order Contribution & Cash Flow Result */}
          <div className="space-y-4">
            <div className={`p-5 rounded-2xl border ${
              summaryBreakdown.netOrderContribution >= 0
                ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40 text-emerald-800 dark:text-emerald-300'
                : 'bg-rose-50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
            }`}>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                Net Order Contribution (True Profit)
              </div>
              <div className="text-3xl font-extrabold font-mono-numbers">
                {formatCurrency(summaryBreakdown.netOrderContribution, settings.currency)}
              </div>
              <div className="text-xs font-bold mt-1">
                {summaryBreakdown.contributionMarginPercent}% Contribution Margin
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 leading-relaxed font-sans">
                This is the actual net earnings generated by this transaction after all product costs, delivery subsidies, packaging, and gateway fees.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2 text-xs">
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                Cash Liquidity Movement for Order
              </span>
              <div className="flex justify-between font-mono-numbers text-slate-600 dark:text-slate-400">
                <span>Customer Cash Inflow:</span>
                <span className="font-semibold text-emerald-600">+{formatCurrency(summaryBreakdown.cashReceived, settings.currency)}</span>
              </div>
              <div className="flex justify-between font-mono-numbers text-slate-600 dark:text-slate-400">
                <span>Immediate Cash Outflows (Courier, packing, fees):</span>
                <span className="font-semibold text-rose-600">-{formatCurrency(summaryBreakdown.directCashOutflow, settings.currency)}</span>
              </div>
              <div className="flex justify-between font-mono-numbers pt-1 border-t border-slate-100 dark:border-slate-800 font-bold text-slate-900 dark:text-white">
                <span>Estimated Net Cash Movement:</span>
                <span className="text-blue-600">{formatCurrency(summaryBreakdown.estimatedOrderCashMovement, settings.currency)}</span>
              </div>
            </div>

            {activeSummaryOrder.internalNotes && (
              <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-300">
                <span className="font-bold block mb-1">Internal Order Notes:</span>
                <p className="font-sans leading-relaxed">{activeSummaryOrder.internalNotes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Backward Button & Action Bar */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setSelectedOrderIdForSummary(null)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer group shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
            <span>Return to Orders List</span>
          </button>

          <button
            onClick={() => setInvoiceOrder(activeSummaryOrder)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Open Printable Invoice</span>
          </button>
        </div>

        {/* Modals rendered in summary mode */}
        <InvoiceModal order={invoiceOrder} onClose={() => setInvoiceOrder(null)} />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Orders & Shipments
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Manage transactions, delivery fees, customer balances, and print invoices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportOrdersCSV}
            disabled={!can('reports.export')}
            title={can('reports.export') ? 'Export orders to CSV' : 'Your role cannot export reports'}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={() => setIsAddModalOpen(true)}
            disabled={!can('orders.create')}
            title={can('orders.create') ? 'Create a new order' : 'Your role cannot create orders'}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
            Create Order
          </button>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by Order #, Customer, Phone or Tracking..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Fulfillment Statuses</option>
              <option value="pending">Pending Confirmation</option>
              <option value="confirmed">Confirmed</option>
              <option value="processing">Processing / Packing</option>
              <option value="shipped">Shipped / In Transit</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          <div className="sm:col-span-3">
            <select
              value={selectedPaymentStatus}
              onChange={(e) => setSelectedPaymentStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Payment Statuses</option>
              <option value="paid">Paid</option>
              <option value="partial">Partially Paid</option>
              <option value="unpaid">Unpaid / COD</option>
              <option value="refunded">Refunded</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders Table (desktop) / Cards (mobile) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto hidden sm:block">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
              <tr>
                <th className="py-3 px-4">Order</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items</th>
                <th className="py-3 px-4 text-right">Total Payable</th>
                <th className="py-3 px-4 text-center">Payment</th>
                <th className="py-3 px-4 text-center">Fulfillment</th>
                <th className="py-3 px-4 text-right">Contribution</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center">
                    <p className="text-slate-400 text-xs">No matching orders found.</p>
                    <button
                      onClick={() => setIsAddModalOpen(true)}
                      className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                    >
                      Record your first order
                    </button>
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const breakdown = calculateOrderProfit(order);
                  const balanceDue = order.totalAmount - (order.amountPaid || 0);

                  return (
                    <tr key={order.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <button
                          onClick={() => setSelectedOrderIdForSummary(order.id)}
                          className="font-bold font-mono-numbers text-slate-900 dark:text-white hover:text-emerald-600 dark:hover:text-emerald-400 transition cursor-pointer text-left flex items-center gap-1.5 group"
                          title="Open Order Summary"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-500 transition-colors shrink-0" />
                          <span>{order.orderNumber}</span>
                        </button>
                        {order.trackingNumber && (
                          <div className="text-[10px] text-slate-400 truncate max-w-[110px] pl-5">
                            {order.carrier}: {order.trackingNumber}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-slate-500">
                        {new Date(order.date).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800 dark:text-slate-200">
                          {order.customerName}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-numbers">
                          {order.customerPhone}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-700 dark:text-slate-300">
                          {order.items.reduce((sum, i) => sum + i.quantity, 0)} units
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[140px]">
                          {order.items.map(i => i.productName).join(', ')}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="font-bold font-mono-numbers text-slate-900 dark:text-white">
                          {formatCurrency(order.totalAmount, settings.currency)}
                        </div>
                        {balanceDue > 0 ? (
                          <div className="text-[10px] text-amber-600 font-mono-numbers">
                            Due: {formatCurrency(balanceDue, settings.currency)}
                          </div>
                        ) : (
                          <div className="text-[10px] text-emerald-600 font-mono-numbers">
                            Paid in full
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          order.paymentStatus === 'paid'
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60'
                            : order.paymentStatus === 'partial'
                            ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800/60'
                            : order.paymentStatus === 'refunded'
                            ? 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-400 border border-purple-200 dark:border-purple-800/60'
                            : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-800/60'
                        }`}>
                          {order.paymentStatus.toUpperCase()}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <select
                          value={order.orderStatus}
                          onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                          className={`text-[11px] font-semibold py-1 px-2 rounded-lg border focus:outline-none cursor-pointer ${
                            order.orderStatus === 'delivered'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
                              : order.orderStatus === 'cancelled'
                              ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800'
                              : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/50 dark:text-blue-300 dark:border-blue-800'
                          }`}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className={`font-bold font-mono-numbers ${
                          breakdown.netOrderContribution >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600'
                        }`}>
                          {formatCurrency(breakdown.netOrderContribution, settings.currency)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {breakdown.contributionMarginPercent}% margin
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Order Summary Trigger */}
                          <button
                            onClick={() => setSelectedOrderIdForSummary(order.id)}
                            className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition cursor-pointer"
                            title="View Order Summary"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Invoice trigger */}
                          <button
                            onClick={() => setInvoiceOrder(order)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                            title="Print / View Invoice"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          {/* Record payment if balance due */}
                          {balanceDue > 0 && (
                            <button
                              onClick={() => {
                                setPaymentOrder(order);
                                setPayAmount(balanceDue);
                              }}
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition cursor-pointer"
                              title="Record Payment"
                            >
                              <DollarSign className="w-4 h-4" />
                            </button>
                          )}

                          {/* Refund trigger */}
                          {order.paymentStatus === 'paid' && (
                            <button
                              onClick={() => {
                                setRefundOrderTarget(order);
                                setRefundAmt(order.totalAmount);
                              }}
                              className="p-1.5 rounded-lg text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-950/50 transition cursor-pointer"
                              title="Issue Refund"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          )}

                          {/* A2: sales return */}
                          {canProcessReturn(order) && (
                            <button
                              onClick={() => openReturn(order)}
                              className="p-1.5 rounded-lg text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/50 transition cursor-pointer"
                              title="Process Return"
                            >
                              <Undo2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile card list */}
        <div className="sm:hidden divide-y divide-slate-100 dark:divide-slate-800">
          {filteredOrders.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-slate-400 text-xs">No matching orders found.</p>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
              >
                Record your first order
              </button>
            </div>
          ) : (
            filteredOrders.map((order) => {
              const cardBalanceDue = Math.max(0, order.totalAmount - (order.amountPaid || 0));
              return (
                <div key={order.id} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <button
                      onClick={() => setSelectedOrderIdForSummary(order.id)}
                      className="text-left min-w-0 cursor-pointer"
                    >
                      <div className="text-xs font-bold font-mono-numbers text-slate-900 dark:text-white">
                        {order.orderNumber}
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-300 font-semibold truncate">
                        {order.customerName}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(order.date).toLocaleDateString()} • {order.items.reduce((sum, i) => sum + i.quantity, 0)} units
                      </div>
                    </button>
                    <div className="text-right shrink-0">
                      <div className="text-sm font-bold font-mono-numbers text-slate-900 dark:text-white">
                        {formatCurrency(order.totalAmount, settings.currency)}
                      </div>
                      <span className={`mt-1 inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        order.paymentStatus === 'paid'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                          : order.paymentStatus === 'partial'
                          ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {order.paymentStatus.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2.5">
                    <select
                      value={order.orderStatus}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                      className="text-[11px] font-semibold py-1 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer"
                      aria-label={`Order status for ${order.orderNumber}`}
                    >
                      {['draft','pending','confirmed','processing','ready','shipped','delivered','cancelled','returned'].map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setSelectedOrderIdForSummary(order.id)}
                        className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition cursor-pointer"
                        aria-label="View order summary"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setInvoiceOrder(order)}
                        className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                        aria-label="View invoice"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                      {cardBalanceDue > 0 && (
                        <button
                          onClick={() => { setPaymentOrder(order); setPayAmount(cardBalanceDue); }}
                          className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition cursor-pointer"
                          aria-label="Record payment"
                        >
                          <DollarSign className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Add Order Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...orderModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8" {...orderModal.panelProps}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Create New Customer Order
                </h3>
              </div>
              <button
                onClick={() => { setIsAddModalOpen(false); setOverrideLimit(false); setOverrideReason(''); }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateOrder} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {orderError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {orderError}
                </p>
              )}
              {/* Customer Selector */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Customer Details</span>
                  <div className="flex items-center gap-2 text-xs">
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input 
                        type="radio" 
                        name="c_mode" 
                        checked={customerMode === 'existing'} 
                        onChange={() => setCustomerMode('existing')} 
                      />
                      <span>Existing Customer</span>
                    </label>
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input 
                        type="radio" 
                        name="c_mode" 
                        checked={customerMode === 'new'} 
                        onChange={() => setCustomerMode('new')} 
                      />
                      <span>+ New Customer</span>
                    </label>
                  </div>
                </div>

                {customerMode === 'existing' ? (
                  <div>
                    <select
                      value={selectedCustomerId}
                      onChange={(e) => setSelectedCustomerId(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    >
                      {customers.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name} — {c.phone} {c.address ? `(${c.address})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Full Name *"
                      required
                      value={newCustomerName}
                      onChange={(e) => setNewCustomerName(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Phone Number *"
                      required
                      value={newCustomerPhone}
                      onChange={(e) => setNewCustomerPhone(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Delivery Address"
                      value={newCustomerAddress}
                      onChange={(e) => setNewCustomerAddress(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                )}
              </div>

              {/* A1: credit-limit warning + override */}
              {creditBreach && selectedCustomer && (
                <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 space-y-3">
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                    <div className="text-xs flex-1">
                      <div className="font-bold text-amber-800 dark:text-amber-200">
                        Credit limit exceeded — order blocked
                      </div>
                      <div className="text-amber-700 dark:text-amber-300 mt-1.5 space-y-0.5 font-mono-numbers">
                        <div className="flex justify-between gap-4">
                          <span>Current outstanding:</span>
                          <span className="font-semibold">{formatCurrency(customerOutstanding, settings.currency)}</span>
                        </div>
                        <div className="flex justify-between gap-4">
                          <span>This order:</span>
                          <span className="font-semibold">{formatCurrency(totalPayable, settings.currency)}</span>
                        </div>
                        <div className="flex justify-between gap-4">
                          <span>Credit limit:</span>
                          <span className="font-semibold">{formatCurrency(customerCreditLimit, settings.currency)}</span>
                        </div>
                        <div className="flex justify-between gap-4 font-bold text-amber-800 dark:text-amber-200">
                          <span>Over by:</span>
                          <span>{formatCurrency(creditOverage, settings.currency)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={overrideLimit}
                      onChange={(e) => setOverrideLimit(e.target.checked)}
                      className="mt-0.5 rounded border-amber-400 text-amber-600 focus:ring-amber-500"
                    />
                    <span className="text-xs font-semibold text-amber-800 dark:text-amber-200">
                      Override credit limit (a reason is required — the override is recorded in the audit log)
                    </span>
                  </label>
                  {overrideLimit && (
                    <input
                      type="text"
                      value={overrideReason}
                      onChange={(e) => setOverrideReason(e.target.value)}
                      placeholder="Reason for override (required)…"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-amber-300 dark:border-amber-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  )}
                </div>
              )}

              {/* Order Line Items */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Order Items (Stock and snapshot costs auto-populated)
                  </span>
                  <button
                    type="button"
                    onClick={handleAddItemRow}
                    className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item</span>
                  </button>
                </div>

                {/* A3: barcode / SKU / name quick-add */}
                <BarcodeInput
                  products={products}
                  onSelect={handleBarcodeSelect}
                  placeholder="Scan barcode / SKU, or type product name + Enter…"
                />

                <div className="space-y-2">
                  {orderItems.map((item, index) => (
                    <div 
                      key={index}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-12 gap-2 items-center"
                    >
                      <div className="sm:col-span-5">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Product</label>
                        <select
                          value={item.productId}
                          onChange={(e) => handleProductSelect(index, e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        >
                          {products.map(p => (
                            <option key={p.id} value={p.id}>
                              {p.name} (Stock: {p.stock} | Cost: {p.costPrice})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Qty</label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => {
                            const val = Math.max(1, parseInt(e.target.value) || 1);
                            setOrderItems(prev => prev.map((it, i) => i === index ? { ...it, quantity: val } : it));
                          }}
                          className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Selling Price</label>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={item.unitPrice}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setOrderItems(prev => prev.map((it, i) => i === index ? { ...it, unitPrice: val } : it));
                          }}
                          className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">Line Discount</label>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={item.discount}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setOrderItems(prev => prev.map((it, i) => i === index ? { ...it, discount: val } : it));
                          }}
                          className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div className="sm:col-span-1 text-center pt-3">
                        <button
                          type="button"
                          onClick={() => handleRemoveItemRow(index)}
                          disabled={orderItems.length <= 1}
                          className="text-slate-400 hover:text-rose-500 disabled:opacity-30 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4 mx-auto" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery, Packaging & Direct Costs */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Logistics & Direct Variable Expenses
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Customer Delivery Fee</label>
                    <input
                      type="number"
                      min="0"
                      value={deliveryChargeCollected}
                      onChange={(e) => setDeliveryChargeCollected(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Actual Courier Cost</label>
                    <input
                      type="number"
                      min="0"
                      value={actualDeliveryExpense}
                      onChange={(e) => setActualDeliveryExpense(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Packaging Box/Poly</label>
                    <input
                      type="number"
                      min="0"
                      value={packagingExpense}
                      onChange={(e) => setPackagingExpense(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Payment/COD Fee</label>
                    <input
                      type="number"
                      min="0"
                      value={paymentFee}
                      onChange={(e) => setPaymentFee(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Details & Live Profit Highlight */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">Payment Collection</span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">Amount Paid Now</label>
                      <input
                        type="number"
                        min="0"
                        max={totalPayable}
                        value={initialAmountPaid}
                        onChange={(e) => setInitialAmountPaid(parseFloat(e.target.value) || 0)}
                        placeholder="0 for full COD"
                        className="w-full px-2.5 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">Payment Method</label>
                      <input
                        type="text"
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  {initialAmountPaid > 0 && (
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">Deposit To Account</label>
                      <select
                        value={paymentAccountId}
                        onChange={(e) => setPaymentAccountId(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        {accounts.map(a => (
                          <option key={a.id} value={a.id}>
                            {a.name} ({formatCurrency(a.balance, settings.currency)})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Live Order Profit Preview Card */}
                <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 text-xs space-y-2">
                  <span className="font-bold text-emerald-800 dark:text-emerald-300">Live Accounting Preview</span>
                  <div className="space-y-1 text-slate-600 dark:text-slate-400">
                    <div className="flex justify-between">
                      <span>Total Invoice Payable:</span>
                      <span className="font-bold font-mono-numbers text-slate-900 dark:text-white">
                        {formatCurrency(totalPayable, settings.currency)}
                      </span>
                    </div>
                    {taxAmount > 0 && (
                      <div className="flex justify-between">
                        <span>Incl. VAT / Tax ({settings.taxRatePercent}%):</span>
                        <span className="font-mono-numbers">
                          {formatCurrency(taxAmount, settings.currency)}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Gross Profit (Sales - COGS):</span>
                      <span className="font-mono-numbers">
                        {formatCurrency(previewBreakdown.grossProfit, settings.currency)}
                      </span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-emerald-200/60 dark:border-emerald-800/60 font-bold text-emerald-700 dark:text-emerald-300">
                      <span>Net Order Contribution:</span>
                      <span className="font-mono-numbers">
                        {formatCurrency(previewBreakdown.netOrderContribution, settings.currency)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => { setIsAddModalOpen(false); setOverrideLimit(false); setOverrideReason(''); }}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={orderSubmitBlocked}
                  title={orderSubmitBlocked ? 'Credit limit exceeded — override with a reason to proceed' : undefined}
                  className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Save & Confirm Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {paymentOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...paymentModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...paymentModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Record Payment for {paymentOrder.orderNumber}
              </h3>
              <button onClick={() => setPaymentOrder(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-500 block mb-1">Amount to Collect ({settings.currency})</label>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-500 block mb-1">Deposit To Account</label>
                <select
                  value={payAccountId}
                  onChange={(e) => setPayAccountId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-500 block mb-1">Payment Method / Channel</label>
                <input
                  type="text"
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPaymentOrder(null)}
                  className="px-3 py-1.5 text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 text-white font-semibold rounded-xl"
                >
                  Confirm Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Refund Modal */}
      {refundOrderTarget && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...refundModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...refundModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Issue Customer Refund for {refundOrderTarget.orderNumber}
              </h3>
              <button onClick={() => setRefundOrderTarget(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRefundSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-500 block mb-1">Refund Amount ({settings.currency})</label>
                <input
                  type="number"
                  min="1"
                  max={refundOrderTarget.amountPaid}
                  step="any"
                  required
                  value={refundAmt}
                  onChange={(e) => setRefundAmt(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-500 block mb-1">Refund From Account</label>
                <select
                  value={refundAccId}
                  onChange={(e) => setRefundAccId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              {/* I13: full return restocks items; partial refunds never restock */}
              <label className="flex items-start gap-2 cursor-pointer p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <input
                  type="checkbox"
                  checked={refundIsFullReturn}
                  onChange={(e) => setRefundIsFullReturn(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-purple-600 focus:ring-purple-500"
                />
                <span>
                  <span className="font-semibold text-slate-700 dark:text-slate-200 block">Full return — restock items</span>
                  <span className="text-[11px] text-slate-500">
                    Only check this when the customer returned all goods AND is refunded in full. Items go back into inventory; otherwise stock is untouched.
                  </span>
                </span>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRefundOrderTarget(null)}
                  className="px-3 py-1.5 text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-purple-600 text-white font-semibold rounded-xl"
                >
                  Process Refund
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* A2: Process Return Modal */}
      {returnTarget && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" {...returnModal.backdropProps}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4" {...returnModal.panelProps}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Process Return — {returnTarget.orderNumber}
              </h3>
              <button onClick={() => setReturnTarget(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleReturnSubmit} className="space-y-4 text-xs">
              {returnError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl px-3 py-2">
                  {returnError}
                </p>
              )}
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {returnTarget.items.map((item, idx) => {
                  const remaining = returnableQty(item);
                  const line = returnLines[idx];
                  return (
                    <div key={idx} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {item.productName}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-numbers">
                          Ordered {item.quantity}
                          {(item.returnedQuantity || 0) > 0 && ` · ${item.returnedQuantity} already returned`}
                          {' · '}{formatCurrency(item.unitPrice, settings.currency)}/unit
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <label className="text-[10px] text-slate-400">Return</label>
                        <input
                          type="number"
                          min={0}
                          max={remaining}
                          value={line?.quantity || 0}
                          onChange={(e) => {
                            const val = Math.max(0, Math.min(remaining, parseInt(e.target.value) || 0));
                            setReturnLines(prev => prev.map((l, i) => i === idx ? { ...l, quantity: val } : l));
                          }}
                          disabled={remaining === 0}
                          className="w-16 px-2 py-1.5 text-xs font-mono-numbers rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-40"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-500">Refund amount ({settings.currency})</label>
                  <button
                    type="button"
                    onClick={() => setReturnRefundAmt(suggestedReturnRefund(returnTarget, returnLines))}
                    className="text-[11px] font-semibold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                  >
                    Use suggested ({formatCurrency(suggestedReturnRefund(returnTarget, returnLines), settings.currency)})
                  </button>
                </div>
                <input
                  type="number"
                  min={0}
                  step="any"
                  value={returnRefundAmt}
                  onChange={(e) => setReturnRefundAmt(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono-numbers text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-slate-500 block mb-1">Refund From Account (optional)</label>
                <select
                  value={returnAccountId}
                  onChange={(e) => setReturnAccountId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="">No account movement (store credit / manual)</option>
                  {accounts.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({formatCurrency(a.balance, settings.currency)})
                    </option>
                  ))}
                </select>
              </div>

              <p className="text-[11px] text-slate-400">
                Returned quantities go back into inventory as customer returns. Fully returning every item marks the order as Returned.
              </p>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReturnTarget(null)}
                  className="px-3 py-1.5 text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-xl"
                >
                  Confirm Return
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Invoice Modal */}
      <InvoiceModal
        order={invoiceOrder}
        onClose={() => setInvoiceOrder(null)}
      />
    </div>
  );
};
