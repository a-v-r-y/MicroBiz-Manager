import React, { useState } from 'react';
import { 
  BarChart3, 
  FileText, 
  Printer, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  Boxes, 
  DollarSign, 
  ShieldCheck, 
  Play, 
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { InventoryValuationMethod } from '../types';
import { 
  formatCurrency, 
  calculateDashboardMetrics, 
  calculateInventoryValuationSummary,
  runAccountingVerificationSuite,
  VerificationTestResult 
} from '../utils/calculations';
import { generatePdfSummaryReport } from '../utils/pdfGenerator';
import { useNotifications } from '../context/NotificationContext';

export const ReportsView: React.FC = () => {
  const { orders, expenses, products, purchaseOrders, accounts, settings, movements } = useApp();
  const { pushNotification } = useNotifications();

  const [activeReportTab, setActiveReportTab] = useState<'pnl' | 'cashflow' | 'receivables' | 'inventory' | 'testing'>('pnl');
  const [valuationMethodTab, setValuationMethodTab] = useState<InventoryValuationMethod>(
    settings.inventoryValuationMethod || 'FIFO'
  );
  const [testResults, setTestResults] = useState<VerificationTestResult[]>(() => runAccountingVerificationSuite());
  const [testStatus, setTestStatus] = useState<string>('idle');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const metrics = calculateDashboardMetrics(
    orders, 
    expenses, 
    products, 
    'all', 
    0, 
    movements, 
    settings.inventoryValuationMethod || 'FIFO'
  );

  const valuationSummary = calculateInventoryValuationSummary(
    products, 
    movements, 
    valuationMethodTab
  );

  const handleRunTests = () => {
    setTestStatus('running');
    setTimeout(() => {
      const results = runAccountingVerificationSuite();
      setTestResults(results);
      setTestStatus('completed');
    }, 300);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    setIsGeneratingPdf(true);
    try {
      generatePdfSummaryReport({
        settings,
        orders,
        expenses,
        products,
        purchaseOrders,
        accounts,
        movements,
        periodLabel: 'Financial Summary'
      });
    } catch (err) {
      console.error('Failed to generate PDF summary:', err);
      pushNotification({
        type: 'system_update',
        title: 'PDF report failed',
        message: 'An error occurred while generating the PDF report. Please try again.',
        priority: 'critical',
        category: 'system',
        targetTab: 'reports',
        actionLabel: 'Open reports',
      });
    } finally {
      setTimeout(() => setIsGeneratingPdf(false), 800);
    }
  };

  const allPassed = testResults.every(t => t.passed);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Financial Reports & Audit Verification
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Strict GAAP and managerial accounting statements, cash flow reconciliation, and automated calculation test runners.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadPdf}
            disabled={isGeneratingPdf}
            className="no-print inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white shadow-xs transition cursor-pointer"
            title="Download executive 1-page PDF summary report"
          >
            <Download className="w-4 h-4" />
            {isGeneratingPdf ? 'Generating PDF...' : 'Download PDF Summary'}
          </button>
          <button
            onClick={handlePrint}
            className="no-print inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            Print Report
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="no-print flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveReportTab('pnl')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeReportTab === 'pnl'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Profit & Loss (P&L)
        </button>

        <button
          onClick={() => setActiveReportTab('cashflow')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeReportTab === 'cashflow'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Cash Flow Statement
        </button>

        <button
          onClick={() => setActiveReportTab('receivables')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeReportTab === 'receivables'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Receivables & Payables Aging
        </button>

        <button
          onClick={() => setActiveReportTab('inventory')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeReportTab === 'inventory'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Inventory Valuation
        </button>

        <button
          onClick={() => setActiveReportTab('testing')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
            activeReportTab === 'testing'
              ? 'bg-emerald-600 text-white'
              : 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/50 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          Automated Calculation Tests ({testResults.length})
        </button>
      </div>

      {/* 1. Profit & Loss Statement */}
      {activeReportTab === 'pnl' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Income Statement (Profit & Loss)
              </h2>
              <p className="text-xs text-slate-500">
                For {settings.businessName} • Currency: {settings.currency} • Accounting Basis: Accrual
              </p>
            </div>
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="no-print inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition cursor-pointer self-start sm:self-auto"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isGeneratingPdf ? 'Generating PDF...' : 'Download PDF Summary'}</span>
            </button>
          </div>

          <div className="space-y-4 text-xs font-mono-numbers">
            {/* Revenue Section */}
            <div className="space-y-2">
              <div className="text-slate-900 dark:text-white font-bold font-sans text-sm pb-1 border-b border-slate-100 dark:border-slate-800">
                1. REVENUE FROM MERCHANDISE & SERVICES
              </div>
              <div className="flex justify-between pl-4 text-slate-600 dark:text-slate-400">
                <span>Gross Merchandise Sales (Item Retail Prices):</span>
                <span>{formatCurrency(metrics.totalGrossSales, settings.currency)}</span>
              </div>
              <div className="flex justify-between pl-4 text-rose-600">
                <span>Less: Trade Discounts & Promo Reductions:</span>
                <span>-{formatCurrency(metrics.totalGrossSales - metrics.netMerchandiseSales, settings.currency)}</span>
              </div>
              <div className="flex justify-between pl-4 font-semibold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800/40 py-1 px-2 rounded-lg">
                <span>Net Merchandise Sales:</span>
                <span>{formatCurrency(metrics.netMerchandiseSales, settings.currency)}</span>
              </div>
              <div className="flex justify-between pl-4 text-slate-600 dark:text-slate-400">
                <span>Delivery Charges Collected from Customers:</span>
                <span>+{formatCurrency(metrics.totalNetRevenue - metrics.netMerchandiseSales, settings.currency)}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900 dark:text-white py-1 px-2 border-t border-b border-slate-200 dark:border-slate-800 text-sm">
                <span>TOTAL RECOGNIZED REVENUE:</span>
                <span>{formatCurrency(metrics.totalNetRevenue, settings.currency)}</span>
              </div>
            </div>

            {/* Cost of Goods Sold Section */}
            <div className="space-y-2 pt-2">
              <div className="text-slate-900 dark:text-white font-bold font-sans text-sm pb-1 border-b border-slate-100 dark:border-slate-800">
                2. COST OF GOODS SOLD (COGS)
              </div>
              <div className="flex justify-between pl-4 text-rose-600">
                <span>Direct Product Acquisition Cost ({settings.inventoryValuationMethod} snapshot):</span>
                <span>-{formatCurrency(metrics.totalCOGS, settings.currency)}</span>
              </div>
              <div className="flex justify-between font-bold text-emerald-600 dark:text-emerald-400 py-1.5 px-2 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-xl text-sm">
                <span>GROSS PROFIT (Gross Margin {metrics.grossMarginPercent}%):</span>
                <span>{formatCurrency(metrics.grossProfit, settings.currency)}</span>
              </div>
            </div>

            {/* Operating Overhead Section */}
            <div className="space-y-2 pt-2">
              <div className="text-slate-900 dark:text-white font-bold font-sans text-sm pb-1 border-b border-slate-100 dark:border-slate-800">
                3. OPERATING OVERHEAD & EXPENSES (OPEX)
              </div>
              {expenses.filter(e => e.type === 'operating').map(e => (
                <div key={e.id} className="flex justify-between pl-4 text-slate-600 dark:text-slate-400">
                  <span>{e.category} — {e.description}:</span>
                  <span className="text-rose-600">-{formatCurrency(e.amount, settings.currency)}</span>
                </div>
              ))}
              <div className="flex justify-between pl-4 font-semibold text-rose-600 py-1 border-t border-slate-100 dark:border-slate-800">
                <span>Total Operating Expenses:</span>
                <span>-{formatCurrency(metrics.totalOperatingExpenses, settings.currency)}</span>
              </div>
            </div>

            {/* Net Operating Profit Final */}
            <div className="pt-4 border-t-2 border-slate-300 dark:border-slate-700">
              <div className={`flex justify-between p-3 rounded-2xl text-base font-extrabold ${
                metrics.netOperatingProfit >= 0
                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200'
                  : 'bg-rose-100 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200'
              }`}>
                <span>NET OPERATING PROFIT (Net Margin {metrics.netOperatingMarginPercent}%):</span>
                <span>{formatCurrency(metrics.netOperatingProfit, settings.currency)}</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans mt-2">
                This is your authoritative operating profit before taxes and unallocated partner distributions.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 2. Cash Flow Statement */}
      {activeReportTab === 'cashflow' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Statement of Cash Flows
            </h2>
            <p className="text-xs text-slate-500">
              Actual money received and disbursed across all bank and cash accounts.
            </p>
          </div>

          <div className="space-y-4 text-xs font-mono-numbers">
            <div className="space-y-2">
              <div className="text-slate-900 dark:text-white font-bold font-sans text-sm pb-1 border-b border-slate-100 dark:border-slate-800">
                OPERATING ACTIVITIES
              </div>
              <div className="flex justify-between pl-4 text-emerald-600">
                <span>Customer Cash Inflows (Order Payments):</span>
                <span>+{formatCurrency(metrics.totalCashCollected, settings.currency)}</span>
              </div>
              <div className="flex justify-between pl-4 text-rose-600">
                <span>Supplier Payments Disbursed:</span>
                <span>-{formatCurrency(purchaseOrders.reduce((s, p) => s + (p.amountPaid || 0), 0), settings.currency)}</span>
              </div>
              <div className="flex justify-between pl-4 text-rose-600">
                <span>Operating Overhead Disbursed:</span>
                <span>-{formatCurrency(metrics.totalOperatingExpenses, settings.currency)}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex justify-between font-bold text-sm">
              <span className="font-sans">Total Liquid Cash Across Accounts:</span>
              <span className="text-slate-900 dark:text-white">
                {formatCurrency(accounts.reduce((s, a) => s + a.balance, 0), settings.currency)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 3. Receivables & Payables Aging */}
      {activeReportTab === 'receivables' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Accounts Receivable (Customer Due)
            </h3>
            <div className="text-2xl font-bold font-mono-numbers text-amber-600">
              {formatCurrency(metrics.outstandingReceivables, settings.currency)}
            </div>
            <p className="text-xs text-slate-400">
              Outstanding balances on dispatched and delivered orders.
            </p>

            <div className="space-y-2 pt-2">
              {orders.filter(o => o.orderStatus !== 'cancelled' && (o.totalAmount - (o.amountPaid || 0)) > 0).map(o => (
                <div key={o.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{o.customerName}</div>
                    <div className="text-[10px] text-slate-400">{o.orderNumber} • {o.customerPhone}</div>
                  </div>
                  <div className="text-right font-bold font-mono-numbers text-amber-600">
                    {formatCurrency(o.totalAmount - (o.amountPaid || 0), settings.currency)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Accounts Payable (Supplier Due)
            </h3>
            <div className="text-2xl font-bold font-mono-numbers text-rose-600">
              {formatCurrency(metrics.outstandingPayables, settings.currency)}
            </div>
            <p className="text-xs text-slate-400">
              Outstanding balance payable to factory and technology suppliers.
            </p>

            <div className="space-y-2 pt-2">
              {purchaseOrders.filter(p => p.status !== 'cancelled' && (p.totalAmount - (p.amountPaid || 0)) > 0).map(p => (
                <div key={p.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{p.supplierName}</div>
                    <div className="text-[10px] text-slate-400">{p.poNumber}</div>
                  </div>
                  <div className="text-right font-bold font-mono-numbers text-rose-600">
                    {formatCurrency(p.totalAmount - (p.amountPaid || 0), settings.currency)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. Inventory Valuation Report (FIFO vs LIFO vs WAC) */}
      {activeReportTab === 'inventory' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Inventory Valuation & Costing Report
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  {valuationMethodTab} Active
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Authoritative inventory balance sheet valuation comparing FIFO, LIFO, and Weighted Average Cost with LIFO Reserve calculation.
              </p>
            </div>

            {/* Method Switcher */}
            <div className="inline-flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold self-start sm:self-auto">
              <button
                onClick={() => setValuationMethodTab('FIFO')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  valuationMethodTab === 'FIFO'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                FIFO (First In, First Out)
              </button>
              <button
                onClick={() => setValuationMethodTab('LIFO')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  valuationMethodTab === 'LIFO'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                LIFO (Last In, First Out)
              </button>
              <button
                onClick={() => setValuationMethodTab('WAC')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  valuationMethodTab === 'WAC'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                WAC (Average)
              </button>
            </div>
          </div>

          {/* 4 Summary Valuation Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60">
              <span className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold block mb-1">
                FIFO Total Valuation
              </span>
              <div className="text-xl font-bold font-mono-numbers text-emerald-900 dark:text-emerald-300">
                {formatCurrency(valuationSummary.fifoTotalValuation, settings.currency)}
              </div>
              <span className="text-[10px] text-emerald-600">
                Newest batch prices on balance sheet
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60">
              <span className="text-xs text-blue-700 dark:text-blue-400 font-semibold block mb-1">
                LIFO Total Valuation
              </span>
              <div className="text-xl font-bold font-mono-numbers text-blue-900 dark:text-blue-300">
                {formatCurrency(valuationSummary.lifoTotalValuation, settings.currency)}
              </div>
              <span className="text-[10px] text-blue-600">
                Oldest base layers in ending inventory
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/60">
              <span className="text-xs text-purple-700 dark:text-purple-400 font-semibold block mb-1">
                LIFO Reserve (FIFO - LIFO)
              </span>
              <div className="text-xl font-bold font-mono-numbers text-purple-900 dark:text-purple-300">
                {formatCurrency(valuationSummary.lifoReserve, settings.currency)}
              </div>
              <span className="text-[10px] text-purple-600">
                Balance sheet variance between methods
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
              <span className="text-xs text-slate-500 block mb-1">Warehouse Physical Units</span>
              <div className="text-xl font-bold font-mono-numbers text-slate-900 dark:text-white">
                {valuationSummary.totalStockUnits} units
              </div>
              <span className="text-[10px] text-slate-400">
                Across {products.length} catalog products
              </span>
            </div>
          </div>

          {/* Educational Callout */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 space-y-2">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Accounting Standard Comparison: FIFO vs LIFO Impact on Financial Statements
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] leading-relaxed">
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 space-y-1">
                <span className="font-bold text-emerald-700 dark:text-emerald-400 block">FIFO (First-In, First-Out)</span>
                <p>
                  Assumes earliest purchased goods are sold first. During inflationary periods (rising supply costs), FIFO results in <strong>higher ending inventory valuation</strong> on the balance sheet, <strong>lower Cost of Goods Sold (COGS)</strong>, and <strong>higher reported gross profits</strong>.
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 space-y-1">
                <span className="font-bold text-blue-700 dark:text-blue-400 block">LIFO (Last-In, First-Out)</span>
                <p>
                  Assumes latest purchased goods are sold first. During inflationary periods, LIFO charges the newest (higher) costs against revenue, resulting in <strong>higher recognized COGS</strong>, <strong>lower reported net income</strong>, and <strong>tax deferral</strong>, while creating a <strong>LIFO Reserve</strong> on the balance sheet.
                </p>
              </div>
            </div>
          </div>

          {/* Product Valuation Comparison Matrix Table */}
          <div className="space-y-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Product-by-Product Valuation Matrix
            </h3>
            <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold">
                  <tr>
                    <th className="py-3 px-4">Product Name & SKU</th>
                    <th className="py-3 px-4 text-center">Stock</th>
                    <th className="py-3 px-4 text-right">FIFO Total (Unit)</th>
                    <th className="py-3 px-4 text-right">LIFO Total (Unit)</th>
                    <th className="py-3 px-4 text-right">WAC Total (Unit)</th>
                    <th className="py-3 px-4 text-right">LIFO Reserve</th>
                    <th className="py-3 px-4 text-center">Batches</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {valuationSummary.productCostings.map((c) => (
                    <tr key={c.productId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">{c.productName}</div>
                        <div className="text-[10px] text-slate-400 font-mono-numbers">{c.sku}</div>
                      </td>

                      <td className="py-3 px-4 text-center font-bold font-mono-numbers text-slate-900 dark:text-white">
                        {c.currentStock}
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers">
                        <div className="font-bold text-emerald-600 dark:text-emerald-400">
                          {formatCurrency(c.fifoValuation, settings.currency)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          @{formatCurrency(c.fifoUnitCost, settings.currency)}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers">
                        <div className="font-bold text-blue-600 dark:text-blue-400">
                          {formatCurrency(c.lifoValuation, settings.currency)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          @{formatCurrency(c.lifoUnitCost, settings.currency)}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers">
                        <div className="font-bold text-purple-600 dark:text-purple-400">
                          {formatCurrency(c.wacValuation, settings.currency)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          @{formatCurrency(c.wacUnitCost, settings.currency)}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono-numbers font-bold">
                        <span className={c.lifoReserve > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400'}>
                          {c.lifoReserve > 0 ? formatCurrency(c.lifoReserve, settings.currency) : '৳0.00'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center font-mono-numbers text-slate-500">
                        {c.batches.length} receipts
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5. Automated Accounting Test Runner (Spec Section 22) */}
      {activeReportTab === 'testing' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Automated Calculation Verification Suite
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Verifies all financial formulas specified in Section 22: discounts, delivery subsidies, partial payments, refund deduction, and transfer neutrality.
              </p>
            </div>

            <button
              onClick={handleRunTests}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              Re-run Test Suite
            </button>
          </div>

          {/* Test Status Banner — reflects the ACTUAL per-test results (I6) */}
          {(() => {
            const failedCount = testResults.filter(t => !t.passed).length;
            return (
              <div className={`p-4 rounded-2xl border flex items-center gap-3 ${
                allPassed
                  ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-300'
                  : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-300'
              }`}>
                {allPassed
                  ? <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  : <AlertCircle className="w-6 h-6 text-rose-600 shrink-0" />
                }
                <div>
                  <h4 className="font-bold text-sm">
                    {allPassed
                      ? `All ${testResults.length} Mathematical Tests Passed with 100% Precision`
                      : `${failedCount} of ${testResults.length} Mathematical Tests FAILED — review required`}
                  </h4>
                  <p className="text-xs opacity-90 mt-0.5">
                    {allPassed
                      ? 'Zero rounding errors or floating-point leaks detected. All formulas conform to Bangladeshi and international accounting rules.'
                      : 'One or more formulas produced unexpected results. Inspect the failed test cards below before trusting these figures.'}
                  </p>
                </div>
              </div>
            );
          })()}

          {/* Individual Test Cards */}
          <div className="space-y-3">
            {testResults.map((t) => (
              <div 
                key={t.id}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${t.passed ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {t.name}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">
                      {t.category}
                    </span>
                  </div>

                  {t.passed ? (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-[10px]">
                      PASSED
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 font-bold text-[10px]">
                      FAILED
                    </span>
                  )}
                </div>

                <p className="text-slate-500 dark:text-slate-400">
                  {t.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono-numbers text-[11px]">
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <span className="text-slate-400 block text-[10px] font-sans">Expected:</span>
                    <span className="text-slate-700 dark:text-slate-300 font-semibold">{t.expected}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <span className="text-slate-400 block text-[10px] font-sans">Calculated:</span>
                    <span className={`font-semibold ${t.passed ? 'text-emerald-600' : 'text-rose-600'}`}>{t.actual}</span>
                  </div>
                </div>

                <p className={`text-[10px] font-medium ${t.passed ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}`}>
                  {t.passed ? `✓ ${t.details}` : `✗ FAILED — ${t.details}`}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
