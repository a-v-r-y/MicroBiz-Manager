import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ShoppingCart, 
  Package, 
  Boxes, 
  Receipt, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Calendar, 
  ArrowUpRight, 
  Plus, 
  Wallet, 
  CreditCard, 
  HelpCircle,
  BarChart2,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateDashboardMetrics,
  formatCurrency,
  calculatePeriodMetrics,
  filterOrdersByWindow,
  filterExpensesByWindow,
  getPreviousPeriodWindow,
  previousPeriodLabel,
  bucketRevenueByRange,
  PeriodTrendMetrics,
  RevenueBucket
} from '../utils/calculations';
import { NavTab } from './Sidebar';

/**
 * B2: period-over-period delta chip. For revenue/profit metrics up is good;
 * for cost metrics (invert) up is bad.
 */
const DeltaChip: React.FC<{
  current: number;
  previous: number;
  invert?: boolean;
  label: string;
  className?: string;
}> = ({ current, previous, invert = false, label, className = '' }) => {
  if (previous === 0 && current === 0) return null;
  let content: React.ReactNode;
  let good = false;
  let bad = false;
  if (previous === 0) {
    content = <>New</>;
    good = !invert;
    bad = invert;
  } else {
    const pct = ((current - previous) / Math.abs(previous)) * 100;
    const rounded = Math.abs(pct) < 0.05 ? 0 : pct;
    const up = rounded > 0;
    const down = rounded < 0;
    good = invert ? down : up;
    bad = invert ? up : down;
    const Icon = up ? TrendingUp : down ? TrendingDown : null;
    content = (
      <>
        {Icon && <Icon className="w-3 h-3" />}
        <span>{up ? '+' : ''}{rounded.toFixed(1)}%</span>
      </>
    );
  }
  return (
    <span
      title={label}
      className={`inline-flex items-center gap-1 text-[11px] font-bold ${
        good
          ? 'text-emerald-600 dark:text-emerald-400'
          : bad
          ? 'text-rose-600 dark:text-rose-400'
          : 'text-slate-400'
      } ${className}`}
    >
      {content}
    </span>
  );
};

/** B2: lightweight pure-SVG revenue sparkline — no new dependencies. */
const RevenueSparkline: React.FC<{ data: RevenueBucket[]; onNavigate: (tab: NavTab) => void }> = ({ data, onNavigate }) => {
  const W = 600;
  const H = 120;
  const PAD = 10;
  const max = Math.max(...data.map(d => d.value), 0);
  if (data.length === 0 || max === 0) {
    return (
      <div className="h-[120px] flex flex-col items-center justify-center gap-2 text-xs text-slate-400">
        <p>No revenue recorded in this period yet.</p>
        <button
          onClick={() => onNavigate('orders')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" /> Record your first order
        </button>
      </div>
    );
  }
  const stepX = data.length > 1 ? (W - PAD * 2) / (data.length - 1) : 0;
  const pts = data.map((d, i) => {
    const x = PAD + i * stepX;
    const y = H - PAD - (d.value / max) * (H - PAD * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const area = `${PAD},${H - PAD} ${pts.join(' ')} ${W - PAD},${H - PAD}`;
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full h-[120px]"
      preserveAspectRatio="none"
      role="img"
      aria-label="Revenue trend across the selected period"
    >
      <title>Revenue trend</title>
      <polygon points={area} fill="rgba(16,185,129,0.12)" />
      <polyline
        points={pts.join(' ')}
        fill="none"
        stroke="#10b981"
        strokeWidth="2.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
};

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenQuickAction: (action: 'order' | 'product' | 'expense' | 'calculator') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenQuickAction
}) => {
  const { orders, expenses, products, purchaseOrders, accounts, settings, movements } = useApp();
  const [dateRange, setDateRange] = useState('30days');

  // Calculate outstanding supplier payables from POs
  const outstandingPayables = purchaseOrders.reduce((sum, po) => {
    if (po.status !== 'cancelled') {
      const balance = po.totalAmount - (po.amountPaid || 0);
      return sum + Math.max(0, balance);
    }
    return sum;
  }, 0);

  const metrics = calculateDashboardMetrics(
    orders, 
    expenses, 
    products, 
    dateRange, 
    outstandingPayables,
    movements,
    settings.inventoryValuationMethod || 'FIFO'
  );

  // B2: period-over-period comparison against the previous equivalent window
  const prevWindow = getPreviousPeriodWindow(dateRange);
  const prevMetrics: PeriodTrendMetrics | null = prevWindow
    ? calculatePeriodMetrics(
        filterOrdersByWindow(orders, prevWindow.start, prevWindow.end),
        filterExpensesByWindow(expenses, prevWindow.start, prevWindow.end)
      )
    : null;
  const prevLabel = previousPeriodLabel(dateRange);

  // B2: revenue buckets for the sparkline, aligned with the active date range
  const revenueSeries = bucketRevenueByRange(orders, dateRange);
  const rangeLabels: Record<string, string> = {
    today: 'Today',
    yesterday: 'Yesterday',
    '7days': 'Last 7 days',
    '30days': 'Last 30 days',
    thisMonth: 'This month',
    lastMonth: 'Last month',
    thisYear: 'This year',
    all: 'All time'
  };

  // Total cash balance across all financial accounts
  const totalCashBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // Best selling products by units sold in the active orders
  const productSalesMap = new Map<string, { name: string; units: number; revenue: number }>();
  orders.filter(o => o.orderStatus !== 'cancelled').forEach(order => {
    order.items.forEach(item => {
      const existing = productSalesMap.get(item.productId) || { name: item.productName, units: 0, revenue: 0 };
      existing.units += item.quantity;
      existing.revenue += (item.quantity * item.unitPrice) - (item.discount || 0);
      productSalesMap.set(item.productId, existing);
    });
  });

  const bestSellers = Array.from(productSalesMap.values())
    .sort((a, b) => b.units - a.units)
    .slice(0, 4);

  // Order status counts
  const totalOrdersCount = orders.length;
  const statusDeliveredCount = orders.filter(o => o.orderStatus === 'delivered').length;
  const statusPendingCount = orders.filter(o => o.orderStatus === 'pending').length;
  const statusProcessingCount = orders.filter(o => ['confirmed', 'processing', 'ready', 'shipped'].includes(o.orderStatus)).length;
  const statusCancelledCount = orders.filter(o => o.orderStatus === 'cancelled').length;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Banner: Greeting, Time Range Filter & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            Business Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Operational and accounting summary for <span className="font-semibold text-slate-700 dark:text-slate-300">{settings.businessName}</span>
          </p>
        </div>

        {/* Filters and Date Dropdown */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="pl-9 pr-8 py-2 text-xs font-semibold rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 shadow-2xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 cursor-pointer"
            >
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="7days">Last 7 Days</option>
              <option value="30days">Last 30 Days</option>
              <option value="thisMonth">This Month</option>
              <option value="lastMonth">Previous Month</option>
              <option value="thisYear">This Year</option>
              <option value="all">All Time</option>
            </select>
          </div>

          <button
            onClick={() => onOpenQuickAction('order')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Order
          </button>
        </div>
      </div>

      {/* Quick Action Shortcuts Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => onOpenQuickAction('order')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <ShoppingCart className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">+ Add Order</div>
          <div className="text-[10px] text-slate-400">Record sales & COD</div>
        </button>

        <button
          onClick={() => onOpenQuickAction('product')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <Package className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">+ Add Product</div>
          <div className="text-[10px] text-slate-400">Manage SKU & price</div>
        </button>

        <button
          onClick={() => onOpenQuickAction('expense')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <Receipt className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">+ Record Expense</div>
          <div className="text-[10px] text-slate-400">Rent, Ads, Utilities</div>
        </button>

        <button
          onClick={() => onOpenQuickAction('calculator')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <DollarSign className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Profit Calculator</div>
          <div className="text-[10px] text-slate-400">Verify unit margins</div>
        </button>

        <button
          onClick={() => onNavigate('inventory')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <Boxes className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Adjust Stock</div>
          <div className="text-[10px] text-slate-400">Audit & count checks</div>
        </button>

        <button
          onClick={() => onNavigate('reports')}
          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-2xs text-left group transition cursor-pointer"
        >
          <div className="w-7 h-7 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
            <BarChart2 className="w-4 h-4" />
          </div>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Financial Reports</div>
          <div className="text-[10px] text-slate-400">P&L & test runner</div>
        </button>
      </div>

      {/* Primary Financial Indicators Cards (4 Key Metrics) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Sales */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Sales</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.netMerchandiseSales, settings.currency)}
          </div>
          {prevMetrics && (
            <DeltaChip current={metrics.netMerchandiseSales} previous={prevMetrics.netSales} label={prevLabel} />
          )}
          <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
            <span>Gross Sales:</span>
            <span className="font-mono-numbers">{formatCurrency(metrics.totalGrossSales, settings.currency)}</span>
          </div>
        </div>

        {/* Cost of Goods Sold */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Cost of Goods (COGS)</span>
            <div className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.totalCOGS, settings.currency)}
          </div>
          {prevMetrics && (
            <DeltaChip current={metrics.totalCOGS} previous={prevMetrics.cogs} invert label={prevLabel} />
          )}
          <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
            <span>Gross Profit:</span>
            <span className="font-bold text-emerald-600 font-mono-numbers">
              {formatCurrency(metrics.grossProfit, settings.currency)}
            </span>
          </div>
        </div>

        {/* Operating Expenses */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Operating Expenses</span>
            <div className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.totalOperatingExpenses, settings.currency)}
          </div>
          {prevMetrics && (
            <DeltaChip current={metrics.totalOperatingExpenses} previous={prevMetrics.operatingExpenses} invert label={prevLabel} />
          )}
          <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
            <span>Direct Order Contrib:</span>
            <span className="font-mono-numbers">{formatCurrency(metrics.directOrderContribution, settings.currency)}</span>
          </div>
        </div>

        {/* Net Operating Profit */}
        <div className={`rounded-2xl p-5 border shadow-2xs space-y-2 ${
          metrics.netOperatingProfit >= 0
            ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
            : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800/60'
        }`}>
          <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Operating Profit</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
              {metrics.netOperatingMarginPercent}% Margin
            </span>
          </div>
          <div className={`text-2xl font-bold font-mono-numbers ${
            metrics.netOperatingProfit >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
          }`}>
            {formatCurrency(metrics.netOperatingProfit, settings.currency)}
          </div>
          {prevMetrics && (
            <DeltaChip current={metrics.netOperatingProfit} previous={prevMetrics.netOperatingProfit} label={prevLabel} />
          )}
          <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
            Recognized revenue minus COGS and operating overhead
          </div>
        </div>
      </div>

      {/* Secondary Financial & Cash Flow Indicators (4 Cards) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Estimated Cash Balance */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Total Cash Balance</span>
            <Wallet className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-lg font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(totalCashBalance, settings.currency)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Across {accounts.length} business accounts</div>
        </div>

        {/* Outstanding Receivables */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Customer Receivables</span>
            <DollarSign className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-lg font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.outstandingReceivables, settings.currency)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Uncollected deliveries & orders</div>
        </div>

        {/* Outstanding Payables */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Supplier Payables</span>
            <CreditCard className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <div className="text-lg font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.outstandingPayables, settings.currency)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Due to suppliers on POs</div>
        </div>

        {/* Inventory Valuation */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Inventory Valuation</span>
            <Boxes className="w-3.5 h-3.5 text-indigo-500" />
          </div>
          <div className="text-lg font-bold font-mono-numbers text-slate-900 dark:text-white">
            {formatCurrency(metrics.totalInventoryValuation, settings.currency)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">At acquisition cost ({settings.inventoryValuationMethod})</div>
        </div>
      </div>

      {/* Operational Low Stock Alert Banner (if any) */}
      {(metrics.lowStockCount > 0 || metrics.outOfStockCount > 0) && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs sm:text-sm font-bold text-amber-900 dark:text-amber-200">
                Inventory Alerts: {metrics.outOfStockCount} out of stock, {metrics.lowStockCount} running low
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-400">
                Reorder timely to avoid lost orders and customer backorders.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('inventory')}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-slate-900 text-amber-900 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-50 transition cursor-pointer"
          >
            Review Inventory Ledger
          </button>
        </div>
      )}

      {/* Data-Driven Visual Charts and Breakdown (Real recorded data) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Order Status Distribution & Top Sellers */}
        <div className="lg:col-span-7 space-y-6">
          {/* Order Status Distribution Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Order Status Breakdown
                </h3>
                <p className="text-xs text-slate-400">
                  {totalOrdersCount} total transactions recorded
                </p>
              </div>
              <button
                onClick={() => onNavigate('orders')}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View all</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Visual segmented bar */}
            <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden flex">
              <div 
                style={{ width: `${totalOrdersCount ? (statusDeliveredCount / totalOrdersCount) * 100 : 0}%` }}
                className="bg-emerald-500 h-full transition-all" 
                title={`Delivered: ${statusDeliveredCount}`}
              />
              <div 
                style={{ width: `${totalOrdersCount ? (statusProcessingCount / totalOrdersCount) * 100 : 0}%` }}
                className="bg-blue-500 h-full transition-all" 
                title={`In Processing: ${statusProcessingCount}`}
              />
              <div 
                style={{ width: `${totalOrdersCount ? (statusPendingCount / totalOrdersCount) * 100 : 0}%` }}
                className="bg-amber-500 h-full transition-all" 
                title={`Pending: ${statusPendingCount}`}
              />
              <div 
                style={{ width: `${totalOrdersCount ? (statusCancelledCount / totalOrdersCount) * 100 : 0}%` }}
                className="bg-rose-400 h-full transition-all" 
                title={`Cancelled: ${statusCancelledCount}`}
              />
            </div>

            {/* Legend pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Delivered</span>
                </div>
                <div className="text-base font-bold font-mono-numbers text-slate-800 dark:text-slate-100 mt-1">
                  {statusDeliveredCount}
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span>In Transit</span>
                </div>
                <div className="text-base font-bold font-mono-numbers text-slate-800 dark:text-slate-100 mt-1">
                  {statusProcessingCount}
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <span>Pending</span>
                </div>
                <div className="text-base font-bold font-mono-numbers text-slate-800 dark:text-slate-100 mt-1">
                  {statusPendingCount}
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-rose-400"></span>
                  <span>Cancelled</span>
                </div>
                <div className="text-base font-bold font-mono-numbers text-slate-800 dark:text-slate-100 mt-1">
                  {statusCancelledCount}
                </div>
              </div>
            </div>
          </div>

          {/* Best-Selling Products Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Best-Selling Products
              </h3>
              <button
                onClick={() => onNavigate('products')}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View catalog</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {bestSellers.length === 0 ? (
              <div className="py-4 text-center">
                <p className="text-xs text-slate-400">No product sales recorded yet.</p>
                <button
                  onClick={() => onNavigate('products')}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add your first product
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {bestSellers.map((item, idx) => (
                  <div 
                    key={idx}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-xs">
                        {item.name}
                      </span>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-bold font-mono-numbers text-slate-900 dark:text-white">
                        {formatCurrency(item.revenue, settings.currency)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {item.units} units sold
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column (5 cols): Operating Expenses by Category & Profit Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          {/* B2: Revenue Trend sparkline */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Revenue Trend
                </h3>
                <p className="text-xs text-slate-400">
                  {rangeLabels[dateRange] || dateRange} · net revenue
                </p>
              </div>
              {prevMetrics && (
                <DeltaChip
                  current={metrics.totalNetRevenue}
                  previous={prevMetrics.netRevenue}
                  label={prevLabel}
                />
              )}
            </div>
            <RevenueSparkline data={revenueSeries} onNavigate={onNavigate} />
            {revenueSeries.length > 0 && (
              <div className="flex justify-between text-[10px] text-slate-400 font-mono-numbers">
                <span>{revenueSeries[0].label}</span>
                <span>{revenueSeries[revenueSeries.length - 1].label}</span>
              </div>
            )}
          </div>

          {/* Revenue vs Expense Summary Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Revenue & Expense Flow
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400 mb-1">
                  <span>Net Recognized Revenue:</span>
                  <span className="font-bold font-mono-numbers text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(metrics.totalNetRevenue, settings.currency)}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full w-full"></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400 mb-1">
                  <span>Inventory Product Cost (COGS):</span>
                  <span className="font-bold font-mono-numbers text-amber-600 dark:text-amber-400">
                    {formatCurrency(metrics.totalCOGS, settings.currency)}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div 
                    style={{ width: `${metrics.totalNetRevenue ? Math.min(100, (metrics.totalCOGS / metrics.totalNetRevenue) * 100) : 0}%` }}
                    className="h-full bg-amber-500 rounded-full transition-all"
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400 mb-1">
                  <span>Operating Overhead:</span>
                  <span className="font-bold font-mono-numbers text-rose-600 dark:text-rose-400">
                    {formatCurrency(metrics.totalOperatingExpenses, settings.currency)}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div 
                    style={{ width: `${metrics.totalNetRevenue ? Math.min(100, (metrics.totalOperatingExpenses / metrics.totalNetRevenue) * 100) : 0}%` }}
                    className="h-full bg-rose-500 rounded-full transition-all"
                  ></div>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-300">Retained Operating Profit:</span>
              <span className={`font-mono-numbers ${metrics.netOperatingProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {formatCurrency(metrics.netOperatingProfit, settings.currency)}
              </span>
            </div>
          </div>

          {/* Recent Expenses List */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Recent Expenses
              </h3>
              <button
                onClick={() => onNavigate('expenses')}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>All expenses</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2">
              {expenses.slice(0, 3).map((exp) => (
                <div 
                  key={exp.id}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{exp.category}</div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[160px]">{exp.description}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold font-mono-numbers text-rose-600 dark:text-rose-400">
                      -{formatCurrency(exp.amount, settings.currency)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {new Date(exp.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
