import React, { useState } from 'react';
import {
  UserCog,
  Plus,
  Copy,
  Check,
  ShieldAlert,
  KeyRound,
  Power,
  PowerOff,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { ConfirmDialog } from './ConfirmDialog';
import { useModalBehavior } from '../hooks/useModalBehavior';
import { generateTempPassword } from '../utils/cryptoAuth';
import { UserRole } from '../types';
import { AuthUser } from '../types/auth';

const ROLE_OPTIONS: Array<{ value: UserRole; label: string; blurb: string }> = [
  { value: 'owner', label: 'Owner', blurb: 'Full access, including team management' },
  { value: 'admin', label: 'Admin', blurb: 'Everything except settings, restores and team' },
  { value: 'sales', label: 'Sales', blurb: 'Orders, customers and reports' },
  { value: 'inventory', label: 'Inventory', blurb: 'Products, stock and purchase orders' },
  { value: 'accountant', label: 'Accountant', blurb: 'Expenses, cash accounts and reports' },
  { value: 'viewer', label: 'Viewer', blurb: 'Reports only' }
];

const roleBadgeClass: Record<UserRole, string> = {
  owner: 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
  admin: 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
  sales: 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
  inventory: 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
  accountant: 'bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800',
  viewer: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
};

export const TeamView: React.FC = () => {
  const {
    currentUser,
    allUsers,
    can,
    updateUserRole,
    setUserActive,
    adminResetPassword,
    createUser
  } = useAuth();
  const { pushNotification } = useNotifications();

  const [addOpen, setAddOpen] = useState(false);
  const [fName, setFName] = useState('');
  const [fEmail, setFEmail] = useState('');
  const [fPassword, setFPassword] = useState('');
  const [fRole, setFRole] = useState<UserRole>('sales');
  const [fError, setFError] = useState('');
  const [fBusy, setFBusy] = useState(false);

  const [confirmAction, setConfirmAction] = useState<{ kind: 'deactivate' | 'activate'; user: AuthUser } | null>(null);
  const [resetConfirm, setResetConfirm] = useState<AuthUser | null>(null);
  const [tempPw, setTempPw] = useState<{ name: string; pw: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const { backdropProps, panelProps } = useModalBehavior(
    addOpen,
    () => setAddOpen(false),
    'Add team member'
  );

  const notify = (
    title: string,
    message: string,
    priority: 'success' | 'critical' | 'warning' | 'info'
  ) => {
    pushNotification({
      type: priority === 'critical' ? 'security_alert' : 'system_update',
      title,
      message,
      priority,
      category: 'system',
      targetTab: 'settings'
    });
  };

  if (!can('users.manage')) {
    return (
      <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Team management is owner-only</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            Only the business owner can view and manage team accounts. Ask your owner to make changes.
          </p>
        </div>
      </div>
    );
  }

  const handleRoleChange = async (u: AuthUser, role: UserRole) => {
    if (u.role === role || busyId) return;
    setBusyId(u.id);
    const res = await updateUserRole(u.id, role);
    setBusyId(null);
    if (res.success) {
      notify('Role updated', `${u.name} is now ${role}.`, 'success');
    } else {
      notify('Could not change role', res.error || 'Failed to update role.', 'critical');
    }
  };

  const doToggleActive = async () => {
    if (!confirmAction) return;
    const { kind, user } = confirmAction;
    setConfirmAction(null);
    setBusyId(user.id);
    const res = await setUserActive(user.id, kind === 'activate');
    setBusyId(null);
    if (res.success) {
      notify(
        kind === 'activate' ? 'Account reactivated' : 'Account deactivated',
        kind === 'activate'
          ? `${user.name} can sign in again.`
          : `${user.name} can no longer sign in on this device.`,
        kind === 'activate' ? 'success' : 'warning'
      );
    } else {
      notify('Action failed', res.error || 'Could not update account status.', 'critical');
    }
  };

  const doResetPassword = async () => {
    if (!resetConfirm) return;
    const u = resetConfirm;
    setResetConfirm(null);
    setBusyId(u.id);
    const res = await adminResetPassword(u.id);
    setBusyId(null);
    if (res.success && res.tempPassword) {
      setTempPw({ name: u.name, pw: res.tempPassword });
      setCopied(false);
    } else {
      notify('Password reset failed', res.error || 'Could not reset password.', 'critical');
    }
  };

  const copyTemp = async () => {
    if (!tempPw) return;
    try {
      await navigator.clipboard.writeText(tempPw.pw);
      setCopied(true);
    } catch {
      notify('Copy failed', 'Long-press the password to copy it manually.', 'warning');
    }
  };

  const openAdd = () => {
    setFName('');
    setFEmail('');
    setFPassword(generateTempPassword());
    setFRole('sales');
    setFError('');
    setAddOpen(true);
  };

  const submitAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setFError('');
    setFBusy(true);
    const res = await createUser(fName, fEmail, fPassword, fRole);
    setFBusy(false);
    if (res.success) {
      setAddOpen(false);
      notify(
        'Team member added',
        `${fName.trim()} was created as ${fRole}. Share their password — they must change it on first sign-in.`,
        'success'
      );
    } else {
      setFError(res.error || 'Could not create the account.');
    }
  };

  const isSelf = (u: AuthUser) => u.id === currentUser?.id;
  const isActive = (u: AuthUser) => u.isActive !== false;

  const roleSelect = (u: AuthUser) => (
    <select
      value={u.role}
      disabled={busyId === u.id}
      onChange={(e) => handleRoleChange(u, e.target.value as UserRole)}
      aria-label={`Role for ${u.name}`}
      className="text-xs font-semibold rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-2 py-1.5 text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500/30 disabled:opacity-50"
    >
      {ROLE_OPTIONS.map((r) => (
        <option key={r.value} value={r.value}>
          {r.label}
        </option>
      ))}
    </select>
  );

  const statusBadge = (u: AuthUser) =>
    isActive(u) ? (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
      </span>
    ) : (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Deactivated
      </span>
    );

  const rowActions = (u: AuthUser) => (
    <div className="flex items-center gap-1.5">
      {!isSelf(u) && (
        <button
          onClick={() => setResetConfirm(u)}
          disabled={busyId === u.id}
          title={`Reset password for ${u.name}`}
          className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition disabled:opacity-50 cursor-pointer"
        >
          <KeyRound className="w-4 h-4" />
        </button>
      )}
      {!isSelf(u) && (
        <button
          onClick={() => setConfirmAction({ kind: isActive(u) ? 'deactivate' : 'activate', user: u })}
          disabled={busyId === u.id}
          title={isActive(u) ? `Deactivate ${u.name}` : `Reactivate ${u.name}`}
          className={`p-2 rounded-lg transition disabled:opacity-50 cursor-pointer ${
            isActive(u)
              ? 'text-slate-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600'
              : 'text-slate-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600'
          }`}
        >
          {isActive(u) ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
        </button>
      )}
    </div>
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <UserCog className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            Team
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            {allUsers.length} account{allUsers.length === 1 ? '' : 's'} on this device. Staff sign in with their own email and password.
          </p>
        </div>
        <button
          onClick={openAdd}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add team member
        </button>
      </div>

      {/* One-time temp password box */}
      {tempPw && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-amber-900 dark:text-amber-200">
                Temporary password for {tempPw.name}
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-400">
                Copy it now — it will not be shown again. They must choose a new password on next sign-in.
              </p>
            </div>
            <button
              onClick={() => setTempPw(null)}
              className="p-1.5 rounded-lg text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/60 cursor-pointer"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 font-mono text-sm font-bold text-slate-900 dark:text-white select-all">
              {tempPw.pw}
            </code>
            <button
              onClick={copyTemp}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white transition cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
        </div>
      )}

      {/* Desktop table */}
      <div className="hidden sm:block overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-200 dark:border-slate-800">
              <th className="px-4 py-3 font-semibold">Member</th>
              <th className="px-4 py-3 font-semibold">Role</th>
              <th className="px-4 py-3 font-semibold">Status</th>
              <th className="px-4 py-3 font-semibold">Added</th>
              <th className="px-4 py-3 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {allUsers.map((u) => (
              <tr key={u.id} className="border-b border-slate-100 dark:border-slate-800/60 last:border-0">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-xs shrink-0">
                      {u.avatar || u.name.substring(0, 2).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        <span className="truncate">{u.name}</span>
                        {isSelf(u) && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500">
                            You
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 truncate">{u.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    {roleSelect(u)}
                    <span className={`hidden lg:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${roleBadgeClass[u.role]}`}>
                      {u.role}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">{statusBadge(u)}</td>
                <td className="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">
                  {new Date(u.createdAt).toLocaleDateString()}
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end">{rowActions(u)}</div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="sm:hidden space-y-3">
        {allUsers.map((u) => (
          <div
            key={u.id}
            className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-xs shrink-0">
                {u.avatar || u.name.substring(0, 2).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-slate-800 dark:text-slate-200 text-sm flex items-center gap-2">
                  <span className="truncate">{u.name}</span>
                  {isSelf(u) && (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500">
                      You
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-400 truncate">{u.email}</div>
              </div>
              {statusBadge(u)}
            </div>
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Role</span>
                {roleSelect(u)}
              </div>
              {rowActions(u)}
            </div>
          </div>
        ))}
      </div>

      {/* Add member modal */}
      {addOpen && (
        <div
          className="fixed inset-0 z-[70] overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
          {...backdropProps}
        >
          <div
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4"
            {...panelProps}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 shrink-0">
                  <UserCog className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">Add team member</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    They sign in on this device with these credentials.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setAddOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={submitAdd} className="space-y-3">
              {fError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs font-medium text-rose-700 dark:text-rose-300">
                  {fError}
                </div>
              )}
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">Full name</label>
                <input
                  value={fName}
                  onChange={(e) => setFName(e.target.value)}
                  placeholder="e.g. Rahim Uddin"
                  className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">Email</label>
                <input
                  type="email"
                  value={fEmail}
                  onChange={(e) => setFEmail(e.target.value)}
                  placeholder="rahim@example.com"
                  className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">Temporary password</label>
                <div className="mt-1 flex gap-2">
                  <input
                    value={fPassword}
                    onChange={(e) => setFPassword(e.target.value)}
                    placeholder="Min. 8 characters"
                    className="flex-1 px-3 py-2.5 rounded-xl text-sm font-mono bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                  />
                  <button
                    type="button"
                    onClick={() => setFPassword(generateTempPassword())}
                    className="px-3 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer whitespace-nowrap"
                  >
                    Generate
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">They must choose their own password on first sign-in.</p>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">Role</label>
                <select
                  value={fRole}
                  onChange={(e) => setFRole(e.target.value as UserRole)}
                  className="mt-1 w-full px-3 py-2.5 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 cursor-pointer"
                >
                  {ROLE_OPTIONS.map((r) => (
                    <option key={r.value} value={r.value}>
                      {r.label} — {r.blurb}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setAddOpen(false)}
                  className="px-4 py-2.5 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={fBusy}
                  className="px-4 py-2.5 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition disabled:opacity-50 cursor-pointer"
                >
                  {fBusy ? 'Creating…' : 'Create account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deactivate / reactivate confirmation */}
      <ConfirmDialog
        isOpen={!!confirmAction}
        title={confirmAction?.kind === 'activate' ? 'Reactivate account?' : 'Deactivate account?'}
        message={
          confirmAction?.kind === 'activate'
            ? `${confirmAction.user.name} will be able to sign in on this device again.`
            : `${confirmAction.user.name} will be signed out immediately and blocked from signing in. Their data is kept.`
        }
        confirmLabel={confirmAction?.kind === 'activate' ? 'Reactivate' : 'Deactivate'}
        danger={confirmAction?.kind === 'deactivate'}
        onConfirm={doToggleActive}
        onCancel={() => setConfirmAction(null)}
      />

      {/* Reset password confirmation */}
      <ConfirmDialog
        isOpen={!!resetConfirm}
        title="Reset password?"
        message={`${resetConfirm?.name} will be signed out and given a one-time temporary password. They must choose a new password on next sign-in, and their 2FA will need re-enrollment.`}
        confirmLabel="Reset password"
        danger
        onConfirm={doResetPassword}
        onCancel={() => setResetConfirm(null)}
      />
    </div>
  );
};
