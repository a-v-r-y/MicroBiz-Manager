import React, { useState, useEffect, useRef } from 'react';
import { 
  Bell, 
  Check, 
  CheckCheck, 
  Trash2, 
  X, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle2, 
  Info, 
  Package, 
  ShoppingCart, 
  WalletCards, 
  ShieldAlert,
  ArrowRight,
  Filter
} from 'lucide-react';
import { useNotifications } from '../context/NotificationContext';
import { AppNotification, NotificationCategory, NotificationPriority } from '../types';
import { NavTab } from './Sidebar';

interface NotificationPanelProps {
  onNavigate?: (tab: NavTab) => void;
}

export const NotificationPanel: React.FC<NotificationPanelProps> = ({ onNavigate }) => {
  const {
    notifications,
    unreadCount,
    isOpen,
    closeNotifications,
    markAsRead,
    markAllAsRead,
    dismissNotification,
    clearAllNotifications,
    triggerTestNotification,
    soundEnabled,
    toggleSound
  } = useNotifications();

  const [activeCategory, setActiveCategory] = useState<NotificationCategory>('all');
  const panelRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (isOpen && panelRef.current && !panelRef.current.contains(e.target as Node)) {
        // Only close if click is not on the bell toggle button
        const bellBtn = document.getElementById('header-bell-button');
        if (bellBtn && bellBtn.contains(e.target as Node)) {
          return;
        }
        closeNotifications();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        closeNotifications();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, closeNotifications]);

  if (!isOpen) return null;

  const filteredNotifications = notifications.filter(item => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'unread') return !item.read;
    return item.category === activeCategory;
  });

  const formatRelativeTime = (isoString: string) => {
    try {
      const now = new Date();
      const past = new Date(isoString);
      const diffMs = now.getTime() - past.getTime();
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffSecs < 60) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays === 1) return 'Yesterday';
      return `${diffDays}d ago`;
    } catch {
      return 'Recently';
    }
  };

  const getPriorityBadge = (priority: NotificationPriority) => {
    switch (priority) {
      case 'critical':
        return {
          bg: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-900',
          icon: AlertCircle,
          label: 'Critical'
        };
      case 'warning':
        return {
          bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-900',
          icon: AlertTriangle,
          label: 'Warning'
        };
      case 'success':
        return {
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-900',
          icon: CheckCircle2,
          label: 'Success'
        };
      case 'info':
      default:
        return {
          bg: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-900',
          icon: Info,
          label: 'Info'
        };
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'inventory':
        return <Package className="w-4 h-4 text-amber-500" />;
      case 'orders':
        return <ShoppingCart className="w-4 h-4 text-emerald-500" />;
      case 'financial':
        return <WalletCards className="w-4 h-4 text-indigo-500" />;
      case 'system':
      default:
        return <ShieldAlert className="w-4 h-4 text-blue-500" />;
    }
  };

  const handleActionClick = (notif: AppNotification) => {
    markAsRead(notif.id);
    if (notif.targetTab && onNavigate) {
      onNavigate(notif.targetTab as NavTab);
    }
    closeNotifications();
  };

  return (
    <div
      ref={panelRef}
      className="absolute right-0 top-full mt-2 w-96 sm:w-[440px] max-w-[calc(100vw-1.5rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 z-50 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in slide-in-from-top-2 duration-150"
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Notifications
              </h3>
              {unreadCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white leading-none">
                  {unreadCount} new
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400">
              Warehouse alerts, order queue & system status
            </p>
          </div>
        </div>

        {/* Quick controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={triggerTestNotification}
            title="Send real-time test notification"
            className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-indigo-500" />
          </button>
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Sound alerts enabled' : 'Sound alerts muted'}
            className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>
          <button
            onClick={closeNotifications}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-3 pt-2 pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1 overflow-x-auto text-[11px] font-medium no-scrollbar">
        {[
          { key: 'all', label: 'All', count: notifications.length },
          { key: 'unread', label: 'Unread', count: unreadCount },
          { key: 'inventory', label: 'Stock', count: notifications.filter(n => n.category === 'inventory').length },
          { key: 'orders', label: 'Orders', count: notifications.filter(n => n.category === 'orders').length },
          { key: 'financial', label: 'Financial', count: notifications.filter(n => n.category === 'financial').length },
          { key: 'system', label: 'System', count: notifications.filter(n => n.category === 'system').length }
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveCategory(tab.key as NotificationCategory)}
            className={`px-2.5 py-1 rounded-lg shrink-0 transition flex items-center gap-1.5 cursor-pointer ${
              activeCategory === tab.key
                ? 'bg-slate-900 text-white dark:bg-emerald-600 dark:text-white font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`text-[10px] px-1 rounded-full ${
              activeCategory === tab.key
                ? 'bg-white/20 text-white'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Actions Toolbar */}
      {notifications.length > 0 && (
        <div className="px-4 py-1.5 bg-slate-50/50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
          <span>{filteredNotifications.length} items shown</span>
          <div className="flex items-center gap-3">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline font-semibold cursor-pointer"
              >
                <CheckCheck className="w-3 h-3" />
                Mark all read
              </button>
            )}
            <button
              onClick={clearAllNotifications}
              className="text-slate-400 hover:text-rose-600 transition flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              Clear all
            </button>
          </div>
        </div>
      )}

      {/* Notifications List */}
      <div className="overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 flex-1 overscroll-contain">
        {filteredNotifications.length === 0 ? (
          <div className="py-12 px-6 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <div>
              <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                All caught up!
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                No active notifications in this category. You will be alerted when new orders or low-stock events occur.
              </p>
            </div>
            <button
              onClick={triggerTestNotification}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              Send test notification
            </button>
          </div>
        ) : (
          filteredNotifications.map(item => {
            const priorityBadge = getPriorityBadge(item.priority);
            const PriorityIcon = priorityBadge.icon;

            return (
              <div
                key={item.id}
                className={`p-3.5 transition group relative ${
                  !item.read
                    ? 'bg-amber-50/25 dark:bg-amber-950/15 hover:bg-amber-50/40 dark:hover:bg-amber-950/25'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Category icon with indicator */}
                  <div className="mt-0.5 relative shrink-0">
                    <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                      {getCategoryIcon(item.category)}
                    </div>
                    {!item.read && (
                      <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white dark:ring-slate-900" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border uppercase tracking-wider ${priorityBadge.bg}`}>
                          {priorityBadge.label}
                        </span>
                        <h4 className={`text-xs font-bold truncate ${
                          !item.read ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
                        }`}>
                          {item.title}
                        </h4>
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0 font-mono-numbers">
                        {formatRelativeTime(item.timestamp)}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {item.message}
                    </p>

                    {/* Action buttons */}
                    <div className="mt-2.5 flex items-center justify-between pt-1">
                      {item.actionLabel && (
                        <button
                          onClick={() => handleActionClick(item)}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 hover:underline cursor-pointer"
                        >
                          <span>{item.actionLabel}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}

                      <div className="flex items-center gap-2 ml-auto">
                        {!item.read && (
                          <button
                            onClick={() => markAsRead(item.id)}
                            title="Mark as read"
                            className="text-[11px] text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition cursor-pointer"
                          >
                            Mark read
                          </button>
                        )}
                        <button
                          onClick={() => dismissNotification(item.id)}
                          title="Dismiss notification"
                          className="text-slate-300 hover:text-rose-500 transition p-0.5 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer */}
      <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between px-4">
        <span>MicroBiz Notification Dispatcher</span>
        <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          Live Monitoring
        </span>
      </div>
    </div>
  );
};
