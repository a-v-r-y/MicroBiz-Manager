import { Expense } from '../types';

/**
 * B1: Recurring-expense engine.
 *
 * Templates are Expense records with isRecurring=true and a recurringInterval.
 * Generated instances are plain expenses carrying generatedFromTemplateId and
 * isRecurring=false, so they are never treated as templates themselves.
 * Each template tracks lastGeneratedDate to avoid duplicate generation.
 */

export interface RecurringGeneration {
  instances: Array<Omit<Expense, 'id' | 'createdAt'>>;
  templateUpdates: Array<{ id: string; lastGeneratedDate: string }>;
}

type Interval = 'weekly' | 'monthly' | 'yearly';

/** Step one interval forward from the cursor, preserving the template's day-of-month. */
function stepDate(cursor: Date, interval: Interval, originalDay: number): Date {
  const h = cursor.getHours();
  const min = cursor.getMinutes();
  const s = cursor.getSeconds();
  const ms = cursor.getMilliseconds();
  if (interval === 'weekly') {
    const d = new Date(cursor);
    d.setDate(d.getDate() + 7);
    return d;
  }
  if (interval === 'monthly') {
    const d = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1, h, min, s, ms);
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(originalDay, lastDay));
    return d;
  }
  // yearly — clamp Feb 29 to Feb 28 on non-leap years
  const d = new Date(cursor.getFullYear() + 1, cursor.getMonth(), 1, h, min, s, ms);
  const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(originalDay, lastDay));
  return d;
}

/**
 * Pure: given the current expense list, compute every recurring instance due
 * up to today that has not been generated yet, plus template lastGeneratedDate
 * updates. Capped at 48 instances per template per run as a safety bound.
 */
export function generateDueRecurringInstances(expenses: Expense[], now: Date = new Date()): RecurringGeneration {
  const instances: Array<Omit<Expense, 'id' | 'createdAt'>> = [];
  const templateUpdates: Array<{ id: string; lastGeneratedDate: string }> = [];
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  for (const template of expenses) {
    if (!template.isRecurring || template.generatedFromTemplateId) continue;
    const interval = template.recurringInterval;
    if (!interval) continue;

    const templateDate = new Date(template.date);
    if (isNaN(templateDate.getTime())) continue;
    const originalDay = templateDate.getDate();
    let cursor = template.lastGeneratedDate ? new Date(template.lastGeneratedDate) : templateDate;
    if (isNaN(cursor.getTime())) cursor = templateDate;

    let generated = 0;
    while (generated < 48) {
      const next = stepDate(cursor, interval, originalDay);
      if (next.getTime() > todayStart) break;
      instances.push({
        date: next.toISOString(),
        amount: template.amount,
        category: template.category,
        type: template.type,
        description: template.description,
        payee: template.payee,
        paymentMethod: template.paymentMethod,
        accountId: template.accountId,
        isRecurring: false,
        generatedFromTemplateId: template.id,
        referenceOrderNumber: template.referenceOrderNumber,
        receiptName: template.receiptName
      });
      cursor = next;
      generated++;
    }

    if (generated > 0) {
      templateUpdates.push({ id: template.id, lastGeneratedDate: cursor.toISOString() });
    }
  }

  return { instances, templateUpdates };
}
