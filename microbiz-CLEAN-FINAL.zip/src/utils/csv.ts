/**
 * RFC-4180 style CSV serializer / parser (I7).
 * - Serializer quotes fields containing comma, quote, CR or LF; quotes are doubled.
 * - Parser handles quoted fields, escaped ("") quotes, and embedded newlines.
 */

/** Serialize one row of fields into a CSV line. */
export function toCsvRow(fields: Array<string | number | undefined | null>): string {
  return fields
    .map((f) => {
      const s = f === undefined || f === null ? '' : String(f);
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    })
    .join(',');
}

/** Parse full CSV text into rows of fields. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  let i = 0;

  const pushField = () => {
    row.push(field);
    field = '';
  };
  const pushRow = () => {
    pushField();
    // Skip completely empty trailing rows
    if (!(row.length === 1 && row[0] === '')) rows.push(row);
    row = [];
  };

  while (i < text.length) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
        } else {
          inQuotes = false;
          i++;
        }
      } else {
        field += ch;
        i++;
      }
    } else if (ch === '"') {
      inQuotes = true;
      i++;
    } else if (ch === ',') {
      pushField();
      i++;
    } else if (ch === '\r') {
      // Handle \r\n or lone \r
      if (text[i + 1] === '\n') i++;
      i++;
      pushRow();
    } else if (ch === '\n') {
      i++;
      pushRow();
    } else {
      field += ch;
      i++;
    }
  }
  // Flush trailing content
  if (field !== '' || row.length > 0) pushRow();

  return rows;
}

/** Trigger a browser download of CSV content built from headers + rows. */
export function downloadCsv(filename: string, headers: string[], rows: Array<Array<string | number | undefined | null>>): void {
  const content = [toCsvRow(headers), ...rows.map((r) => toCsvRow(r))].join('\n');
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
