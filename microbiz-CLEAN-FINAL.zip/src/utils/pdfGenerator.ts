import { jsPDF } from 'jspdf';
import { BusinessSettings, Order, Expense, Product, FinancialAccount, PurchaseOrder, InventoryMovement } from '../types';
import { calculateDashboardMetrics, calculateOrderProfit, roundToMinorUnits, CURRENCY_CONFIGS } from './calculations';

interface GeneratePdfOptions {
  settings: BusinessSettings;
  orders: Order[];
  expenses: Expense[];
  products: Product[];
  purchaseOrders: PurchaseOrder[];
  accounts: FinancialAccount[];
  movements?: InventoryMovement[];
  periodLabel?: string;
}

/**
 * Format currency safely for PDF standard fonts (avoids unicode glyph rendering issues)
 */
function formatPdfCurrency(amount: number, currencyCode: string): string {
  const rounded = roundToMinorUnits(amount, 2);
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(Math.abs(rounded));
  const sign = rounded < 0 ? '-' : '';
  return `${sign}${currencyCode} ${formatted}`;
}

export function generatePdfSummaryReport({
  settings,
  orders,
  expenses,
  products,
  purchaseOrders,
  accounts,
  movements = [],
  periodLabel = 'All Time Performance'
}: GeneratePdfOptions): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;
  const contentWidth = pageWidth - (margin * 2);

  // Compute metrics
  const outstandingPayables = purchaseOrders.reduce((sum, po) => {
    if (po.status !== 'cancelled') {
      const balance = po.totalAmount - (po.amountPaid || 0);
      return sum + Math.max(0, balance);
    }
    return sum;
  }, 0);

  const metrics = calculateDashboardMetrics(
    orders,
    expenses,
    products,
    'all',
    outstandingPayables,
    movements,
    settings.inventoryValuationMethod || 'FIFO'
  );

  const totalCashBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // I5: true direct order variable costs — summed from each order's real
  // breakdown, NOT derived as grossProfit − contribution (which conflates
  // delivery revenue into the cost figure).
  const trueTotalVariableCosts = roundToMinorUnits(
    orders
      .filter(o => o.orderStatus !== 'cancelled')
      .reduce((sum, o) => sum + calculateOrderProfit(o).totalVariableCosts, 0)
  );

  // Top selling products
  const productSalesMap = new Map<string, { name: string; units: number; revenue: number }>();
  orders.filter(o => o.orderStatus !== 'cancelled').forEach(order => {
    order.items.forEach(item => {
      const existing = productSalesMap.get(item.productId) || { name: item.productName, units: 0, revenue: 0 };
      existing.units += item.quantity;
      existing.revenue += (item.quantity * item.unitPrice) - (item.discount || 0);
      productSalesMap.set(item.productId, existing);
    });
  });

  const topProducts = Array.from(productSalesMap.values())
    .sort((a, b) => b.units - a.units)
    .slice(0, 5);

  let y = margin;

  // --- 1. HEADER SECTION ---
  // Top brand bar
  doc.setFillColor(15, 23, 42); // slate-900
  doc.roundedRect(margin, y, contentWidth, 28, 3, 3, 'F');

  // Business Name & Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(settings.businessName, margin + 8, y + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text(
    `${settings.businessCategory || 'Business'} | ${settings.country || 'Global'} | Currency: ${settings.currency}`,
    margin + 8,
    y + 16
  );

  // Right-aligned report label & date
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(52, 211, 153); // emerald-400
  doc.text('EXECUTIVE PERFORMANCE & PROFIT REPORT', pageWidth - margin - 8, y + 10, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225); // slate-300
  const nowStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  doc.text(`Generated: ${nowStr} | ${periodLabel}`, pageWidth - margin - 8, y + 16, { align: 'right' });

  y += 33;

  // --- 2. HIGHLIGHT KPI TILES (4 CARDS) ---
  const cardGap = 4;
  const cardWidth = (contentWidth - (cardGap * 3)) / 4;
  const cardHeight = 24;

  const kpis = [
    {
      title: 'TOTAL NET SALES',
      value: formatPdfCurrency(metrics.netMerchandiseSales, settings.currency),
      subtext: `Gross: ${formatPdfCurrency(metrics.totalGrossSales, settings.currency)}`,
      bg: [248, 250, 252],
      border: [226, 232, 240],
      textCol: [15, 23, 42]
    },
    {
      title: 'COST OF GOODS (COGS)',
      value: formatPdfCurrency(metrics.totalCOGS, settings.currency),
      subtext: `${settings.inventoryValuationMethod} inventory cost`,
      bg: [255, 251, 235], // amber-50
      border: [254, 215, 170],
      textCol: [180, 83, 9]
    },
    {
      title: 'GROSS PROFIT',
      value: formatPdfCurrency(metrics.grossProfit, settings.currency),
      subtext: `Margin: ${metrics.grossMarginPercent}%`,
      bg: [236, 253, 245], // emerald-50
      border: [167, 243, 208],
      textCol: [4, 120, 87]
    },
    {
      title: 'NET OPERATING PROFIT',
      value: formatPdfCurrency(metrics.netOperatingProfit, settings.currency),
      subtext: `Net Margin: ${metrics.netOperatingMarginPercent}%`,
      bg: metrics.netOperatingProfit >= 0 ? [236, 253, 245] : [255, 241, 242],
      border: metrics.netOperatingProfit >= 0 ? [167, 243, 208] : [254, 205, 211],
      textCol: metrics.netOperatingProfit >= 0 ? [4, 120, 87] : [190, 18, 60]
    }
  ];

  kpis.forEach((kpi, idx) => {
    const cardX = margin + (idx * (cardWidth + cardGap));
    doc.setFillColor(kpi.bg[0], kpi.bg[1], kpi.bg[2]);
    doc.setDrawColor(kpi.border[0], kpi.border[1], kpi.border[2]);
    doc.setLineWidth(0.4);
    doc.roundedRect(cardX, y, cardWidth, cardHeight, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(kpi.title, cardX + 3, y + 5.5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(kpi.textCol[0], kpi.textCol[1], kpi.textCol[2]);
    doc.text(kpi.value, cardX + 3, y + 13.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(kpi.subtext, cardX + 3, y + 19.5);
  });

  y += cardHeight + 6;

  // --- 3. INCOME & PROFIT MARGIN WATERFALL BREAKDOWN ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Profit & Loss Summary Breakdown (Income Statement)', margin, y + 2);
  y += 5;

  const tableHeaderY = y;
  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(margin, tableHeaderY, contentWidth, 7, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('ACCOUNTING ITEM & DESCRIPTION', margin + 4, tableHeaderY + 4.8);
  doc.text('CLASSIFICATION', margin + 115, tableHeaderY + 4.8);
  doc.text('AMOUNT & MARGIN', pageWidth - margin - 4, tableHeaderY + 4.8, { align: 'right' });

  y += 7;

  const pnlRows: Array<{ label: string; classif: string; amount: string; isBold?: boolean; isHighlight?: boolean; isNegative?: boolean }> = [
    {
      label: 'Gross Merchandise Sales (Item Retail Prices)',
      classif: 'Merchandise Volume',
      amount: formatPdfCurrency(metrics.totalGrossSales, settings.currency)
    },
    {
      label: 'Less: Customer Discounts & Trade Concessions',
      classif: 'Sales Reduction',
      amount: `-${formatPdfCurrency(metrics.totalGrossSales - metrics.netMerchandiseSales, settings.currency)}`,
      isNegative: true
    },
    {
      label: 'Net Merchandise Sales',
      classif: 'Core Product Sales',
      amount: formatPdfCurrency(metrics.netMerchandiseSales, settings.currency),
      isBold: true
    },
    {
      label: 'Delivery Fees Collected from Customers',
      classif: 'Logistics Revenue',
      amount: `+${formatPdfCurrency(metrics.totalNetRevenue - metrics.netMerchandiseSales, settings.currency)}`
    },
    {
      label: 'TOTAL RECOGNIZED REVENUE',
      classif: 'Top-line Recognized Revenue',
      amount: formatPdfCurrency(metrics.totalNetRevenue, settings.currency),
      isBold: true,
      isHighlight: true
    },
    {
      label: 'Cost of Goods Sold (COGS - Inventory Valuation)',
      classif: 'Direct Product Cost',
      amount: `-${formatPdfCurrency(metrics.totalCOGS, settings.currency)}`,
      isNegative: true
    },
    {
      label: `GROSS PROFIT (Gross Margin: ${metrics.grossMarginPercent}%)`,
      classif: 'Product Margin',
      amount: formatPdfCurrency(metrics.grossProfit, settings.currency),
      isBold: true,
      isHighlight: true
    },
    {
      label: 'Direct Order Variable Costs (Courier, Packing, Payment Fees)',
      classif: 'Order Variable OPEX',
      amount: `-${formatPdfCurrency(trueTotalVariableCosts, settings.currency)}`,
      isNegative: true
    },
    {
      label: 'Direct Order Contribution',
      classif: 'Contribution Pool',
      amount: formatPdfCurrency(metrics.directOrderContribution, settings.currency),
      isBold: true
    },
    {
      label: 'Operating Overhead (Rent, Salaries, Marketing, Utilities)',
      classif: 'Fixed OPEX Overhead',
      amount: `-${formatPdfCurrency(metrics.totalOperatingExpenses, settings.currency)}`,
      isNegative: true
    },
    {
      label: `NET OPERATING PROFIT (Net Margin: ${metrics.netOperatingMarginPercent}%)`,
      classif: 'Operating Earnings',
      amount: formatPdfCurrency(metrics.netOperatingProfit, settings.currency),
      isBold: true,
      isHighlight: true
    }
  ];

  pnlRows.forEach((row, idx) => {
    const rowHeight = 6.2;
    if (row.isHighlight) {
      doc.setFillColor(240, 253, 244); // light emerald
      doc.rect(margin, y, contentWidth, rowHeight, 'F');
    } else if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, contentWidth, rowHeight, 'F');
    }

    doc.setFont('helvetica', row.isBold ? 'bold' : 'normal');
    doc.setFontSize(7.5);

    if (row.isHighlight) {
      doc.setTextColor(4, 120, 87); // emerald-700
    } else if (row.isNegative) {
      doc.setTextColor(190, 18, 60); // rose-700
    } else {
      doc.setTextColor(30, 41, 59);
    }

    doc.text(row.label, margin + 4, y + 4.3);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text(row.classif, margin + 115, y + 4.3);

    doc.setFont('helvetica', row.isBold ? 'bold' : 'normal');
    doc.setFontSize(7.5);
    if (row.isHighlight) {
      doc.setTextColor(4, 120, 87);
    } else if (row.isNegative) {
      doc.setTextColor(190, 18, 60);
    } else {
      doc.setTextColor(30, 41, 59);
    }
    doc.text(row.amount, pageWidth - margin - 4, y + 4.3, { align: 'right' });

    y += rowHeight;
  });

  y += 5;

  // --- 4. BALANCE SHEET & CASH FLOW SNAPSHOT ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Cash Flow, Assets & Working Capital Position', margin, y + 2);
  y += 5;

  const bsCardWidth = (contentWidth - (cardGap * 3)) / 4;
  const bsCards = [
    {
      title: 'TOTAL LIQUID CASH',
      val: formatPdfCurrency(totalCashBalance, settings.currency),
      sub: `Across ${accounts.length} business accounts`,
      badgeColor: [37, 99, 235]
    },
    {
      title: 'CUSTOMER RECEIVABLES',
      val: formatPdfCurrency(metrics.outstandingReceivables, settings.currency),
      sub: 'Open / unpaid customer orders',
      badgeColor: [217, 119, 6]
    },
    {
      title: 'SUPPLIER PAYABLES',
      val: formatPdfCurrency(metrics.outstandingPayables, settings.currency),
      sub: 'Due on purchase invoices',
      badgeColor: [225, 29, 72]
    },
    {
      title: 'WAREHOUSE INVENTORY',
      val: formatPdfCurrency(metrics.totalInventoryValuation, settings.currency),
      sub: `${settings.inventoryValuationMethod} (Res: ${formatPdfCurrency(metrics.lifoReserve, settings.currency)})`,
      badgeColor: [79, 70, 229]
    }
  ];

  bsCards.forEach((c, idx) => {
    const cardX = margin + (idx * (bsCardWidth + cardGap));
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.roundedRect(cardX, y, bsCardWidth, 20, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(c.badgeColor[0], c.badgeColor[1], c.badgeColor[2]);
    doc.text(c.title, cardX + 3, y + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(c.val, cardX + 3, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(c.sub, cardX + 3, y + 17);
  });

  y += 24;

  // --- 5. TOP PERFORMING PRODUCTS TABLE ---
  if (topProducts.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('Top Revenue & Volume Generating Products', margin, y + 2);
    y += 5;

    // Header
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 6, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text('PRODUCT / MERCHANDISE NAME', margin + 4, y + 4.2);
    doc.text('UNITS SOLD', margin + 115, y + 4.2);
    doc.text('GENERATED REVENUE', pageWidth - margin - 4, y + 4.2, { align: 'right' });
    y += 6;

    topProducts.forEach((prod, idx) => {
      if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y, contentWidth, 5.5, 'F');
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);
      doc.text(`${idx + 1}. ${prod.name}`, margin + 4, y + 3.8);

      doc.setTextColor(100, 116, 139);
      doc.text(`${prod.units} units`, margin + 115, y + 3.8);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(formatPdfCurrency(prod.revenue, settings.currency), pageWidth - margin - 4, y + 3.8, { align: 'right' });

      y += 5.5;
    });
  }

  // --- 6. AUDIT COMPLIANCE & FOOTER ---
  y = pageHeight - margin - 8;
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.4);
  doc.line(margin, y, pageWidth - margin, y);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `MicroBiz Manager Audit Certificate: Authoritative GAAP calculation report. Generated electronically without modification.`,
    margin,
    y + 4.5
  );

  doc.text(
    `Page 1 of 1 | ${settings.businessName}`,
    pageWidth - margin,
    y + 4.5,
    { align: 'right' }
  );

  // Generate file download
  const sanitizedName = settings.businessName.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 25);
  const dateStamp = new Date().toISOString().slice(0, 10);
  doc.save(`${sanitizedName}_executive_summary_${dateStamp}.pdf`);
}
