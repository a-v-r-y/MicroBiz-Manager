/**
 * Web Crypto API-based cryptographic authentication utilities:
 * - PBKDF2 SHA-256 password hashing with unique salt (100,000 iterations)
 * - RFC 6238 / RFC 4226 Time-based One-Time Password (TOTP) 2FA generator & validator
 * - Cryptographically random session tokens & 6-digit verification codes
 * - Device / browser environment detection
 */

// Helper to convert Uint8Array to hex string
export function bufferToHex(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Helper to convert hex string to Uint8Array
export function hexToBuffer(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

/**
 * Generate cryptographically secure random salt
 */
export function generateSalt(byteLength: number = 16): string {
  const salt = new Uint8Array(byteLength);
  window.crypto.getRandomValues(salt);
  return bufferToHex(salt);
}

/**
 * Hash password using PBKDF2 with SHA-256 and 100,000 iterations
 */
export async function hashPassword(password: string, saltHex: string): Promise<string> {
  const enc = new TextEncoder();
  const passwordKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  const saltBytes = hexToBuffer(saltHex);

  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes as unknown as BufferSource,
      iterations: 100000,
      hash: 'SHA-256'
    },
    passwordKey,
    256 // 32 bytes
  );

  return bufferToHex(derivedBits);
}

/**
 * Verify password against stored PBKDF2 hash and salt
 */
export async function verifyPassword(password: string, saltHex: string, storedHashHex: string): Promise<boolean> {
  try {
    const computedHashHex = await hashPassword(password, saltHex);
    // Constant-time comparison
    if (computedHashHex.length !== storedHashHex.length) return false;
    let result = 0;
    for (let i = 0; i < computedHashHex.length; i++) {
      result |= computedHashHex.charCodeAt(i) ^ storedHashHex.charCodeAt(i);
    }
    return result === 0;
  } catch (err) {
    console.error('Password verification error:', err);
    return false;
  }
}

/**
 * Generate secure random token (for sessions, email verification links, reset tokens)
 */
export function generateRandomToken(byteLength: number = 32): string {
  const array = new Uint8Array(byteLength);
  window.crypto.getRandomValues(array);
  return bufferToHex(array);
}

/**
 * Generate a 6-digit numeric verification code
 */
export function generateSixDigitCode(): string {
  const array = new Uint32Array(1);
  window.crypto.getRandomValues(array);
  // Guarantee 6 digits: 100000 to 999999
  const code = 100000 + (array[0] % 900000);
  return code.toString();
}

/**
 * Base32 Alphabet for TOTP Secret Keys (RFC 3548 / RFC 4648)
 */
const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

/**
 * Generate a random Base32 encoded secret key (16 characters / 80 bits)
 */
export function generateBase32Secret(length: number = 16): string {
  const bytes = new Uint8Array(length);
  window.crypto.getRandomValues(bytes);
  let secret = '';
  for (let i = 0; i < length; i++) {
    secret += BASE32_CHARS.charAt(bytes[i] % BASE32_CHARS.length);
  }
  return secret;
}

/**
 * Convert Base32 string to Uint8Array
 */
function base32ToBuffer(base32: string): Uint8Array {
  const cleaned = base32.toUpperCase().replace(/=+$/, '');
  let bits = '';
  for (let i = 0; i < cleaned.length; i++) {
    const val = BASE32_CHARS.indexOf(cleaned.charAt(i));
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }

  const bytes = new Uint8Array(Math.floor(bits.length / 8));
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(bits.substring(i * 8, (i + 1) * 8), 2);
  }
  return bytes;
}

/**
 * Compute RFC 6238 TOTP code for a given secret at a specific time step
 */
export async function calculateTotpCode(secretBase32: string, timeStepOffset: number = 0): Promise<string> {
  const keyBytes = base32ToBuffer(secretBase32);
  const key = await window.crypto.subtle.importKey(
    'raw',
    keyBytes as unknown as BufferSource,
    { name: 'HMAC', hash: 'SHA-1' },
    false,
    ['sign']
  );

  const epochSeconds = Math.floor(Date.now() / 1000);
  const timeStep = Math.floor(epochSeconds / 30) + timeStepOffset;

  // 8-byte big-endian buffer
  const timeBuffer = new Uint8Array(8);
  let temp = timeStep;
  for (let i = 7; i >= 0; i--) {
    timeBuffer[i] = temp & 0xff;
    temp = Math.floor(temp / 256);
  }

  const signature = await window.crypto.subtle.sign('HMAC', key, timeBuffer);
  const sigBytes = new Uint8Array(signature);

  // Dynamic truncation (RFC 4226)
  const offset = sigBytes[sigBytes.length - 1] & 0x0f;
  const binary =
    ((sigBytes[offset] & 0x7f) << 24) |
    ((sigBytes[offset + 1] & 0xff) << 16) |
    ((sigBytes[offset + 2] & 0xff) << 8) |
    (sigBytes[offset + 3] & 0xff);

  const otp = binary % 1000000;
  return otp.toString().padStart(6, '0');
}

/**
 * Verify a 6-digit TOTP code with ±1 step window tolerance (±30 seconds)
 */
export async function verifyTotpCode(secretBase32: string, candidateCode: string): Promise<boolean> {
  const cleanCode = candidateCode.trim().replace(/\s+/g, '');
  if (cleanCode.length !== 6 || !/^\d{6}$/.test(cleanCode)) {
    return false;
  }

  // Check windows: current step (0), previous step (-1), and next step (+1)
  const offsets = [0, -1, 1];
  for (const offset of offsets) {
    const validCode = await calculateTotpCode(secretBase32, offset);
    if (validCode === cleanCode) {
      return true;
    }
  }
  return false;
}

/**
 * Generate 8 emergency one-time backup recovery codes (e.g., "A3F2-9K8L")
 */
export function generateBackupCodes(count: number = 8): string[] {
  const codes: string[] = [];
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Excludes confusing characters (0, O, 1, I)

  for (let i = 0; i < count; i++) {
    const bytes = new Uint8Array(8);
    window.crypto.getRandomValues(bytes);
    let code = '';
    for (let j = 0; j < 8; j++) {
      code += chars.charAt(bytes[j] % chars.length);
      if (j === 3) code += '-';
    }
    codes.push(code);
  }
  return codes;
}

/**
 * Generate standard otpauth:// URI for QR code generators (Google Authenticator, Authy, 1Password)
 */
export function generateOtpauthUri(email: string, secretBase32: string, issuer: string = 'MicroBizManager'): string {
  const encodedIssuer = encodeURIComponent(issuer);
  const encodedLabel = encodeURIComponent(`${issuer}:${email}`);
  return `otpauth://totp/${encodedLabel}?secret=${secretBase32}&issuer=${encodedIssuer}&algorithm=SHA1&digits=6&period=30`;
}

/**
 * Detect client device, browser, and operating system from User Agent
 */
export function detectClientEnvironment(): { browser: string; device: string; ip: string } {
  const ua = navigator.userAgent;

  let browser = 'Web Browser';
  if (ua.includes('Firefox')) browser = 'Mozilla Firefox';
  else if (ua.includes('Edg')) browser = 'Microsoft Edge';
  else if (ua.includes('Chrome')) browser = 'Google Chrome';
  else if (ua.includes('Safari')) browser = 'Apple Safari';
  else if (ua.includes('Opera') || ua.includes('OPR')) browser = 'Opera';

  let device = 'Desktop Computer';
  if (/Android/i.test(ua)) device = 'Android Device';
  else if (/iPhone/i.test(ua)) device = 'Apple iPhone';
  else if (/iPad/i.test(ua)) device = 'Apple iPad';
  else if (/Macintosh|Mac OS/i.test(ua)) device = 'macOS Workstation';
  else if (/Windows/i.test(ua)) device = 'Windows PC';
  else if (/Linux/i.test(ua)) device = 'Linux Workstation';

  // Realistic mock local IP
  const ip = '192.168.1.' + (10 + (Math.abs(ua.length) % 80));

  return { browser, device, ip };
}

/* ------------------------------------------------------------------ */
/* Password-based AES-GCM encryption for secrets at rest (C4 / I11).    */
/* Payload format (JSON string): { v:1, salt:<b64>, iv:<b64>, data:<b64> } */
/* Key: PBKDF2-SHA256, 100k iterations, 256-bit AES-GCM key.           */
/* ------------------------------------------------------------------ */

export function u8ToB64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export function b64ToU8(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export interface EncryptedPayload {
  v: 1;
  salt: string; // base64, 16 bytes
  iv: string;   // base64, 12 bytes
  data: string; // base64 ciphertext
}

/**
 * Derive a 256-bit AES-GCM CryptoKey from a password + salt via PBKDF2.
 * Keep the returned key in memory only; never persist it.
 */
export async function deriveAesKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );
  return window.crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: salt as unknown as BufferSource, iterations: 100000, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypt plaintext with an existing in-memory key, reusing the payload's salt
 * but generating a fresh random IV on every call.
 */
export async function encryptWithExistingKey(
  plaintext: string,
  key: CryptoKey,
  saltB64: string
): Promise<string> {
  const iv = new Uint8Array(12);
  window.crypto.getRandomValues(iv);
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as unknown as BufferSource },
    key,
    new TextEncoder().encode(plaintext)
  );
  const payload: EncryptedPayload = {
    v: 1,
    salt: saltB64,
    iv: u8ToB64(iv),
    data: u8ToB64(new Uint8Array(ciphertext))
  };
  return JSON.stringify(payload);
}

/**
 * Encrypt plaintext with a password. Generates a fresh random salt + IV.
 * Returns the JSON-encoded payload string (safe to persist).
 */
export async function encryptWithPassword(plaintext: string, password: string): Promise<string> {
  const salt = new Uint8Array(16);
  window.crypto.getRandomValues(salt);
  const key = await deriveAesKey(password, salt);
  return encryptWithExistingKey(plaintext, key, u8ToB64(salt));
}

/**
 * Decrypt a payload produced by encryptWithPassword / encryptWithExistingKey.
 * Throws on wrong password, tampered data, or malformed payload.
 */
export async function decryptWithPassword(payloadJson: string, password: string): Promise<string> {
  const payload = JSON.parse(payloadJson) as EncryptedPayload;
  if (!payload || payload.v !== 1 || !payload.salt || !payload.iv || !payload.data) {
    throw new Error('Malformed encrypted payload.');
  }
  const key = await deriveAesKey(password, b64ToU8(payload.salt));
  return decryptWithKey(payloadJson, key);
}

/**
 * Decrypt a payload with an in-memory CryptoKey derived from the same salt.
 * Throws on tampered data or malformed payload.
 */
export async function decryptWithKey(payloadJson: string, key: CryptoKey): Promise<string> {
  const payload = JSON.parse(payloadJson) as EncryptedPayload;
  if (!payload || payload.v !== 1 || !payload.iv || !payload.data) {
    throw new Error('Malformed encrypted payload.');
  }
  const plaintext = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: b64ToU8(payload.iv) as unknown as BufferSource },
    key,
    b64ToU8(payload.data) as unknown as BufferSource
  );
  return new TextDecoder().decode(plaintext);
}

/**
 * Extract the salt (base64) embedded in an encrypted payload, so a caller
 * holding the password-derived key material can re-derive later.
 */
export function extractPayloadSalt(payloadJson: string): string {
  const payload = JSON.parse(payloadJson) as EncryptedPayload;
  if (!payload || payload.v !== 1 || !payload.salt) {
    throw new Error('Malformed encrypted payload.');
  }
  return payload.salt;
}

/**
 * Generate a readable temporary password for owner-issued staff accounts,
 * e.g. "k7R9-mQ2p-X4z8". Uses crypto randomness; excludes confusing
 * characters (0/O, 1/l/I). The recipient must change it on next login.
 */
export function generateTempPassword(): string {
  const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(12);
  window.crypto.getRandomValues(bytes);
  let out = '';
  for (let i = 0; i < 12; i++) {
    out += chars.charAt(bytes[i] % chars.length);
    if (i === 3 || i === 7) out += '-';
  }
  return out;
}
