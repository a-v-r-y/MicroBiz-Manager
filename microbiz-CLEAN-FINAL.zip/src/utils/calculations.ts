import { Order, Expense, Product, Customer, CurrencyCode, CurrencyConfig, InventoryMovement, InventoryValuationMethod } from '../types';

export const CURRENCY_CONFIGS: Record<CurrencyCode, CurrencyConfig> = {
  BDT: {
    code: 'BDT',
    symbol: '৳',
    name: 'Bangladeshi Taka',
    minorUnitDigits: 2,
    locale: 'en-BD'
  },
  USD: {
    code: 'USD',
    symbol: '$',
    name: 'US Dollar',
    minorUnitDigits: 2,
    locale: 'en-US'
  },
  EUR: {
    code: 'EUR',
    symbol: '€',
    name: 'Euro',
    minorUnitDigits: 2,
    locale: 'de-DE'
  },
  GBP: {
    code: 'GBP',
    symbol: '£',
    name: 'British Pound',
    minorUnitDigits: 2,
    locale: 'en-GB'
  },
  INR: {
    code: 'INR',
    symbol: '₹',
    name: 'Indian Rupee',
    minorUnitDigits: 2,
    locale: 'en-IN'
  },
  CAD: {
    code: 'CAD',
    symbol: 'CA$',
    name: 'Canadian Dollar',
    minorUnitDigits: 2,
    locale: 'en-CA'
  },
  AED: {
    code: 'AED',
    symbol: 'AED',
    name: 'UAE Dirham',
    minorUnitDigits: 2,
    locale: 'ar-AE'
  }
};

/**
 * High-precision rounding to eliminate JS binary floating point inaccuracies
 */
export function roundToMinorUnits(amount: number, digits: number = 2): number {
  if (isNaN(amount) || !isFinite(amount)) return 0;
  const factor = Math.pow(10, digits);
  return Math.round((amount + Number.EPSILON) * factor) / factor;
}

export function formatCurrency(amount: number, currencyCode: CurrencyCode = 'BDT'): string {
  const cfg = CURRENCY_CONFIGS[currencyCode] || CURRENCY_CONFIGS.BDT;
  const rounded = roundToMinorUnits(amount, cfg.minorUnitDigits);
  try {
    const formatted = new Intl.NumberFormat(cfg.locale, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(Math.abs(rounded));
    const sign = rounded < 0 ? '-' : '';
    return `${sign}${cfg.symbol} ${formatted}`;
  } catch {
    return `${rounded < 0 ? '-' : ''}${cfg.symbol} ${Math.abs(rounded).toFixed(2)}`;
  }
}

export interface OrderProfitBreakdown {
  grossMerchandiseSales: number;
  itemDiscounts: number;
  orderDiscount: number;
  totalDiscounts: number;
  refunds: number;
  netMerchandiseSales: number;
  deliveryChargeCollected: number;
  netRevenue: number;
  cogs: number;
  grossProfit: number;
  grossMarginPercent: number;
  actualDeliveryExpense: number;
  packagingExpense: number;
  paymentFee: number;
  marketplaceCommission: number;
  adCostAllocated: number;
  otherExpenses: number;
  totalVariableCosts: number;
  netOrderContribution: number;
  contributionMarginPercent: number;
  cashReceived: number;
  directCashOutflow: number;
  estimatedOrderCashMovement: number;
}

/**
 * Calculates authoritative order financial breakdown strictly following GAAP / managerial accounting rules
 */
export function calculateOrderProfit(order: {
  items: Array<{ quantity: number; unitPrice: number; unitCostSnapshot: number; discount?: number }>;
  discount?: number;
  refundAmount?: number;
  deliveryChargeCollected?: number;
  actualDeliveryExpense?: number;
  packagingExpense?: number;
  paymentFee?: number;
  marketplaceCommission?: number;
  adCostAllocated?: number;
  otherExpenses?: number;
  amountPaid?: number;
}): OrderProfitBreakdown {
  const grossMerchandiseSales = roundToMinorUnits(
    order.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0)
  );

  const itemDiscounts = roundToMinorUnits(
    order.items.reduce((sum, item) => sum + (item.discount || 0), 0)
  );
  const orderDiscount = roundToMinorUnits(order.discount || 0);
  const totalDiscounts = roundToMinorUnits(itemDiscounts + orderDiscount);
  const refunds = roundToMinorUnits(order.refundAmount || 0);

  // Net Merchandise Sales = Gross merchandise sales minus discounts and refunds
  const netMerchandiseSales = roundToMinorUnits(
    Math.max(0, grossMerchandiseSales - totalDiscounts - refunds)
  );

  const deliveryChargeCollected = roundToMinorUnits(order.deliveryChargeCollected || 0);
  
  // Net Revenue = Net merchandise sales + delivery revenue collected
  const netRevenue = roundToMinorUnits(netMerchandiseSales + deliveryChargeCollected);

  // COGS = sum of inventory cost snapshot * quantity
  const cogs = roundToMinorUnits(
    order.items.reduce((sum, item) => sum + (item.quantity * (item.unitCostSnapshot || 0)), 0)
  );

  // Gross profit = Net merchandise sales - COGS
  const grossProfit = roundToMinorUnits(netMerchandiseSales - cogs);
  const grossMarginPercent = netMerchandiseSales > 0 
    ? roundToMinorUnits((grossProfit / netMerchandiseSales) * 100, 1) 
    : 0;

  // Variable expenses
  const actualDeliveryExpense = roundToMinorUnits(order.actualDeliveryExpense || 0);
  const packagingExpense = roundToMinorUnits(order.packagingExpense || 0);
  const paymentFee = roundToMinorUnits(order.paymentFee || 0);
  const marketplaceCommission = roundToMinorUnits(order.marketplaceCommission || 0);
  const adCostAllocated = roundToMinorUnits(order.adCostAllocated || 0);
  const otherExpenses = roundToMinorUnits(order.otherExpenses || 0);

  const totalVariableCosts = roundToMinorUnits(
    actualDeliveryExpense + packagingExpense + paymentFee + marketplaceCommission + adCostAllocated + otherExpenses
  );

  // Net Order Contribution = Net Revenue minus COGS minus Direct Variable Costs
  const netOrderContribution = roundToMinorUnits(
    netRevenue - cogs - totalVariableCosts
  );

  const contributionMarginPercent = netRevenue > 0
    ? roundToMinorUnits((netOrderContribution / netRevenue) * 100, 1)
    : 0;

  // Cash movement: Customer cash received minus immediate cash outflows
  const cashReceived = roundToMinorUnits(order.amountPaid !== undefined ? order.amountPaid : (grossMerchandiseSales - totalDiscounts + deliveryChargeCollected));
  const directCashOutflow = roundToMinorUnits(paymentFee + actualDeliveryExpense + packagingExpense + otherExpenses);
  const estimatedOrderCashMovement = roundToMinorUnits(cashReceived - directCashOutflow);

  return {
    grossMerchandiseSales,
    itemDiscounts,
    orderDiscount,
    totalDiscounts,
    refunds,
    netMerchandiseSales,
    deliveryChargeCollected,
    netRevenue,
    cogs,
    grossProfit,
    grossMarginPercent,
    actualDeliveryExpense,
    packagingExpense,
    paymentFee,
    marketplaceCommission,
    adCostAllocated,
    otherExpenses,
    totalVariableCosts,
    netOrderContribution,
    contributionMarginPercent,
    cashReceived,
    directCashOutflow,
    estimatedOrderCashMovement
  };
}

export interface InventoryBatch {
  id: string;
  date: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  source: string;
}

export interface BatchAllocation {
  batchId: string;
  date: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  source: string;
}

export interface ProductCostingDetail {
  productId: string;
  productName: string;
  sku: string;
  currentStock: number;
  costPrice: number;
  batches: InventoryBatch[];
  totalInboundUnits: number;
  totalInboundCost: number;
  totalUnitsSoldOrDeducted: number;
  // FIFO (First In, First Out)
  fifoValuation: number;
  fifoUnitCost: number;
  fifoEndingBatches: BatchAllocation[];
  fifoHistoricalCOGS: number;
  // LIFO (Last In, First Out)
  lifoValuation: number;
  lifoUnitCost: number;
  lifoEndingBatches: BatchAllocation[];
  lifoHistoricalCOGS: number;
  // WAC (Weighted Average Cost)
  wacValuation: number;
  wacUnitCost: number;
  wacHistoricalCOGS: number;
  // Financial Accounting Metric: LIFO Reserve = FIFO - LIFO
  lifoReserve: number;
}

export interface InventoryValuationSummary {
  fifoTotalValuation: number;
  lifoTotalValuation: number;
  wacTotalValuation: number;
  activeMethodTotalValuation: number;
  activeMethod: InventoryValuationMethod;
  totalStockUnits: number;
  lifoReserve: number;
  productCostings: ProductCostingDetail[];
}

/**
 * Calculates authoritative FIFO, LIFO, and WAC costing for an individual catalog product
 */
export function calculateProductInventoryCosting(
  product: Product,
  movements: InventoryMovement[]
): ProductCostingDetail {
  const currentStock = Math.max(0, product.stock || 0);

  // Extract inbound movements for this product
  // Inbound types: initial, purchase_receipt, and positive manual adjustments or returns
  const inboundMovements = movements
    .filter(m => m.productId === product.id && m.quantity > 0)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const batches: InventoryBatch[] = [];

  // If inbound movements exist, construct batches from them
  if (inboundMovements.length > 0) {
    inboundMovements.forEach((m, idx) => {
      batches.push({
        id: m.id || `batch-${idx}`,
        date: m.date,
        quantity: m.quantity,
        unitCost: roundToMinorUnits(m.unitCost || product.costPrice || 0),
        totalCost: roundToMinorUnits(m.quantity * (m.unitCost || product.costPrice || 0)),
        source: m.referenceId || (m.type === 'purchase_receipt' ? 'Purchase Order' : 'Initial Stock')
      });
    });
  }

  // Calculate sum of inbound units
  const totalInboundUnitsFromMovements = batches.reduce((sum, b) => sum + b.quantity, 0);

  // If product stock exists without movements, or exceeds movement batches, synthesize a baseline batch
  if (batches.length === 0 || currentStock > totalInboundUnitsFromMovements) {
    const baselineQty = batches.length === 0 ? currentStock : (currentStock - totalInboundUnitsFromMovements);
    if (baselineQty > 0) {
      batches.unshift({
        id: `init-base-${product.id}`,
        date: product.createdAt || '2026-01-01T00:00:00Z',
        quantity: baselineQty,
        unitCost: roundToMinorUnits(product.costPrice || 0),
        totalCost: roundToMinorUnits(baselineQty * (product.costPrice || 0)),
        source: 'Initial Stock Baseline'
      });
    }
  }

  // Ensure chronologically sorted: oldest first
  batches.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const totalInboundUnits = batches.reduce((sum, b) => sum + b.quantity, 0);
  const totalInboundCost = roundToMinorUnits(batches.reduce((sum, b) => sum + b.totalCost, 0));
  const totalUnitsSoldOrDeducted = Math.max(0, totalInboundUnits - currentStock);

  // --- 1. FIFO (First In, First Out) ---
  // In FIFO, items sold are deducted from the oldest batches first.
  // Therefore, ending inventory of currentStock units consists of the NEWEST batches.
  let fifoVal = 0;
  let remainingNeededFIFO = currentStock;
  const fifoEndingBatches: BatchAllocation[] = [];

  // Traverse from newest to oldest
  for (let i = batches.length - 1; i >= 0 && remainingNeededFIFO > 0; i--) {
    const batch = batches[i];
    const takeQty = Math.min(batch.quantity, remainingNeededFIFO);
    if (takeQty > 0) {
      const lineCost = roundToMinorUnits(takeQty * batch.unitCost);
      fifoVal += lineCost;
      fifoEndingBatches.unshift({
        batchId: batch.id,
        date: batch.date,
        quantity: takeQty,
        unitCost: batch.unitCost,
        totalCost: lineCost,
        source: batch.source
      });
      remainingNeededFIFO -= takeQty;
    }
  }

  if (remainingNeededFIFO > 0) {
    const residualCost = roundToMinorUnits(remainingNeededFIFO * (product.costPrice || 0));
    fifoVal += residualCost;
    fifoEndingBatches.unshift({
      batchId: 'residual-base',
      date: product.createdAt || '2026-01-01T00:00:00Z',
      quantity: remainingNeededFIFO,
      unitCost: roundToMinorUnits(product.costPrice || 0),
      totalCost: residualCost,
      source: 'Base Catalog Unit Cost'
    });
  }

  const fifoValuation = roundToMinorUnits(fifoVal);
  const fifoUnitCost = currentStock > 0 ? roundToMinorUnits(fifoValuation / currentStock) : (product.costPrice || 0);
  const fifoHistoricalCOGS = roundToMinorUnits(Math.max(0, totalInboundCost - fifoValuation));

  // --- 2. LIFO (Last In, First Out) ---
  // In LIFO, items sold are deducted from the newest batches first.
  // Therefore, ending inventory of currentStock units consists of the OLDEST batches (base layers).
  let lifoVal = 0;
  let remainingNeededLIFO = currentStock;
  const lifoEndingBatches: BatchAllocation[] = [];

  // Traverse from oldest to newest
  for (let i = 0; i < batches.length && remainingNeededLIFO > 0; i++) {
    const batch = batches[i];
    const takeQty = Math.min(batch.quantity, remainingNeededLIFO);
    if (takeQty > 0) {
      const lineCost = roundToMinorUnits(takeQty * batch.unitCost);
      lifoVal += lineCost;
      lifoEndingBatches.push({
        batchId: batch.id,
        date: batch.date,
        quantity: takeQty,
        unitCost: batch.unitCost,
        totalCost: lineCost,
        source: batch.source
      });
      remainingNeededLIFO -= takeQty;
    }
  }

  if (remainingNeededLIFO > 0) {
    const residualCost = roundToMinorUnits(remainingNeededLIFO * (product.costPrice || 0));
    lifoVal += residualCost;
    lifoEndingBatches.push({
      batchId: 'residual-base',
      date: product.createdAt || '2026-01-01T00:00:00Z',
      quantity: remainingNeededLIFO,
      unitCost: roundToMinorUnits(product.costPrice || 0),
      totalCost: residualCost,
      source: 'Base Catalog Unit Cost'
    });
  }

  const lifoValuation = roundToMinorUnits(lifoVal);
  const lifoUnitCost = currentStock > 0 ? roundToMinorUnits(lifoValuation / currentStock) : (product.costPrice || 0);
  const lifoHistoricalCOGS = roundToMinorUnits(Math.max(0, totalInboundCost - lifoValuation));

  // --- 3. WAC (Weighted Average Cost) ---
  const wacUnitCost = totalInboundUnits > 0 
    ? roundToMinorUnits(totalInboundCost / totalInboundUnits) 
    : (product.costPrice || 0);
  const wacValuation = roundToMinorUnits(currentStock * wacUnitCost);
  const wacHistoricalCOGS = roundToMinorUnits(Math.max(0, totalInboundCost - wacValuation));

  // --- 4. LIFO Reserve ---
  const lifoReserve = roundToMinorUnits(fifoValuation - lifoValuation);

  return {
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    currentStock,
    costPrice: product.costPrice || 0,
    batches,
    totalInboundUnits,
    totalInboundCost,
    totalUnitsSoldOrDeducted,
    fifoValuation,
    fifoUnitCost,
    fifoEndingBatches,
    fifoHistoricalCOGS,
    lifoValuation,
    lifoUnitCost,
    lifoEndingBatches,
    lifoHistoricalCOGS,
    wacValuation,
    wacUnitCost,
    wacHistoricalCOGS,
    lifoReserve
  };
}

/**
 * Calculates complete inventory valuation summary comparing FIFO, LIFO, and WAC across all products
 */
export function calculateInventoryValuationSummary(
  products: Product[],
  movements: InventoryMovement[] = [],
  activeMethod: InventoryValuationMethod = 'FIFO'
): InventoryValuationSummary {
  const activeProducts = products.filter(p => p.status !== 'archived');
  const productCostings: ProductCostingDetail[] = activeProducts.map(p => 
    calculateProductInventoryCosting(p, movements)
  );

  let fifoTotal = 0;
  let lifoTotal = 0;
  let wacTotal = 0;
  let totalUnits = 0;

  for (const c of productCostings) {
    fifoTotal += c.fifoValuation;
    lifoTotal += c.lifoValuation;
    wacTotal += c.wacValuation;
    totalUnits += c.currentStock;
  }

  const fifoTotalValuation = roundToMinorUnits(fifoTotal);
  const lifoTotalValuation = roundToMinorUnits(lifoTotal);
  const wacTotalValuation = roundToMinorUnits(wacTotal);
  const lifoReserve = roundToMinorUnits(fifoTotalValuation - lifoTotalValuation);

  let activeMethodTotalValuation = fifoTotalValuation;
  if (activeMethod === 'LIFO') {
    activeMethodTotalValuation = lifoTotalValuation;
  } else if (activeMethod === 'WAC') {
    activeMethodTotalValuation = wacTotalValuation;
  }

  return {
    fifoTotalValuation,
    lifoTotalValuation,
    wacTotalValuation,
    activeMethodTotalValuation,
    activeMethod,
    totalStockUnits: totalUnits,
    lifoReserve,
    productCostings
  };
}

export interface DashboardMetrics {
  totalGrossSales: number;
  netMerchandiseSales: number;
  totalNetRevenue: number;
  totalCOGS: number;
  grossProfit: number;
  grossMarginPercent: number;
  directOrderContribution: number;
  totalOperatingExpenses: number;
  netOperatingProfit: number;
  netOperatingMarginPercent: number;
  totalOrders: number;
  completedOrders: number;
  pendingOrders: number;
  processingOrders: number;
  cancelledOrders: number;
  outstandingReceivables: number;
  outstandingPayables: number;
  totalCashCollected: number;
  lowStockCount: number;
  outOfStockCount: number;
  totalInventoryValuation: number;
  fifoInventoryValuation: number;
  lifoInventoryValuation: number;
  wacInventoryValuation: number;
  lifoReserve: number;
  activeValuationMethod: InventoryValuationMethod;
}

export function filterOrdersByDateRange(orders: Order[], range: string): Order[] {
  if (range === 'all') return orders;
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  return orders.filter(o => {
    const orderDate = new Date(o.date).getTime();
    switch (range) {
      case 'today':
        return orderDate >= startOfDay;
      case 'yesterday': {
        const yStart = startOfDay - 86400000;
        return orderDate >= yStart && orderDate < startOfDay;
      }
      case '7days':
        return orderDate >= (startOfDay - 7 * 86400000);
      case '30days':
        return orderDate >= (startOfDay - 30 * 86400000);
      case 'thisMonth': {
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
        return orderDate >= monthStart;
      }
      case 'lastMonth': {
        const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
        const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
        return orderDate >= lastMonthStart && orderDate < thisMonthStart;
      }
      case 'thisYear': {
        const yearStart = new Date(now.getFullYear(), 0, 1).getTime();
        return orderDate >= yearStart;
      }
      default:
        return true;
    }
  });
}

export function filterExpensesByDateRange(expenses: Expense[], range: string): Expense[] {
  if (range === 'all') return expenses;
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  return expenses.filter(e => {
    const expenseDate = new Date(e.date).getTime();
    switch (range) {
      case 'today':
        return expenseDate >= startOfDay;
      case 'yesterday': {
        const yStart = startOfDay - 86400000;
        return expenseDate >= yStart && expenseDate < startOfDay;
      }
      case '7days':
        return expenseDate >= (startOfDay - 7 * 86400000);
      case '30days':
        return expenseDate >= (startOfDay - 30 * 86400000);
      case 'thisMonth': {
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
        return expenseDate >= monthStart;
      }
      case 'lastMonth': {
        const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
        const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
        return expenseDate >= lastMonthStart && expenseDate < thisMonthStart;
      }
      case 'thisYear': {
        const yearStart = new Date(now.getFullYear(), 0, 1).getTime();
        return expenseDate >= yearStart;
      }
      default:
        return true;
    }
  });
}

/**
 * A1: Customer outstanding receivables — unpaid balances over the customer's
 * non-cancelled, non-fully-refunded orders. Matches by customer id or phone.
 */
export function calculateCustomerOutstanding(orders: Order[], customer: Customer): number {
  return roundToMinorUnits(
    orders
      .filter(o =>
        (o.customerId === customer.id || o.customerPhone === customer.phone) &&
        o.orderStatus !== 'cancelled' &&
        o.paymentStatus !== 'refunded'
      )
      .reduce((sum, o) => sum + Math.max(0, o.totalAmount - (o.amountPaid || 0)), 0)
  );
}

/** Core P&L aggregation shared by calculateDashboardMetrics and calculatePeriodMetrics (B2). */
interface FinancialAggregate {
  totalGrossSales: number;
  netMerchandiseSales: number;
  totalNetRevenue: number;
  totalCOGS: number;
  totalVariableCosts: number;
  grossProfit: number;
  grossMarginPercent: number;
  directOrderContribution: number;
  totalOperatingExpenses: number;
  netOperatingProfit: number;
  netOperatingMarginPercent: number;
  totalCashCollected: number;
  outstandingReceivables: number;
}

function aggregateFinancials(orders: Order[], expenses: Expense[]): FinancialAggregate {
  // Only non-cancelled orders contribute to sales and COGS
  const activeOrders = orders.filter(o => o.orderStatus !== 'cancelled');

  let totalGrossSales = 0;
  let netMerchandiseSales = 0;
  let totalNetRevenue = 0;
  let totalCOGS = 0;
  let totalVariableCosts = 0;
  let totalCashCollected = 0;
  let outstandingReceivables = 0;

  for (const o of activeOrders) {
    const breakdown = calculateOrderProfit(o);
    totalGrossSales += breakdown.grossMerchandiseSales;
    netMerchandiseSales += breakdown.netMerchandiseSales;
    totalNetRevenue += breakdown.netRevenue;
    totalCOGS += breakdown.cogs;
    totalVariableCosts += breakdown.totalVariableCosts;
    totalCashCollected += o.amountPaid || 0;

    // Receivables are unpaid portions of delivered or confirmed orders
    if (o.orderStatus !== 'draft') {
      const remaining = o.totalAmount - (o.amountPaid || 0);
      if (remaining > 0) {
        outstandingReceivables += remaining;
      }
    }
  }

  // Operating Expenses = expenses marked as 'operating'
  const operatingExpenses = expenses.filter(e => e.type === 'operating');
  const totalOperatingExpenses = roundToMinorUnits(
    operatingExpenses.reduce((sum, e) => sum + e.amount, 0)
  );

  totalGrossSales = roundToMinorUnits(totalGrossSales);
  netMerchandiseSales = roundToMinorUnits(netMerchandiseSales);
  totalNetRevenue = roundToMinorUnits(totalNetRevenue);
  totalCOGS = roundToMinorUnits(totalCOGS);
  const grossProfit = roundToMinorUnits(netMerchandiseSales - totalCOGS);
  const grossMarginPercent = netMerchandiseSales > 0
    ? roundToMinorUnits((grossProfit / netMerchandiseSales) * 100, 1)
    : 0;

  const directOrderContribution = roundToMinorUnits(totalNetRevenue - totalCOGS - totalVariableCosts);

  // Net Operating Profit = Net Merchandise Sales + Delivery Revenue - COGS - Direct Order Expenses - Operating Overhead
  const netOperatingProfit = roundToMinorUnits(directOrderContribution - totalOperatingExpenses);
  const netOperatingMarginPercent = totalNetRevenue > 0
    ? roundToMinorUnits((netOperatingProfit / totalNetRevenue) * 100, 1)
    : 0;

  return {
    totalGrossSales,
    netMerchandiseSales,
    totalNetRevenue,
    totalCOGS,
    totalVariableCosts,
    grossProfit,
    grossMarginPercent,
    directOrderContribution,
    totalOperatingExpenses,
    netOperatingProfit,
    netOperatingMarginPercent,
    totalCashCollected,
    outstandingReceivables: roundToMinorUnits(outstandingReceivables)
  };
}

/** Slim metric set for period-over-period trend deltas (B2). */
export interface PeriodTrendMetrics {
  netSales: number;
  netRevenue: number;
  cogs: number;
  operatingExpenses: number;
  netOperatingProfit: number;
}

/**
 * Computes trend metrics over pre-filtered orders/expenses (e.g. an arbitrary
 * window via filterOrdersByWindow). Reuses the same aggregation as the dashboard.
 */
export function calculatePeriodMetrics(orders: Order[], expenses: Expense[]): PeriodTrendMetrics {
  const agg = aggregateFinancials(orders, expenses);
  return {
    netSales: agg.netMerchandiseSales,
    netRevenue: agg.totalNetRevenue,
    cogs: agg.totalCOGS,
    operatingExpenses: agg.totalOperatingExpenses,
    netOperatingProfit: agg.netOperatingProfit
  };
}

/** Arbitrary-window filters (B2 trends). Bounds are inclusive-start, exclusive-end. */
export function filterOrdersByWindow(orders: Order[], startMs: number, endMs: number): Order[] {
  return orders.filter(o => {
    const t = new Date(o.date).getTime();
    return t >= startMs && t < endMs;
  });
}

export function filterExpensesByWindow(expenses: Expense[], startMs: number, endMs: number): Expense[] {
  return expenses.filter(e => {
    const t = new Date(e.date).getTime();
    return t >= startMs && t < endMs;
  });
}

const DAY_MS = 86400000;

/**
 * Previous equivalent period for a dashboard date-range key (B2).
 * Returns null when there is no meaningful previous period ('all').
 */
export function getPreviousPeriodWindow(range: string): { start: number; end: number } | null {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  switch (range) {
    case 'today':
      return { start: startOfDay - DAY_MS, end: startOfDay };
    case 'yesterday':
      return { start: startOfDay - 2 * DAY_MS, end: startOfDay - DAY_MS };
    case '7days':
      return { start: startOfDay - 14 * DAY_MS, end: startOfDay - 7 * DAY_MS };
    case '30days':
      return { start: startOfDay - 60 * DAY_MS, end: startOfDay - 30 * DAY_MS };
    case 'thisMonth': {
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
      return { start: lastMonthStart, end: thisMonthStart };
    }
    case 'lastMonth': {
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
      const twoMonthsAgoStart = new Date(now.getFullYear(), now.getMonth() - 2, 1).getTime();
      return { start: twoMonthsAgoStart, end: lastMonthStart };
    }
    case 'thisYear': {
      const thisYearStart = new Date(now.getFullYear(), 0, 1).getTime();
      const lastYearStart = new Date(now.getFullYear() - 1, 0, 1).getTime();
      return { start: lastYearStart, end: thisYearStart };
    }
    default:
      return null;
  }
}

/** Human label for the comparison period, e.g. "vs prior 30 days". */
export function previousPeriodLabel(range: string): string {
  switch (range) {
    case 'today': return 'vs yesterday';
    case 'yesterday': return 'vs day before';
    case '7days': return 'vs prior 7 days';
    case '30days': return 'vs prior 30 days';
    case 'thisMonth': return 'vs last month';
    case 'lastMonth': return 'vs month before';
    case 'thisYear': return 'vs last year';
    default: return '';
  }
}

/** Net revenue contributed by one order (shared by revenue bucketing). */
function revenueOf(order: Order): number {
  return calculateOrderProfit(order).netRevenue;
}

/** Revenue buckets for the dashboard sparkline (B2). Bucket count adapts to the range. */
export interface RevenueBucket { label: string; value: number; }

export function bucketRevenueByRange(orders: Order[], range: string): RevenueBucket[] {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  interface RawBucket { label: string; start: number; end: number; value: number; }
  const buckets: RawBucket[] = [];
  const push = (label: string, start: number, end: number) => buckets.push({ label, start, end, value: 0 });

  switch (range) {
    case 'today':
    case 'yesterday': {
      const base = range === 'today' ? startOfDay : startOfDay - DAY_MS;
      for (let i = 0; i < 8; i++) {
        const h = new Date(base + i * 3 * 3600000).getHours();
        push(`${h}:00`, base + i * 3 * 3600000, base + (i + 1) * 3 * 3600000);
      }
      break;
    }
    case '7days':
      for (let i = 0; i < 7; i++) {
        const s = startOfDay - (6 - i) * DAY_MS;
        push(new Date(s).toLocaleDateString([], { weekday: 'short' }), s, s + DAY_MS);
      }
      break;
    case 'thisMonth': {
      const mStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
      for (let d = 1; d <= now.getDate(); d++) {
        const s = mStart + (d - 1) * DAY_MS;
        push(`${d}`, s, s + DAY_MS);
      }
      break;
    }
    case 'lastMonth': {
      const lmStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).getTime();
      const daysInLastMonth = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      for (let d = 1; d <= daysInLastMonth; d++) {
        const s = lmStart + (d - 1) * DAY_MS;
        push(`${d}`, s, s + DAY_MS);
      }
      break;
    }
    case 'thisYear':
      for (let m = 0; m < 12; m++) {
        const s = new Date(now.getFullYear(), m, 1).getTime();
        const e = new Date(now.getFullYear(), m + 1, 1).getTime();
        push(new Date(s).toLocaleDateString([], { month: 'short' }), s, e);
      }
      break;
    case 'all': {
      for (let k = 11; k >= 0; k--) {
        const s = new Date(now.getFullYear(), now.getMonth() - k, 1).getTime();
        const d = new Date(s);
        const e = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime();
        push(d.toLocaleDateString([], { month: 'short' }), s, e);
      }
      break;
    }
    case '30days':
    default: {
      for (let i = 0; i < 30; i++) {
        const s = startOfDay - (29 - i) * DAY_MS;
        push(new Date(s).toLocaleDateString([], { day: 'numeric', month: 'short' }), s, s + DAY_MS);
      }
      break;
    }
  }

  for (const o of orders) {
    if (o.orderStatus === 'cancelled') continue;
    const t = new Date(o.date).getTime();
    const b = buckets.find(bk => t >= bk.start && t < bk.end);
    if (b) b.value = roundToMinorUnits(b.value + revenueOf(o));
  }
  return buckets.map(({ label, value }) => ({ label, value }));
}

export function calculateDashboardMetrics(
  orders: Order[],
  expenses: Expense[],
  products: Product[],
  range: string = '30days',
  outstandingSupplierPayables: number = 0,
  movements: InventoryMovement[] = [],
  valuationMethod: InventoryValuationMethod = 'FIFO'
): DashboardMetrics {
  const filteredOrders = filterOrdersByDateRange(orders, range);
  const filteredExpenses = filterExpensesByDateRange(expenses, range);

  const {
    totalGrossSales,
    netMerchandiseSales,
    totalNetRevenue,
    totalCOGS,
    grossProfit,
    grossMarginPercent,
    directOrderContribution,
    totalOperatingExpenses,
    netOperatingProfit,
    netOperatingMarginPercent,
    totalCashCollected,
    outstandingReceivables
  } = aggregateFinancials(filteredOrders, filteredExpenses);

  const completedOrders = filteredOrders.filter(o => o.orderStatus === 'delivered').length;
  const pendingOrders = filteredOrders.filter(o => o.orderStatus === 'pending' || o.orderStatus === 'draft').length;
  const processingOrders = filteredOrders.filter(o => ['confirmed', 'processing', 'ready', 'shipped'].includes(o.orderStatus)).length;
  const cancelledOrders = filteredOrders.filter(o => o.orderStatus === 'cancelled').length;

  // Inventory stats & Valuation under FIFO, LIFO, and WAC
  let lowStockCount = 0;
  let outOfStockCount = 0;

  for (const p of products) {
    if (p.status !== 'archived') {
      const stock = p.stock || 0;
      if (stock <= 0) {
        outOfStockCount++;
      } else if (stock <= p.minStockAlert) {
        lowStockCount++;
      }
    }
  }

  const valuationSummary = calculateInventoryValuationSummary(products, movements, valuationMethod);

  return {
    totalGrossSales,
    netMerchandiseSales,
    totalNetRevenue,
    totalCOGS,
    grossProfit,
    grossMarginPercent,
    directOrderContribution,
    totalOperatingExpenses,
    netOperatingProfit,
    netOperatingMarginPercent,
    totalOrders: filteredOrders.length,
    completedOrders,
    pendingOrders,
    processingOrders,
    cancelledOrders,
    outstandingReceivables: roundToMinorUnits(outstandingReceivables),
    outstandingPayables: roundToMinorUnits(outstandingSupplierPayables),
    totalCashCollected: roundToMinorUnits(totalCashCollected),
    lowStockCount,
    outOfStockCount,
    totalInventoryValuation: valuationSummary.activeMethodTotalValuation,
    fifoInventoryValuation: valuationSummary.fifoTotalValuation,
    lifoInventoryValuation: valuationSummary.lifoTotalValuation,
    wacInventoryValuation: valuationSummary.wacTotalValuation,
    lifoReserve: valuationSummary.lifoReserve,
    activeValuationMethod: valuationMethod
  };
}

export interface VerificationTestResult {
  id: string;
  name: string;
  category: string;
  description: string;
  passed: boolean;
  expected: string;
  actual: string;
  details: string;
}

/**
 * Automated Verification Suite covering all critical accounting requirements specified in Section 22:
 * 1. Spec Example (Cost 3000, Sell 4000, Disc 100, DelivCol 150, DelivExp 120, Fee 40, Pack 30) -> Net sales 3900, GP 900, Contribution 860.
 * 2. Delivery charge neutrality: Customer delivery charge is NOT counted as pure profit; delivery expense is subtracted.
 * 3. Discount logic: Discounts subtracted from gross sales, never deducted twice.
 * 4. COGS isolation: Product cost snapshot preserved, never deducted twice.
 * 5. Partial payments: Order total vs customer paid balance tracking.
 * 6. Refund logic: Refunds reduce net merchandise sales.
 * 7. Transfer neutrality: Account transfers between Cash & Bank do not alter P&L revenue or operating expenses.
 * 8. OPEX vs CAPEX/Asset separation: Inventory purchase is an asset movement, not operating overhead.
 */
export function runAccountingVerificationSuite(): VerificationTestResult[] {
  const tests: VerificationTestResult[] = [];

  // Test 1: Exact specification example from Prompt Section 6
  {
    const calc = calculateOrderProfit({
      items: [{ quantity: 1, unitPrice: 4000, unitCostSnapshot: 3000 }],
      discount: 100,
      deliveryChargeCollected: 150,
      actualDeliveryExpense: 120,
      paymentFee: 40,
      packagingExpense: 30
    });

    const netSalesPassed = calc.netMerchandiseSales === 3900;
    const grossProfitPassed = calc.grossProfit === 900;
    const contributionPassed = calc.netOrderContribution === 860;
    const allPassed = netSalesPassed && grossProfitPassed && contributionPassed;

    tests.push({
      id: 'spec_core_example',
      name: 'Specification Core Profit Model (Section 6)',
      category: 'Profit Calculation',
      description: 'Tests the exact benchmark: Selling ৳4,000, Cost ৳3,000, Discount ৳100, Deliv ৳150 vs ৳120, Fee ৳40, Pack ৳30.',
      passed: allPassed,
      expected: 'Net Sales: ৳3,900 | Gross Profit: ৳900 | Order Contribution: ৳860',
      actual: `Net Sales: ৳${calc.netMerchandiseSales} | Gross Profit: ৳${calc.grossProfit} | Order Contribution: ৳${calc.netOrderContribution}`,
      details: allPassed ? 'Matches exact specification breakdown step-by-step.' : 'Variance detected in formula calculation.'
    });
  }

  // Test 2: Delivery fee vs delivery expense isolation
  {
    const calc = calculateOrderProfit({
      items: [{ quantity: 1, unitPrice: 1000, unitCostSnapshot: 500 }],
      discount: 0,
      deliveryChargeCollected: 200,
      actualDeliveryExpense: 250 // Business subsidizes delivery
    });
    // Net merchandise sales: 1000
    // Gross profit: 1000 - 500 = 500
    // Net revenue: 1000 + 200 = 1200
    // Contribution: 1200 - 500 - 250 = 450 (Delivery subsidy reduced contribution by 50)
    const passed = calc.grossProfit === 500 && calc.netOrderContribution === 450;
    tests.push({
      id: 'delivery_margin_isolation',
      name: 'Delivery Revenue vs Incurred Delivery Expense',
      category: 'Revenue Recognition',
      description: 'Customer delivery charge must NOT be treated as profit by itself; actual courier expense must be offset.',
      passed,
      expected: 'Gross Profit: ৳500 | Net Contribution: ৳450 (৳50 courier loss reflected)',
      actual: `Gross Profit: ৳${calc.grossProfit} | Net Contribution: ৳${calc.netOrderContribution}`,
      details: passed ? 'Properly separates gross merchandise profit from logistics margin.' : 'Failed to offset delivery cost.'
    });
  }

  // Test 3: Multiple line items with item-level and order-level discounts
  {
    const calc = calculateOrderProfit({
      items: [
        { quantity: 2, unitPrice: 500, unitCostSnapshot: 250, discount: 50 }, // 1000 - 50 = 950
        { quantity: 1, unitPrice: 800, unitCostSnapshot: 400, discount: 0 }   // 800
      ],
      discount: 100 // Extra promo code discount
    });
    // Gross: 1000 + 800 = 1800
    // Item discounts: 50
    // Order discount: 100
    // Total discount: 150
    // Net sales: 1650
    // COGS: 500 + 400 = 900
    // Gross profit: 1650 - 900 = 750
    const passed = calc.grossMerchandiseSales === 1800 && calc.netMerchandiseSales === 1650 && calc.grossProfit === 750;
    tests.push({
      id: 'multi_item_discounts',
      name: 'Multi-Item Stacked Discounts & COGS',
      category: 'Discounts & Pricing',
      description: 'Validates line-item discounts combined with cart-level promo discount without double-deduction.',
      passed,
      expected: 'Gross: ৳1,800 | Net Sales: ৳1,650 | COGS: ৳900 | Gross Profit: ৳750',
      actual: `Gross: ৳${calc.grossMerchandiseSales} | Net Sales: ৳${calc.netMerchandiseSales} | COGS: ৳${calc.cogs} | Gross Profit: ৳${calc.grossProfit}`,
      details: passed ? 'Discounts stacked correctly without duplicating deductions.' : 'Discounts error.'
    });
  }

  // Test 4: Refund deduction and returns
  {
    const calc = calculateOrderProfit({
      items: [{ quantity: 1, unitPrice: 2000, unitCostSnapshot: 1000 }],
      discount: 0,
      refundAmount: 500 // Partial customer refund
    });
    // Net sales = 2000 - 500 = 1500
    // Gross profit = 1500 - 1000 = 500
    const passed = calc.netMerchandiseSales === 1500 && calc.grossProfit === 500;
    tests.push({
      id: 'refund_adjustment',
      name: 'Partial Customer Refund Impact',
      category: 'Returns & Refunds',
      description: 'Refunds directly reduce net merchandise sales and gross profit accurately.',
      passed,
      expected: 'Net Sales: ৳1,500 | Gross Profit: ৳500',
      actual: `Net Sales: ৳${calc.netMerchandiseSales} | Gross Profit: ৳${calc.grossProfit}`,
      details: passed ? 'Refund deducts cleanly from recognized merchandise sales.' : 'Refund calculation error.'
    });
  }

  // Test 5: Double-entry Internal Transfer Neutrality
  {
    // A transfer of 10,000 BDT from Cash to Bank should have 0 impact on Net Operating Profit
    const mockOrder: Order = {
      id: 't-1',
      orderNumber: 'ORD-TEST',
      customerId: 'c-1',
      customerName: 'Test Customer',
      customerPhone: '01700000000',
      date: new Date().toISOString(),
      items: [{ productId: 'p1', productName: 'Item', sku: 'SKU1', quantity: 1, unitPrice: 2000, unitCostSnapshot: 1200, discount: 0, total: 2000 }],
      subtotal: 2000,
      discount: 0,
      taxAmount: 0,
      deliveryChargeCollected: 100,
      actualDeliveryExpense: 80,
      packagingExpense: 20,
      paymentFee: 0,
      marketplaceCommission: 0,
      adCostAllocated: 0,
      otherExpenses: 0,
      totalAmount: 2100,
      amountPaid: 2100,
      paymentMethod: 'Cash',
      paymentStatus: 'paid',
      orderStatus: 'delivered',
      createdAt: new Date().toISOString()
    };
    
    // Normal operating expense 300
    const regularExpense: Expense = {
      id: 'e-1',
      date: new Date().toISOString(),
      amount: 300,
      category: 'Rent & Utilities',
      type: 'operating',
      description: 'Electricity bill',
      payee: 'DESCO',
      paymentMethod: 'Cash',
      createdAt: new Date().toISOString()
    };

    // Capital expenditure 5000 (not operating)
    const capexExpense: Expense = {
      id: 'e-2',
      date: new Date().toISOString(),
      amount: 5000,
      category: 'Other Operating Expenses',
      type: 'capital_expenditure',
      description: 'New Laptop',
      payee: 'Tech Shop',
      paymentMethod: 'Bank',
      createdAt: new Date().toISOString()
    };

    const metrics = calculateDashboardMetrics([mockOrder], [regularExpense, capexExpense], [], 'all');
    // Order contribution: 2000 + 100 - 1200 - 80 - 20 = 800
    // Net operating profit: 800 - 300 (only operating expense, capex excluded!) = 500
    const passed = metrics.netOperatingProfit === 500 && metrics.totalOperatingExpenses === 300;
    tests.push({
      id: 'capex_opex_separation',
      name: 'OPEX vs CAPEX Separation in Operating Profit',
      category: 'Financial Ledger',
      description: 'Capital expenditures (assets) and transfers must not inflate operating expenses.',
      passed,
      expected: 'Operating Expenses: ৳300 | Net Operating Profit: ৳500 (৳5,000 CAPEX excluded)',
      actual: `Operating Expenses: ৳${metrics.totalOperatingExpenses} | Net Operating Profit: ৳${metrics.netOperatingProfit}`,
      details: passed ? 'Properly segregates operating overhead from capital acquisitions.' : 'CAPEX incorrectly deducted from operating profit.'
    });
  }

  // Test 6: Partial payment and Accounts Receivable
  {
    const unpaidOrder: Order = {
      id: 't-2',
      orderNumber: 'ORD-UNPAID',
      customerId: 'c-2',
      customerName: 'Credit Client',
      customerPhone: '01800000000',
      date: new Date().toISOString(),
      items: [{ productId: 'p2', productName: 'Item 2', sku: 'SKU2', quantity: 2, unitPrice: 1500, unitCostSnapshot: 1000, discount: 0, total: 3000 }],
      subtotal: 3000,
      discount: 0,
      taxAmount: 0,
      deliveryChargeCollected: 100,
      actualDeliveryExpense: 80,
      packagingExpense: 20,
      paymentFee: 0,
      marketplaceCommission: 0,
      adCostAllocated: 0,
      otherExpenses: 0,
      totalAmount: 3100,
      amountPaid: 1000, // 2,100 unpaid
      paymentMethod: 'Partial',
      paymentStatus: 'partial',
      orderStatus: 'shipped',
      createdAt: new Date().toISOString()
    };

    const metrics = calculateDashboardMetrics([unpaidOrder], [], [], 'all');
    const passed = metrics.outstandingReceivables === 2100 && metrics.totalCashCollected === 1000;
    tests.push({
      id: 'receivables_tracking',
      name: 'Partial Payment & Accounts Receivable Balance',
      category: 'Cash Flow & Receivables',
      description: 'Uncollected order balance is tracked as Accounts Receivable without inflating cash collected.',
      passed,
      expected: 'Cash Collected: ৳1,000 | Outstanding Receivables: ৳2,100',
      actual: `Cash Collected: ৳${metrics.totalCashCollected} | Outstanding Receivables: ৳${metrics.outstandingReceivables}`,
      details: passed ? 'Accounts receivable calculated strictly from ledger balance.' : 'Mismatch in receivables balance.'
    });
  }

  // Test 7: FIFO (First-In, First-Out) Inventory Valuation & Layer Allocation
  {
    const mockProduct: Product = {
      id: 'test-p-fifo',
      name: 'Test Cotton Hoodie',
      sku: 'HOOD-TEST',
      description: 'Test product for inventory costing',
      category: 'Clothing',
      brand: 'TestBrand',
      costPrice: 100,
      sellingPrice: 250,
      stock: 10, // 10 units remaining out of 20 inbound
      minStockAlert: 5,
      unit: 'pcs',
      status: 'active',
      variants: [],
      createdAt: '2026-01-01T00:00:00Z'
    };

    const mockMovements: InventoryMovement[] = [
      {
        id: 'mov-b1',
        productId: 'test-p-fifo',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-10T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 100, // Total 1,000
        balanceAfter: 10,
        createdBy: 'Admin'
      },
      {
        id: 'mov-b2',
        productId: 'test-p-fifo',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-25T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 160, // Total 1,600 (price increased)
        balanceAfter: 20,
        createdBy: 'Admin'
      }
    ];

    const costing = calculateProductInventoryCosting(mockProduct, mockMovements);
    // Under FIFO: The 10 sold units were from the oldest Batch 1 (@ 100).
    // The 10 remaining units are from the newest Batch 2 (@ 160).
    // FIFO Ending Value = 10 * 160 = 1,600. COGS = 1,000.
    const passed = costing.fifoValuation === 1600 && costing.fifoHistoricalCOGS === 1000 && costing.fifoUnitCost === 160;
    tests.push({
      id: 'fifo_inventory_costing',
      name: 'FIFO (First-In, First-Out) Inventory Costing & Layers',
      category: 'Inventory & Costing',
      description: 'Verifies that oldest acquisition costs are depleted first, leaving ending stock valued at newest batch cost.',
      passed,
      expected: 'FIFO Ending Inventory: ৳1,600 (৳160/unit) | FIFO COGS: ৳1,000',
      actual: `FIFO Ending Inventory: ৳${costing.fifoValuation} (৳${costing.fifoUnitCost}/unit) | FIFO COGS: ৳${costing.fifoHistoricalCOGS}`,
      details: passed ? 'FIFO allocates newest costs to balance sheet and oldest costs to COGS.' : 'FIFO calculation error.'
    });
  }

  // Test 8: LIFO (Last-In, First-Out) Inventory Valuation & Layer Allocation
  {
    const mockProduct: Product = {
      id: 'test-p-lifo',
      name: 'Test Cotton Hoodie',
      sku: 'HOOD-TEST',
      description: 'Test product for inventory costing',
      category: 'Clothing',
      brand: 'TestBrand',
      costPrice: 100,
      sellingPrice: 250,
      stock: 10, // 10 units remaining out of 20 inbound
      minStockAlert: 5,
      unit: 'pcs',
      status: 'active',
      variants: [],
      createdAt: '2026-01-01T00:00:00Z'
    };

    const mockMovements: InventoryMovement[] = [
      {
        id: 'mov-b1',
        productId: 'test-p-lifo',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-10T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 100,
        balanceAfter: 10,
        createdBy: 'Admin'
      },
      {
        id: 'mov-b2',
        productId: 'test-p-lifo',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-25T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 160,
        balanceAfter: 20,
        createdBy: 'Admin'
      }
    ];

    const costing = calculateProductInventoryCosting(mockProduct, mockMovements);
    // Under LIFO: The 10 sold units were from the newest Batch 2 (@ 160).
    // The 10 remaining units are from the oldest Batch 1 (@ 100).
    // LIFO Ending Value = 10 * 100 = 1,000. COGS = 1,600.
    const passed = costing.lifoValuation === 1000 && costing.lifoHistoricalCOGS === 1600 && costing.lifoUnitCost === 100;
    tests.push({
      id: 'lifo_inventory_costing',
      name: 'LIFO (Last-In, First-Out) Inventory Costing & Layers',
      category: 'Inventory & Costing',
      description: 'Verifies that newest acquisition costs are matched against sales first, preserving initial cost base in ending inventory.',
      passed,
      expected: 'LIFO Ending Inventory: ৳1,000 (৳100/unit) | LIFO COGS: ৳1,600',
      actual: `LIFO Ending Inventory: ৳${costing.lifoValuation} (৳${costing.lifoUnitCost}/unit) | LIFO COGS: ৳${costing.lifoHistoricalCOGS}`,
      details: passed ? 'LIFO preserves historical base layers in inventory and expenses newest costs.' : 'LIFO calculation error.'
    });
  }

  // Test 9: LIFO Reserve & Cost Balance Invariance
  {
    const mockProduct: Product = {
      id: 'test-p-reserve',
      name: 'Test Cotton Hoodie',
      sku: 'HOOD-TEST',
      description: 'Test product for inventory costing',
      category: 'Clothing',
      brand: 'TestBrand',
      costPrice: 100,
      sellingPrice: 250,
      stock: 10,
      minStockAlert: 5,
      unit: 'pcs',
      status: 'active',
      variants: [],
      createdAt: '2026-01-01T00:00:00Z'
    };

    const mockMovements: InventoryMovement[] = [
      {
        id: 'mov-b1',
        productId: 'test-p-reserve',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-10T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 100,
        balanceAfter: 10,
        createdBy: 'Admin'
      },
      {
        id: 'mov-b2',
        productId: 'test-p-reserve',
        productName: 'Test Cotton Hoodie',
        date: '2026-01-25T10:00:00Z',
        type: 'purchase_receipt',
        quantity: 10,
        unitCost: 160,
        balanceAfter: 20,
        createdBy: 'Admin'
      }
    ];

    const costing = calculateProductInventoryCosting(mockProduct, mockMovements);
    // LIFO Reserve = FIFO Value (1,600) - LIFO Value (1,000) = 600.
    // LIFO COGS (1,600) - FIFO COGS (1,000) = 600 = LIFO Reserve.
    // Total cost identity: 1,600 + 1,000 = 2,600 in both methods.
    const passed = costing.lifoReserve === 600 && (costing.lifoHistoricalCOGS - costing.fifoHistoricalCOGS === 600);
    tests.push({
      id: 'lifo_reserve_identity',
      name: 'LIFO Reserve & Accounting Balance Identity',
      category: 'Inventory & Costing',
      description: 'Validates that LIFO Reserve (FIFO - LIFO Valuation) exactly equals the COGS variance between the two methods.',
      passed,
      expected: 'LIFO Reserve: ৳600 | COGS Variance (LIFO - FIFO): ৳600',
      actual: `LIFO Reserve: ৳${costing.lifoReserve} | COGS Variance: ৳${costing.lifoHistoricalCOGS - costing.fifoHistoricalCOGS}`,
      details: passed ? 'LIFO reserve matches COGS difference with mathematical certainty.' : 'LIFO reserve mismatch.'
    });
  }

  return tests;
}
