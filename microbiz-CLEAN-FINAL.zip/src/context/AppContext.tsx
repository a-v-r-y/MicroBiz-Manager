import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { useAuth, PermissionAction } from './AuthContext';
import { AuthUser } from '../types/auth';
import { encryptWithPassword, decryptWithPassword } from '../utils/cryptoAuth';
import { generateDueRecurringInstances } from '../utils/recurring';
import { 
  BusinessSettings, 
  Product, 
  Customer, 
  Supplier, 
  Order, 
  PurchaseOrder, 
  Expense, 
  FinancialAccount, 
  CashTransaction, 
  InventoryMovement,
  UserProfile,
  UserRole,
  AuditLog,
  OrderStatus,
  PaymentStatus,
  MovementType,
  NotificationType,
  AppNotification
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_SUPPLIERS,
  INITIAL_ORDERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_EXPENSES,
  INITIAL_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  INITIAL_MOVEMENTS,
  INITIAL_USER
} from '../data/sampleData';

interface AppContextType {
  user: UserProfile;
  settings: BusinessSettings;
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  orders: Order[];
  purchaseOrders: PurchaseOrder[];
  expenses: Expense[];
  accounts: FinancialAccount[];
  transactions: CashTransaction[];
  movements: InventoryMovement[];
  auditLogs: AuditLog[];
  darkMode: boolean;
  toggleDarkMode: () => void;
  setUserRole: (role: UserRole) => void;
  updateSettings: (newSettings: Partial<BusinessSettings>) => void;

  // Order actions
  addOrder: (order: Omit<Order, 'id' | 'orderNumber' | 'createdAt'>) => Order | null;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  updateOrderStatus: (id: string, newStatus: OrderStatus) => void;
  recordOrderPayment: (orderId: string, amount: number, accountId: string, method: string) => void;
  refundOrder: (orderId: string, refundAmount: number, accountId?: string, isFullReturn?: boolean) => void;
  /** A2: item-level sales returns — restocks only the returned quantities. */
  returnOrderItems: (orderId: string, lines: ReturnLineInput[], refundAmount: number, accountId?: string) => void;
  /** Explicit audit entry for UI flows (e.g. credit-limit overrides). Call only from already-gated flows. */
  logAuditEvent: (action: string, entity: string, details: string) => void;

  // Product actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Product | null;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  archiveProduct: (id: string) => void;
  bulkImportProducts: (newProducts: Array<Omit<Product, 'id' | 'createdAt'>>) => void;

  // Inventory actions
  adjustStock: (productId: string, quantityChange: number, type: MovementType, notes?: string, unitCost?: number, variantId?: string) => boolean;

  // Purchase Order actions
  addPurchaseOrder: (po: Omit<PurchaseOrder, 'id' | 'poNumber' | 'createdAt'>) => PurchaseOrder | null;
  updatePurchaseOrderStatus: (poId: string, status: PurchaseOrder['status']) => void;
  receivePurchaseOrder: (poId: string, variantId?: string) => void;
  recordPOPayment: (poId: string, amount: number, accountId: string) => void;

  // Expense actions
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => Expense | null;
  deleteExpense: (id: string) => void;

  // Customer & Supplier actions
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => Customer | null;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  addSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt'>) => Supplier | null;
  updateSupplier: (id: string, updates: Partial<Supplier>) => void;

  // Financial Account & Transfer actions
  addAccount: (account: Omit<FinancialAccount, 'id'>) => FinancialAccount | null;
  transferFunds: (fromAccountId: string, toAccountId: string, amount: number, fee?: number, description?: string) => boolean;
  reconcileTransaction: (txId: string) => void;

  // Backup & Reset
  resetToSampleData: () => void;
  /** Wipes all business data for a clean start (used by the onboarding wizard). */
  clearAllData: () => void;
  /** AES-GCM encrypted backup (password-derived key). Includes users + audit logs. */
  exportEncryptedBackup: (password: string) => Promise<string>;
  /** Validates schema before touching any state; rejects with error on mismatch. */
  importEncryptedBackup: (password: string, payload: string) => Promise<{ success: boolean; error?: string }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

/** A2: one returned line — quantity must not exceed the item's remaining (unreturned) quantity. */
export interface ReturnLineInput {
  productId: string;
  variantId?: string;
  quantity: number;
}

const STORAGE_PREFIX = 'microbiz_mgr_';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // RBAC: write operations below are gated through the signed-in user's permissions
  const { can, getBackupUsers, restoreBackupUsers } = useAuth();

  /** Returns true when the action is DENIED (and notifies the user). */
  const deny = (action: PermissionAction): boolean => {
    if (can(action)) return false;
    notify(
      'Permission denied',
      `Your role cannot perform "${action}". Please contact the business owner.`,
      'critical',
      'system',
      'settings',
      'security_alert'
    );
    return true;
  };

  /** Fire a notification via the NotificationProvider bridge (I12, B1). */
  const notify = (
    title: string,
    message: string,
    priority: 'critical' | 'warning' | 'info' | 'success' = 'warning',
    category: AppNotification['category'] = 'inventory',
    targetTab: AppNotification['targetTab'] = 'inventory',
    type: NotificationType = 'inventory_low'
  ) => {
    window.dispatchEvent(new CustomEvent('microbiz:notify', {
      detail: { type, title, message, priority, category, targetTab }
    }));
  };

  // Load state or fallback to sample seed
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}user`);
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [settings, setSettings] = useState<BusinessSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}settings`);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}products`);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}customers`);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}suppliers`);
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}orders`);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}purchaseOrders`);
    return saved ? JSON.parse(saved) : INITIAL_PURCHASE_ORDERS;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}expenses`);
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [accounts, setAccounts] = useState<FinancialAccount[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}accounts`);
    return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
  });

  const [transactions, setTransactions] = useState<CashTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}transactions`);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [movements, setMovements] = useState<InventoryMovement[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}movements`);
    return saved ? JSON.parse(saved) : INITIAL_MOVEMENTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}auditLogs`);
    return saved ? JSON.parse(saved) : [
      {
        id: 'aud-1',
        timestamp: new Date().toISOString(),
        user: 'Tanvir Hossain',
        action: 'System Initialized',
        entity: 'System',
        details: 'MicroBiz Manager loaded successfully with business profile'
      }
    ];
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem(`${STORAGE_PREFIX}darkMode`) === 'true';
  });

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(`${STORAGE_PREFIX}darkMode`, String(darkMode));
  }, [darkMode]);

  // Persist state changes
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}user`, JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}settings`, JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}products`, JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}customers`, JSON.stringify(customers)); }, [customers]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}suppliers`, JSON.stringify(suppliers)); }, [suppliers]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}orders`, JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}purchaseOrders`, JSON.stringify(purchaseOrders)); }, [purchaseOrders]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}expenses`, JSON.stringify(expenses)); }, [expenses]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}accounts`, JSON.stringify(accounts)); }, [accounts]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}transactions`, JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}movements`, JSON.stringify(movements)); }, [movements]);
  useEffect(() => { localStorage.setItem(`${STORAGE_PREFIX}auditLogs`, JSON.stringify(auditLogs)); }, [auditLogs]);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  const logAudit = (action: string, entity: string, details: string) => {
    const entry: AuditLog = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      user: user.name,
      action,
      entity,
      details
    };
    setAuditLogs(prev => [entry, ...prev.slice(0, 99)]);
  };

  const setUserRole = (role: UserRole) => {
    setUser(prev => ({ ...prev, role }));
    logAudit('Role Switched', 'User', `Active simulation role changed to ${role}`);
  };

  const updateSettings = (newSettings: Partial<BusinessSettings>) => {
    if (deny('settings.update')) return;
    setSettings(prev => ({ ...prev, ...newSettings }));
    logAudit('Settings Updated', 'BusinessSettings', 'Business configurations updated');
  };

  // Order Actions
  const addOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt'>): Order | null => {
    if (deny('orders.create')) return null;

    const orderNumber = `ORD-${1000 + orders.length + 1}`;
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString()
    };

    // If inventory tracking is enabled and order is confirmed or delivered, deduct inventory and log movements
    if (settings.inventoryTracking && newOrder.orderStatus !== 'cancelled' && newOrder.orderStatus !== 'draft') {
      // I12: block when stock is insufficient and negative stock is not allowed
      for (const item of newOrder.items) {
        const prod = products.find(p => p.id === item.productId);
        if (!prod) continue;
        const variant = item.variantId ? prod.variants.find(v => v.id === item.variantId) : undefined;
        const available = variant ? variant.stock : prod.stock;
        if (item.quantity > available) {
          if (!settings.allowNegativeStock) {
            notify(
              'Order blocked: insufficient stock',
              `Insufficient stock for "${item.productName}"${variant ? ` (${variant.name})` : ''}. Available: ${available}, requested: ${item.quantity}.`,
              'critical',
              'orders',
              'orders',
              'order_pending'
            );
            return null;
          }
          // Negative stock is allowed — warn loudly instead of blocking
          notify(
            'Negative stock sale recorded',
            `Order ${orderNumber}: sold ${item.quantity} × "${item.productName}"${variant ? ` (${variant.name})` : ''} with only ${available} in stock. Inventory went negative.`,
            'warning'
          );
        }
      }

      newOrder.items.forEach(item => {
        const prod = products.find(p => p.id === item.productId);
        if (prod) {
          const variant = item.variantId ? prod.variants.find(v => v.id === item.variantId) : undefined;
          // I9: variant stock is decremented alongside product stock
          const newVariantStock = variant
            ? (settings.allowNegativeStock ? variant.stock - item.quantity : Math.max(0, variant.stock - item.quantity))
            : undefined;
          const newStock = settings.allowNegativeStock
            ? prod.stock - item.quantity
            : Math.max(0, prod.stock - item.quantity);
          // Movement log
          const movement: InventoryMovement = {
            id: `mov-${Date.now()}-${Math.random()}`,
            productId: prod.id,
            productName: prod.name,
            variantId: item.variantId,
            variantName: variant?.name,
            date: newOrder.date,
            type: 'sale',
            quantity: -item.quantity,
            unitCost: item.unitCostSnapshot,
            balanceAfter: newVariantStock !== undefined ? newVariantStock : newStock,
            referenceId: orderNumber,
            notes: `Sold in order ${orderNumber}`,
            createdBy: user.name
          };
          setMovements(prev => [movement, ...prev]);
        }
      });

      // Update product stock levels (and variant stock levels)
      setProducts(prev => prev.map(p => {
        const matchedItems = newOrder.items.filter(i => i.productId === p.id);
        if (matchedItems.length === 0) return p;
        const totalQtyDeducted = matchedItems.reduce((sum, i) => sum + i.quantity, 0);
        const variants = p.variants && p.variants.length > 0
          ? p.variants.map(v => {
              const vQty = matchedItems.filter(i => i.variantId === v.id).reduce((sum, i) => sum + i.quantity, 0);
              if (!vQty) return v;
              return { ...v, stock: settings.allowNegativeStock ? v.stock - vQty : Math.max(0, v.stock - vQty) };
            })
          : p.variants;
        return {
          ...p,
          variants,
          stock: settings.allowNegativeStock ? p.stock - totalQtyDeducted : Math.max(0, p.stock - totalQtyDeducted)
        };
      }));
    }

    // If payment was made at order placement, record cash transaction and update account balance
    if (newOrder.amountPaid > 0 && newOrder.paymentAccountId) {
      const tx: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: newOrder.date,
        type: 'customer_payment',
        amount: newOrder.amountPaid,
        fee: newOrder.paymentFee,
        toAccountId: newOrder.paymentAccountId,
        reference: orderNumber,
        description: `Payment for ${orderNumber} (${newOrder.customerName})`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [tx, ...prev]);

      setAccounts(prev => prev.map(acc => {
        if (acc.id === newOrder.paymentAccountId) {
          return { ...acc, balance: acc.balance + newOrder.amountPaid - (newOrder.paymentFee || 0) };
        }
        return acc;
      }));
    }

    setOrders(prev => [newOrder, ...prev]);
    logAudit('Order Created', 'Order', `Order ${orderNumber} created for customer ${newOrder.customerName}`);
    return newOrder;
  };

  const updateOrder = (id: string, updates: Partial<Order>) => {
    if (deny('orders.update')) return;
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
    logAudit('Order Modified', 'Order', `Order ${id} details updated`);
  };

  const updateOrderStatus = (id: string, newStatus: OrderStatus) => {
    if (deny('orders.update')) return;
    const existing = orders.find(o => o.id === id);
    if (!existing) return;

    // Handle cancellation: return reserved items to stock — but ONLY when
    // cancelling from a status that had actually deducted stock (I1).
    // addOrder deducts for every status except 'cancelled' and 'draft', so
    // cancelling a draft must NOT create phantom stock.
    const hadDeductedStock = existing.orderStatus !== 'cancelled' && existing.orderStatus !== 'draft';
    if (newStatus === 'cancelled' && hadDeductedStock) {
      if (settings.inventoryTracking) {
        existing.items.forEach(item => {
          const prod = products.find(p => p.id === item.productId);
          if (prod) {
            const variant = item.variantId ? prod.variants.find(v => v.id === item.variantId) : undefined;
            const newStock = prod.stock + item.quantity;
            const movement: InventoryMovement = {
              id: `mov-${Date.now()}-${Math.random()}`,
              productId: prod.id,
              productName: prod.name,
              variantId: item.variantId,
              variantName: variant?.name,
              date: new Date().toISOString(),
              type: 'manual_adjustment',
              quantity: item.quantity,
              unitCost: item.unitCostSnapshot,
              balanceAfter: newStock,
              referenceId: existing.orderNumber,
              notes: `Stock returned due to cancelled order ${existing.orderNumber}`,
              createdBy: user.name
            };
            setMovements(prev => [movement, ...prev]);
          }
        });

        setProducts(prev => prev.map(p => {
          const matched = existing.items.filter(i => i.productId === p.id);
          if (matched.length === 0) return p;
          const returned = matched.reduce((sum, i) => sum + i.quantity, 0);
          const variants = p.variants && p.variants.length > 0
            ? p.variants.map(v => {
                const vQty = matched.filter(i => i.variantId === v.id).reduce((sum, i) => sum + i.quantity, 0);
                return vQty ? { ...v, stock: v.stock + vQty } : v;
              })
            : p.variants;
          return { ...p, variants, stock: p.stock + returned };
        }));
      }
    }

    setOrders(prev => prev.map(o => o.id === id ? { ...o, orderStatus: newStatus } : o));
    logAudit('Order Status Updated', 'Order', `Order ${existing.orderNumber} status changed to ${newStatus}`);
  };

  const recordOrderPayment = (orderId: string, amount: number, accountId: string, method: string) => {
    if (deny('orders.payment')) return;
    const target = orders.find(o => o.id === orderId);
    if (!target) return;

    const newAmountPaid = (target.amountPaid || 0) + amount;
    const newPaymentStatus: PaymentStatus = newAmountPaid >= target.totalAmount ? 'paid' : 'partial';

    // Update order
    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      amountPaid: newAmountPaid,
      paymentStatus: newPaymentStatus,
      paymentAccountId: accountId,
      paymentMethod: method
    } : o));

    // Record cash transaction
    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'customer_payment',
      amount,
      toAccountId: accountId,
      reference: target.orderNumber,
      description: `Payment collected for ${target.orderNumber}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [tx, ...prev]);

    // Update account balance
    setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance + amount } : acc));
    logAudit('Payment Received', 'Order', `Received ${amount} for order ${target.orderNumber}`);
  };

  // Shared refund helpers (I13 + A2). refundOrder and returnOrderItems both
  // build on these so the money math exists in exactly one place.

  /** Pure refund-money math: totals, adjusted amountPaid and resulting payment status. */
  const computeRefundTotals = (order: Order, refundAmount: number) => {
    const totalRefund = (order.refundAmount || 0) + refundAmount;
    const newAmountPaid = Math.max(0, (order.amountPaid || 0) - refundAmount);
    const newPaymentStatus: PaymentStatus = newAmountPaid <= 0 ? 'refunded' : 'partial';
    return { totalRefund, newAmountPaid, newPaymentStatus };
  };

  /** Writes the cash transaction and account movement for a refund. */
  const writeRefundTransaction = (order: Order, refundAmount: number, accountId?: string) => {
    if (!accountId) return;
    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'refund',
      amount: refundAmount,
      fromAccountId: accountId,
      reference: order.orderNumber,
      description: `Customer refund for ${order.orderNumber}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [tx, ...prev]);
    setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance - refundAmount } : acc));
  };

  /** Restocks the given quantities via customer_return movements (product + variant stock). */
  const restockReturnedItems = (
    order: Order,
    items: Array<{ productId: string; variantId?: string; productName: string; quantity: number; unitCostSnapshot: number }>
  ) => {
    if (!settings.inventoryTracking || items.length === 0) return;
    items.forEach(item => {
      const prod = products.find(p => p.id === item.productId);
      if (prod) {
        const variant = item.variantId ? prod.variants.find(v => v.id === item.variantId) : undefined;
        const movement: InventoryMovement = {
          id: `mov-${Date.now()}-${Math.random()}`,
          productId: prod.id,
          productName: prod.name,
          variantId: item.variantId,
          variantName: variant?.name,
          date: new Date().toISOString(),
          type: 'customer_return',
          quantity: item.quantity,
          unitCost: item.unitCostSnapshot,
          balanceAfter: (variant ? variant.stock : prod.stock) + item.quantity,
          referenceId: order.orderNumber,
          notes: `Customer return restock for order ${order.orderNumber}`,
          createdBy: user.name
        };
        setMovements(prev => [movement, ...prev]);
      }
    });

    setProducts(prev => prev.map(p => {
      const matched = items.filter(i => i.productId === p.id);
      if (matched.length === 0) return p;
      const returned = matched.reduce((sum, i) => sum + i.quantity, 0);
      const variants = p.variants && p.variants.length > 0
        ? p.variants.map(v => {
            const vQty = matched.filter(i => i.variantId === v.id).reduce((sum, i) => sum + i.quantity, 0);
            return vQty ? { ...v, stock: v.stock + vQty } : v;
          })
        : p.variants;
      return { ...p, variants, stock: p.stock + returned };
    }));
  };

  // I13: partial refunds reduce amountPaid ('partial' unless fully refunded);
  // items are restocked ONLY on a full return (isFullReturn + nothing left paid).
  const refundOrder = (orderId: string, refundAmount: number, accountId?: string, isFullReturn: boolean = false) => {
    if (deny('orders.refund')) return;
    const target = orders.find(o => o.id === orderId);
    if (!target) return;

    const { totalRefund, newAmountPaid, newPaymentStatus } = computeRefundTotals(target, refundAmount);
    const isCompleteReturn = isFullReturn && newAmountPaid <= 0;

    // Restock items only on a full return with a full refund
    if (isCompleteReturn) {
      restockReturnedItems(target, target.items.map(i => ({
        productId: i.productId,
        variantId: i.variantId,
        productName: i.productName,
        quantity: i.quantity,
        unitCostSnapshot: i.unitCostSnapshot
      })));
    }

    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      refundAmount: totalRefund,
      amountPaid: newAmountPaid,
      paymentStatus: newPaymentStatus,
      orderStatus: isCompleteReturn ? 'returned' : o.orderStatus
    } : o));

    writeRefundTransaction(target, refundAmount, accountId);

    logAudit('Order Refunded', 'Order', `Refund of ${refundAmount} issued for ${target.orderNumber}`);
  };

  // A2: item-level sales returns. Restocks ONLY the returned quantities via
  // customer_return movements; money math is shared with refundOrder.
  const returnOrderItems = (orderId: string, lines: ReturnLineInput[], refundAmount: number, accountId?: string) => {
    if (deny('orders.refund')) return;
    const target = orders.find(o => o.id === orderId);
    if (!target) return;
    const validLines = lines.filter(l => l.quantity > 0);
    if (validLines.length === 0 || refundAmount < 0) return;

    // Validate against remaining (not-yet-returned) quantities
    for (const line of validLines) {
      const item = target.items.find(i =>
        i.productId === line.productId && (i.variantId || undefined) === (line.variantId || undefined));
      const remaining = item ? item.quantity - (item.returnedQuantity || 0) : 0;
      if (!item || line.quantity > remaining) {
        notify(
          'Return rejected',
          `Cannot return ${line.quantity} × "${item?.productName || line.productId}": only ${remaining} unit(s) available to return.`,
          'warning',
          'orders',
          'orders',
          'order_pending'
        );
        return;
      }
    }

    restockReturnedItems(target, validLines.map(l => {
      const item = target.items.find(i =>
        i.productId === l.productId && (i.variantId || undefined) === (l.variantId || undefined))!;
      return {
        productId: l.productId,
        variantId: l.variantId,
        productName: item.productName,
        quantity: l.quantity,
        unitCostSnapshot: item.unitCostSnapshot
      };
    }));

    const { totalRefund, newAmountPaid, newPaymentStatus } = computeRefundTotals(target, refundAmount);

    setOrders(prev => prev.map(o => {
      if (o.id !== orderId) return o;
      const updatedItems = o.items.map(item => {
        const line = validLines.find(l =>
          l.productId === item.productId && (l.variantId || undefined) === (item.variantId || undefined));
        return line ? { ...item, returnedQuantity: (item.returnedQuantity || 0) + line.quantity } : item;
      });
      const fullyReturned = updatedItems.every(item => (item.returnedQuantity || 0) >= item.quantity);
      return {
        ...o,
        items: updatedItems,
        refundAmount: totalRefund,
        amountPaid: newAmountPaid,
        paymentStatus: newPaymentStatus,
        orderStatus: fullyReturned ? 'returned' : o.orderStatus
      };
    }));

    writeRefundTransaction(target, refundAmount, accountId);

    const totalUnits = validLines.reduce((s, l) => s + l.quantity, 0);
    logAudit('Items Returned', 'Order', `Returned ${totalUnits} unit(s) from ${target.orderNumber}; refund ${refundAmount}`);
  };

  /** Explicit audit entry for UI flows (e.g. credit-limit overrides). Call only from already-gated flows. */
  const logAuditEvent = (action: string, entity: string, details: string) => {
    logAudit(action, entity, details);
  };


  // Product Actions
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt'>): Product | null => {
    if (deny('products.create')) return null;
    const newProd: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    setProducts(prev => [newProd, ...prev]);

    // Record initial stock movement if > 0
    if (newProd.stock > 0) {
      const movement: InventoryMovement = {
        id: `mov-${Date.now()}`,
        productId: newProd.id,
        productName: newProd.name,
        date: new Date().toISOString(),
        type: 'initial',
        quantity: newProd.stock,
        unitCost: newProd.costPrice,
        balanceAfter: newProd.stock,
        referenceId: 'INITIAL-STOCK',
        notes: 'Initial inventory balance setup',
        createdBy: user.name
      };
      setMovements(prev => [movement, ...prev]);
    }

    logAudit('Product Created', 'Product', `Added new product ${newProd.name} (SKU: ${newProd.sku})`);
    return newProd;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    if (deny('products.update')) return;
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    logAudit('Product Updated', 'Product', `Updated product details for ${id}`);
  };

  const archiveProduct = (id: string) => {
    if (deny('products.delete')) return;
    setProducts(prev => prev.map(p => p.id === id ? { ...p, status: 'archived' } : p));
    logAudit('Product Archived', 'Product', `Archived product ID ${id}`);
  };

  const bulkImportProducts = (newProducts: Array<Omit<Product, 'id' | 'createdAt'>>) => {
    if (deny('products.import')) return;
    const created: Product[] = newProducts.map((p, index) => ({
      ...p,
      id: `prod-${Date.now()}-${index}`,
      createdAt: new Date().toISOString()
    }));

    setProducts(prev => [...created, ...prev]);
    logAudit('Bulk Import', 'Product', `Imported ${created.length} products via CSV`);
  };

  // Stock Adjustment (I9: optional variantId adjusts that variant's stock too)
  const adjustStock = (
    productId: string, 
    quantityChange: number, 
    type: MovementType, 
    notes?: string, 
    unitCost?: number,
    variantId?: string
  ): boolean => {
    if (deny('inventory.adjust')) return false;
    const prod = products.find(p => p.id === productId);
    if (!prod) return false;

    const variant = variantId ? prod.variants.find(v => v.id === variantId) : undefined;
    if (variantId && !variant) return false;

    const baseStock = variant ? variant.stock : prod.stock;
    const newStock = baseStock + quantityChange;
    if (newStock < 0 && !settings.allowNegativeStock) {
      notify(
        'Adjustment rejected',
        `Stock cannot become negative (${newStock}). Current stock is ${baseStock}.`,
        'warning',
        'inventory',
        'inventory',
        'inventory_low'
      );
      return false;
    }

    const movement: InventoryMovement = {
      id: `mov-${Date.now()}`,
      productId: prod.id,
      productName: prod.name,
      variantId: variant?.id,
      variantName: variant?.name,
      date: new Date().toISOString(),
      type,
      quantity: quantityChange,
      unitCost: unitCost || prod.costPrice,
      balanceAfter: newStock,
      referenceId: `ADJ-${Date.now().toString().slice(-4)}`,
      notes: notes || `Manual stock adjustment (${type})`,
      createdBy: user.name
    };

    setMovements(prev => [movement, ...prev]);
    setProducts(prev => prev.map(p => {
      if (p.id !== productId) return p;
      if (variant) {
        return {
          ...p,
          variants: p.variants.map(v => v.id === variant.id ? { ...v, stock: newStock } : v)
        };
      }
      return { ...p, stock: newStock };
    }));
    logAudit('Stock Adjusted', 'Inventory', `${prod.name}${variant ? ` (${variant.name})` : ''} stock changed by ${quantityChange} (${type})`);
    return true;
  };

  // Purchase Orders Actions
  const addPurchaseOrder = (poData: Omit<PurchaseOrder, 'id' | 'poNumber' | 'createdAt'>): PurchaseOrder | null => {
    if (deny('purchase.create')) return null;
    const poNumber = `PO-2026-${String(purchaseOrders.length + 1).padStart(2, '0')}`;
    const newPO: PurchaseOrder = {
      ...poData,
      id: `po-${Date.now()}`,
      poNumber,
      createdAt: new Date().toISOString()
    };

    setPurchaseOrders(prev => [newPO, ...prev]);
    logAudit('Purchase Order Created', 'PurchaseOrder', `Created PO ${poNumber} for supplier ${newPO.supplierName}`);
    return newPO;
  };

  const updatePurchaseOrderStatus = (poId: string, status: PurchaseOrder['status']) => {
    if (deny('purchase.create')) return;
    setPurchaseOrders(prev => prev.map(po => po.id === poId ? { ...po, status } : po));
    logAudit('PO Status Updated', 'PurchaseOrder', `PO ${poId} status changed to ${status}`);
  };

  // Goods Receipt from Purchase Order (Increases stock and records movement)
  // I9: when an item carries a variantId (or variantId is passed), the variant's
  // stock is increased alongside the product stock.
  const receivePurchaseOrder = (poId: string, variantId?: string) => {
    if (deny('inventory.receive')) return;
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;

    po.items.forEach(item => {
      const unreceivedQty = item.quantityOrdered - item.quantityReceived;
      if (unreceivedQty > 0) {
        const prod = products.find(p => p.id === item.productId);
        if (prod) {
          const itemVariantId = item.variantId || variantId;
          const variant = itemVariantId ? prod.variants.find(v => v.id === itemVariantId) : undefined;
          const newStock = prod.stock + unreceivedQty;
          const movement: InventoryMovement = {
            id: `mov-${Date.now()}-${Math.random()}`,
            productId: prod.id,
            productName: prod.name,
            variantId: variant?.id,
            variantName: variant?.name,
            date: new Date().toISOString(),
            type: 'purchase_receipt',
            quantity: unreceivedQty,
            unitCost: item.unitCost,
            balanceAfter: newStock,
            referenceId: po.poNumber,
            notes: `Received from supplier ${po.supplierName} under ${po.poNumber}`,
            createdBy: user.name
          };
          setMovements(prev => [movement, ...prev]);
          setProducts(prev => prev.map(p => {
            if (p.id !== prod.id) return p;
            const variants = variant
              ? p.variants.map(v => v.id === variant.id ? { ...v, stock: v.stock + unreceivedQty } : v)
              : p.variants;
            return { ...p, variants, stock: newStock };
          }));
        }
      }
    });

    setPurchaseOrders(prev => prev.map(p => p.id === poId ? {
      ...p,
      status: 'received',
      items: p.items.map(i => ({ ...i, quantityReceived: i.quantityOrdered }))
    } : p));

    logAudit('Goods Received', 'PurchaseOrder', `Goods received and stocked for PO ${po.poNumber}`);
  };

  const recordPOPayment = (poId: string, amount: number, accountId: string) => {
    if (deny('accounts.transfer')) return;
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;

    const newAmountPaid = po.amountPaid + amount;
    const newPaymentStatus: PaymentStatus = newAmountPaid >= po.totalAmount ? 'paid' : 'partial';

    setPurchaseOrders(prev => prev.map(p => p.id === poId ? {
      ...p,
      amountPaid: newAmountPaid,
      paymentStatus: newPaymentStatus
    } : p));

    // Cash transaction (deduct from account)
    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'supplier_payment',
      amount,
      fromAccountId: accountId,
      reference: po.poNumber,
      description: `Payment to ${po.supplierName} for ${po.poNumber}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };
    setTransactions(prev => [tx, ...prev]);

    setAccounts(prev => prev.map(acc => acc.id === accountId ? { ...acc, balance: acc.balance - amount } : acc));
    logAudit('Supplier Paid', 'PurchaseOrder', `Paid ${amount} to supplier for PO ${po.poNumber}`);
  };

  // Expense Actions
  /** Ungated core of expense creation — shared by addExpense and the recurring engine (B1). */
  const persistExpense = (expenseData: Omit<Expense, 'id' | 'createdAt'>): Expense => {
    const newExp: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      createdAt: new Date().toISOString()
    };

    setExpenses(prev => [newExp, ...prev]);

    // If an account was chosen, deduct balance and record transaction
    if (newExp.accountId) {
      const tx: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: newExp.date,
        type: 'expense',
        amount: newExp.amount,
        fromAccountId: newExp.accountId,
        reference: `EXP-${newExp.category.slice(0, 3).toUpperCase()}`,
        description: `${newExp.category}: ${newExp.description}`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [tx, ...prev]);
      setAccounts(prev => prev.map(acc => acc.id === newExp.accountId ? { ...acc, balance: acc.balance - newExp.amount } : acc));
    }

    return newExp;
  };

  const addExpense = (expenseData: Omit<Expense, 'id' | 'createdAt'>): Expense | null => {
    if (deny('expenses.create')) return null;
    const newExp = persistExpense(expenseData);
    logAudit('Expense Recorded', 'Expense', `Recorded expense of ${newExp.amount} for ${newExp.category}`);
    return newExp;
  };

  // I2: deleting an expense reverses its cash movement instead of silently
  // dropping it — the account balance is restored and an offsetting
  // transaction is written so the ledger stays balanced.
  const deleteExpense = (id: string) => {
    if (deny('expenses.delete')) return;
    const target = expenses.find(e => e.id === id);
    if (!target) return;

    if (target.accountId) {
      const reversal: CashTransaction = {
        id: `tx-${Date.now()}`,
        date: new Date().toISOString(),
        type: 'expense',
        amount: target.amount,
        toAccountId: target.accountId,
        reference: `REV-${target.category.slice(0, 3).toUpperCase()}`,
        description: `Reversal of deleted expense: ${target.category} — ${target.description}`,
        isReconciled: true,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [reversal, ...prev]);
      setAccounts(prev => prev.map(acc =>
        acc.id === target.accountId ? { ...acc, balance: acc.balance + target.amount } : acc
      ));
    }

    setExpenses(prev => prev.filter(e => e.id !== id));
    logAudit('Expense Deleted', 'Expense', `Deleted expense "${target.description}" (${target.amount}); cash movement reversed`);
  };

  // Customers & Suppliers
  const addCustomer = (customerData: Omit<Customer, 'id' | 'createdAt'>): Customer | null => {
    if (deny('customers.manage')) return null;
    const newCust: Customer = {
      ...customerData,
      id: `cust-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setCustomers(prev => [newCust, ...prev]);
    logAudit('Customer Created', 'Customer', `Added customer ${newCust.name}`);
    return newCust;
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    if (deny('customers.manage')) return;
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const addSupplier = (supplierData: Omit<Supplier, 'id' | 'createdAt'>): Supplier | null => {
    if (deny('suppliers.manage')) return null;
    const newSup: Supplier = {
      ...supplierData,
      id: `sup-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setSuppliers(prev => [newSup, ...prev]);
    logAudit('Supplier Created', 'Supplier', `Added supplier ${newSup.name}`);
    return newSup;
  };

  const updateSupplier = (id: string, updates: Partial<Supplier>) => {
    if (deny('suppliers.manage')) return;
    setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  // Financial Accounts & Transfers
  const addAccount = (accData: Omit<FinancialAccount, 'id'>): FinancialAccount | null => {
    if (deny('accounts.manage')) return null;
    const newAcc: FinancialAccount = {
      ...accData,
      id: `acc-${Date.now()}`
    };
    setAccounts(prev => [...prev, newAcc]);
    logAudit('Account Added', 'FinancialAccount', `Created account ${newAcc.name}`);
    return newAcc;
  };

  const transferFunds = (
    fromAccountId: string, 
    toAccountId: string, 
    amount: number, 
    fee: number = 0, 
    description?: string
  ): boolean => {
    if (deny('accounts.transfer')) return false;
    if (fromAccountId === toAccountId) {
      notify(
        'Transfer rejected',
        'Sender and receiver account cannot be the same.',
        'warning',
        'financial',
        'payments',
        'payment_due'
      );
      return false;
    }

    const fromAcc = accounts.find(a => a.id === fromAccountId);
    const toAcc = accounts.find(a => a.id === toAccountId);

    if (!fromAcc || !toAcc) return false;

    if (fromAcc.balance < amount + fee) {
      notify(
        'Transfer rejected: insufficient funds',
        `Insufficient funds in ${fromAcc.name}. Available: ${fromAcc.balance}, Required: ${amount + fee}.`,
        'warning',
        'financial',
        'payments',
        'payment_due'
      );
      return false;
    }

    // Double-entry transfer: decreases fromAcc, increases toAcc (P&L neutral!)
    setAccounts(prev => prev.map(acc => {
      if (acc.id === fromAccountId) {
        return { ...acc, balance: acc.balance - (amount + fee) };
      }
      if (acc.id === toAccountId) {
        return { ...acc, balance: acc.balance + amount };
      }
      return acc;
    }));

    const tx: CashTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'transfer',
      amount,
      fee,
      fromAccountId,
      toAccountId,
      reference: `TRF-${fromAcc.name.slice(0, 3)}-${toAcc.name.slice(0, 3)}`,
      description: description || `Internal transfer from ${fromAcc.name} to ${toAcc.name}`,
      isReconciled: true,
      createdAt: new Date().toISOString()
    };

    setTransactions(prev => [tx, ...prev]);
    logAudit('Funds Transferred', 'CashLedger', `Transferred ${amount} from ${fromAcc.name} to ${toAcc.name}`);
    return true;
  };

  const reconcileTransaction = (txId: string) => {
    if (deny('accounts.manage')) return;
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, isReconciled: !t.isReconciled } : t));
  };

  // Reset & Backup
  /** Wipes all business data for a clean start (onboarding "Start fresh"). Keeps auth/users intact. */
  const clearAllData = () => {
    if (deny('data.reset')) return;
    setSettings({ ...INITIAL_SETTINGS, onboardingCompleted: true });
    setProducts([]);
    setCustomers([]);
    setSuppliers([]);
    setOrders([]);
    setPurchaseOrders([]);
    setExpenses([]);
    setAccounts([]);
    setTransactions([]);
    setMovements([]);
    setAuditLogs([
      {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        user: user.name,
        action: 'Fresh Start',
        entity: 'System',
        details: 'All business data cleared during onboarding — starting with empty shelves'
      }
    ]);
  };

  const resetToSampleData = () => {
    if (deny('data.reset')) return;
    setUser(INITIAL_USER);
    setSettings(INITIAL_SETTINGS);
    setProducts(INITIAL_PRODUCTS);
    setCustomers(INITIAL_CUSTOMERS);
    setSuppliers(INITIAL_SUPPLIERS);
    setOrders(INITIAL_ORDERS);
    setPurchaseOrders(INITIAL_PURCHASE_ORDERS);
    setExpenses(INITIAL_EXPENSES);
    setAccounts(INITIAL_ACCOUNTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setMovements(INITIAL_MOVEMENTS);
    setAuditLogs([
      {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        user: INITIAL_USER.name,
        action: 'Database Reset',
        entity: 'System',
        details: 'All modules restored to standard verified sample store dataset'
      }
    ]);
  };

  // I11: REAL encrypted backup (AES-GCM, password-derived key). The old
  // plaintext "encrypted JSON" claim is gone — this actually encrypts.
  const BACKUP_FORMAT = 'microbiz-backup-encrypted';
  const BACKUP_VERSION = 2;

  const exportEncryptedBackup = async (password: string): Promise<string> => {
    if (deny('backup.export')) throw new Error('Permission denied: backup.export');
    if (!password || password.length < 8) {
      throw new Error('Backup password must be at least 8 characters long.');
    }
    const backup = {
      format: 'microbiz-backup',
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      exportedBy: user.name,
      data: {
        settings,
        products,
        customers,
        suppliers,
        orders,
        purchaseOrders,
        expenses,
        accounts,
        transactions,
        movements,
        auditLogs,
        users: getBackupUsers()
      }
    };
    const ciphertext = await encryptWithPassword(JSON.stringify(backup), password);
    return JSON.stringify({ format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: backup.exportedAt, payload: ciphertext });
  };

  // Validates the FULL schema before touching any state — rejects with a
  // clear error instead of partially overwriting on mismatch.
  const importEncryptedBackup = async (password: string, payload: string): Promise<{ success: boolean; error?: string }> => {
    if (deny('backup.import')) return { success: false, error: 'Permission denied.' };
    let outer: { format?: string; version?: number; payload?: string };
    try {
      outer = JSON.parse(payload);
    } catch {
      return { success: false, error: 'Not a valid backup file (unparseable JSON).' };
    }
    if (outer.format !== BACKUP_FORMAT || outer.version !== BACKUP_VERSION || typeof outer.payload !== 'string') {
      return { success: false, error: `Unsupported backup format (expected ${BACKUP_FORMAT} v${BACKUP_VERSION}).` };
    }

    let inner: {
      format?: string;
      version?: number;
      data?: {
        settings?: unknown; products?: unknown; customers?: unknown; suppliers?: unknown;
        orders?: unknown; purchaseOrders?: unknown; expenses?: unknown; accounts?: unknown;
        transactions?: unknown; movements?: unknown; auditLogs?: unknown; users?: unknown;
      };
    };
    try {
      const decrypted = await decryptWithPassword(outer.payload, password);
      inner = JSON.parse(decrypted);
    } catch {
      return { success: false, error: 'Wrong password or corrupted backup file.' };
    }

    if (inner.format !== 'microbiz-backup' || inner.version !== BACKUP_VERSION || !inner.data) {
      return { success: false, error: 'Backup payload failed schema validation.' };
    }
    const d = inner.data;
    const isObj = (v: unknown) => typeof v === 'object' && v !== null;
    const requiredArrays: Array<[string, unknown]> = [
      ['products', d.products], ['customers', d.customers], ['suppliers', d.suppliers],
      ['orders', d.orders], ['purchaseOrders', d.purchaseOrders], ['expenses', d.expenses],
      ['accounts', d.accounts], ['transactions', d.transactions], ['movements', d.movements],
      ['auditLogs', d.auditLogs], ['users', d.users]
    ];
    for (const [name, value] of requiredArrays) {
      if (!Array.isArray(value)) {
        return { success: false, error: `Backup schema mismatch: "${name}" must be an array.` };
      }
    }
    if (!isObj(d.settings)) {
      return { success: false, error: 'Backup schema mismatch: "settings" must be an object.' };
    }

    // Users restore is validated inside the auth layer; sessions are dropped.
    const usersResult = restoreBackupUsers(d.users);
    if (!usersResult.success) {
      return { success: false, error: usersResult.error || 'User restore failed.' };
    }

    // All validation passed — now apply atomically
    setSettings(d.settings as BusinessSettings);
    setProducts(d.products as Product[]);
    setCustomers(d.customers as Customer[]);
    setSuppliers(d.suppliers as Supplier[]);
    setOrders(d.orders as Order[]);
    setPurchaseOrders(d.purchaseOrders as PurchaseOrder[]);
    setExpenses(d.expenses as Expense[]);
    setAccounts(d.accounts as FinancialAccount[]);
    setTransactions(d.transactions as CashTransaction[]);
    setMovements(d.movements as InventoryMovement[]);
    setAuditLogs(d.auditLogs as AuditLog[]);
    logAudit('Backup Restored', 'System', 'Data successfully restored from encrypted backup (schema v2 validated)');
    return { success: true };
  };

  // B1: recurring-expense engine — runs once per app load. For every recurring
  // template, generates the instances due up to today (tracked via
  // lastGeneratedDate so nothing is ever duplicated), then notifies once.
  const recurringBootstrapped = useRef(false);
  useEffect(() => {
    if (recurringBootstrapped.current) return;
    recurringBootstrapped.current = true;
    const { instances, templateUpdates } = generateDueRecurringInstances(expenses, new Date());
    if (instances.length === 0) return;
    instances.forEach(data => persistExpense(data));
    setExpenses(prev => prev.map(e => {
      const upd = templateUpdates.find(u => u.id === e.id);
      return upd ? { ...e, lastGeneratedDate: upd.lastGeneratedDate } : e;
    }));
    logAudit('Recurring Expenses Generated', 'Expense', `Auto-generated ${instances.length} recurring expense instance(s) due to date`);
    notify(
      'Recurring expenses posted',
      `${instances.length} recurring expense${instances.length === 1 ? '' : 's'} due since your last visit ${instances.length === 1 ? 'was' : 'were'} automatically posted to your books.`,
      'info',
      'financial',
      'expenses',
      'system_update'
    );
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        settings,
        products,
        customers,
        suppliers,
        orders,
        purchaseOrders,
        expenses,
        accounts,
        transactions,
        movements,
        auditLogs,
        darkMode,
        toggleDarkMode,
        setUserRole,
        updateSettings,
        addOrder,
        updateOrder,
        updateOrderStatus,
        recordOrderPayment,
        refundOrder,
        returnOrderItems,
        logAuditEvent,
        addProduct,
        updateProduct,
        archiveProduct,
        bulkImportProducts,
        adjustStock,
        addPurchaseOrder,
        updatePurchaseOrderStatus,
        receivePurchaseOrder,
        recordPOPayment,
        addExpense,
        deleteExpense,
        addCustomer,
        updateCustomer,
        addSupplier,
        updateSupplier,
        addAccount,
        transferFunds,
        reconcileTransaction,
        resetToSampleData,
        clearAllData,
        exportEncryptedBackup,
        importEncryptedBackup
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
