import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AuthUser, UserSession, PasswordResetRecord, TwoFactorSetupData, MockEmailNotice } from '../types/auth';
import { UserRole } from '../types';
import { 
  generateSalt, 
  hashPassword, 
  verifyPassword, 
  generateRandomToken, 
  generateSixDigitCode, 
  generateBase32Secret, 
  generateOtpauthUri, 
  generateBackupCodes, 
  generateTempPassword,
  verifyTotpCode, 
  detectClientEnvironment,
  deriveAesKey,
  encryptWithExistingKey,
  decryptWithKey,
  decryptWithPassword,
  extractPayloadSalt,
  u8ToB64,
  b64ToU8
} from '../utils/cryptoAuth';

/** Actions gated by role-based access control (I10). */
export type PermissionAction =
  | 'orders.create' | 'orders.update' | 'orders.payment' | 'orders.refund'
  | 'products.create' | 'products.update' | 'products.delete' | 'products.import'
  | 'inventory.adjust' | 'inventory.receive' | 'purchase.create'
  | 'expenses.create' | 'expenses.delete'
  | 'customers.manage' | 'suppliers.manage'
  | 'accounts.manage' | 'accounts.transfer'
  | 'settings.update'
  | 'users.manage'
  | 'reports.view' | 'reports.export'
  | 'backup.export' | 'backup.import' | 'data.reset';

const ALL_ACTIONS: PermissionAction[] = [
  'orders.create', 'orders.update', 'orders.payment', 'orders.refund',
  'products.create', 'products.update', 'products.delete', 'products.import',
  'inventory.adjust', 'inventory.receive', 'purchase.create',
  'expenses.create', 'expenses.delete',
  'customers.manage', 'suppliers.manage',
  'accounts.manage', 'accounts.transfer',
  'settings.update',
  'users.manage',
  'reports.view', 'reports.export',
  'backup.export', 'backup.import', 'data.reset'
];

const ROLE_PERMISSIONS: Record<UserRole, PermissionAction[]> = {
  owner: [...ALL_ACTIONS],
  admin: ALL_ACTIONS.filter(a => !['settings.update', 'backup.import', 'data.reset', 'users.manage'].includes(a)),
  sales: ['orders.create', 'orders.update', 'orders.payment', 'orders.refund', 'customers.manage', 'reports.view', 'reports.export'],
  inventory: ['products.create', 'products.update', 'inventory.adjust', 'inventory.receive', 'purchase.create', 'suppliers.manage', 'reports.view'],
  accountant: ['expenses.create', 'expenses.delete', 'accounts.manage', 'accounts.transfer', 'orders.payment', 'reports.view', 'reports.export', 'backup.export'],
  viewer: ['reports.view']
};

/**
 * In-memory vault for decrypted 2FA secrets. Module-level (never in React
 * state, never persisted): populated only after a successful password login,
 * cleared on logout. This keeps TOTP secrets / backup codes out of localStorage.
 */
interface VaultEntry {
  secret: string;          // Base32 TOTP secret
  backupCodes: string[];   // Remaining one-time codes
  key: CryptoKey;          // Password-derived AES-GCM key (same salt as payloads)
  saltB64: string;         // Salt embedded in the stored payloads
}
const vaultCache = new Map<string, VaultEntry>();

interface AuthContextType {
  currentUser: AuthUser | null;
  currentSession: UserSession | null;
  allSessions: UserSession[];
  isAuthenticated: boolean;
  isEmailVerified: boolean;
  twoFactorPending: { user: AuthUser; rememberMe: boolean } | null;
  mockEmailNotices: MockEmailNotice[];
  latestEmailNotice: MockEmailNotice | null;
  
  // UI Dialog states
  isAuthModalOpen: boolean;
  authModalView: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor';
  isSecuritySettingsOpen: boolean;
  openAuthModal: (view?: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor') => void;
  closeAuthModal: () => void;
  openSecuritySettings: () => void;
  closeSecuritySettings: () => void;
  dismissEmailNotice: (id: string) => void;

  // Authentication actions
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; requires2FA?: boolean; error?: string }>;
  verify2FALogin: (code: string) => Promise<{ success: boolean; error?: string }>;
  cancel2FALogin: () => void;
  logout: () => void;
  /** Central RBAC check: does the signed-in user hold this permission? */
  can: (action: PermissionAction) => boolean;
  
  // Session management
  logoutOtherSessions: () => void;
  revokeSession: (sessionId: string) => void;
  
  // Password reset
  requestPasswordReset: (email: string) => Promise<{ success: boolean; error?: string; code?: string }>;
  resetPassword: (codeOrToken: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  
  // Email verification
  sendVerificationEmail: () => Promise<{ success: boolean; code?: string }>;
  verifyEmail: (code: string) => Promise<{ success: boolean; error?: string }>;
  
  // Two-Factor Authentication
  start2FASetup: () => TwoFactorSetupData;
  confirmEnable2FA: (secret: string, candidateCode: string, backupCodes: string[], password: string) => Promise<{ success: boolean; error?: string }>;
  disable2FA: (currentPassword: string) => Promise<{ success: boolean; error?: string }>;
  /** Password-gated reveal of backup codes (never displayed without re-authentication). */
  revealBackupCodes: (password: string) => Promise<{ success: boolean; codes?: string[]; error?: string }>;
  
  // Password change & Account deletion
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  deleteAccount: (currentPassword: string) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<Pick<AuthUser, 'name' | 'avatar'>>) => void;

  // Team management (owner-only, shared-device staff accounts)
  /** All registered users — used by the owner-only Team view. */
  allUsers: AuthUser[];
  /** True when the signed-in user must set a new password before using the app. */
  mustChangePasswordNow: boolean;
  updateUserRole: (userId: string, role: UserRole) => Promise<{ success: boolean; error?: string }>;
  setUserActive: (userId: string, active: boolean) => Promise<{ success: boolean; error?: string }>;
  adminResetPassword: (userId: string) => Promise<{ success: boolean; tempPassword?: string; error?: string }>;
  createUser: (name: string, email: string, password: string, role: UserRole) => Promise<{ success: boolean; error?: string }>;

  // Backup / restore of auth users (used by encrypted database backup)
  getBackupUsers: () => AuthUser[];
  restoreBackupUsers: (data: unknown) => { success: boolean; error?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_USERS = 'microbiz_auth_users';
const AUTH_STORAGE_SESSIONS = 'microbiz_auth_sessions';
const AUTH_STORAGE_CURRENT_TOKEN = 'microbiz_auth_current_token';
const AUTH_STORAGE_RESETS = 'microbiz_auth_resets';
const AUTH_STORAGE_NOTICES = 'microbiz_auth_notices';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Registered users database (no demo seed — first registered user becomes owner)
  const [users, setUsers] = useState<AuthUser[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_USERS);
      if (saved) {
        const parsed = JSON.parse(saved) as AuthUser[];
        // Migration: strip any legacy PLAINTEXT 2FA fields. They cannot be
        // migrated securely, so affected accounts must re-enroll 2FA.
        return parsed.map((u) => {
          const raw = u as unknown as Record<string, unknown>;
          delete raw['twoFactorSecret'];
          delete raw['twoFactorBackupCodes'];
          // Normalize: legacy records lack isActive — undefined counts as active.
          const normalized = { ...u, isActive: u.isActive !== false };
          if (u.twoFactorEnabled && !u.twoFactorSecretEnc) {
            return { ...normalized, twoFactorEnabled: false };
          }
          return normalized;
        });
      }
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Active sessions table
  const [sessions, setSessions] = useState<UserSession[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_SESSIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Current session token
  const [currentToken, setCurrentToken] = useState<string | null>(() => {
    return localStorage.getItem(AUTH_STORAGE_CURRENT_TOKEN);
  });

  // Password reset records
  const [resetRecords, setResetRecords] = useState<PasswordResetRecord[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_RESETS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Mock emails / notifications for testing verification & password resets
  const [mockNotices, setMockNotices] = useState<MockEmailNotice[]>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_NOTICES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // UI Modal states
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor'>('login');
  const [isSecuritySettingsOpen, setIsSecuritySettingsOpen] = useState(false);
  const [twoFactorPending, setTwoFactorPending] = useState<{ user: AuthUser; rememberMe: boolean } | null>(null);

  // Sync users to storage
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_USERS, JSON.stringify(users));
  }, [users]);

  // Sync sessions to storage
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_SESSIONS, JSON.stringify(sessions));
  }, [sessions]);

  // Sync current token to storage
  useEffect(() => {
    if (currentToken) {
      localStorage.setItem(AUTH_STORAGE_CURRENT_TOKEN, currentToken);
    } else {
      localStorage.removeItem(AUTH_STORAGE_CURRENT_TOKEN);
    }
  }, [currentToken]);

  // Sync reset records
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_RESETS, JSON.stringify(resetRecords));
  }, [resetRecords]);

  // Sync mock notices
  useEffect(() => {
    localStorage.setItem(AUTH_STORAGE_NOTICES, JSON.stringify(mockNotices));
  }, [mockNotices]);

  // Resolve current session and user — expired sessions are rejected (C3)
  const currentSession = sessions.find(
    s => s.token === currentToken && new Date(s.expiresAt).getTime() > Date.now()
  ) || null;
  const currentUser = currentSession ? (users.find(u => u.id === currentSession.userId) || null) : null;
  const isAuthenticated = !!currentUser && !!currentSession;
  const isEmailVerified = currentUser?.isEmailVerified || false;
  /** Forced password-change gate: set by owner-issued temp passwords. */
  const mustChangePasswordNow = isAuthenticated && currentUser?.mustChangePassword === true;

  // Prune expired sessions on load so stale tokens never linger
  useEffect(() => {
    const now = Date.now();
    setSessions(prev => {
      const alive = prev.filter(s => new Date(s.expiresAt).getTime() > now);
      return alive.length === prev.length ? prev : alive;
    });
  }, []);

  // If the current token's session expired, drop it (and the token) immediately
  useEffect(() => {
    if (!currentToken) return;
    const sess = sessions.find(s => s.token === currentToken);
    if (sess && new Date(sess.expiresAt).getTime() <= Date.now()) {
      vaultCache.delete(sess.userId);
      setSessions(prev => prev.filter(s => s.token !== currentToken));
      setCurrentToken(null);
    }
  }, [currentToken, sessions]);

  // Format all sessions for current user
  const userSessions = sessions
    .filter(s => s.userId === currentUser?.id)
    .map(s => ({ ...s, isCurrent: s.token === currentToken }));

  // Helper to append a mock email notice (for user visibility)
  const addEmailNotice = (notice: Omit<MockEmailNotice, 'id' | 'timestamp'>) => {
    const newNotice: MockEmailNotice = {
      ...notice,
      id: `notice-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    setMockNotices(prev => [newNotice, ...prev.slice(0, 19)]);
  };

  const dismissEmailNotice = (id: string) => {
    setMockNotices(prev => prev.filter(n => n.id !== id));
  };

  const latestEmailNotice = mockNotices.length > 0 ? mockNotices[0] : null;

  // NOTE: no silent auto-login. Unauthenticated users are gated to the
  // auth screen by App.tsx; a session is created only via login/register.

  // Central RBAC check (I10). Owner holds every permission.
  const can = (action: PermissionAction): boolean => {
    const role = currentUser?.role;
    if (!role) return false;
    return ROLE_PERMISSIONS[role].includes(action);
  };

  // UI Modal helpers
  const openAuthModal = (view: 'login' | 'register' | 'forgot_password' | 'reset_password' | 'verify_email' | 'two_factor' = 'login') => {
    setAuthModalView(view);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openSecuritySettings = () => {
    setIsSecuritySettingsOpen(true);
  };

  const closeSecuritySettings = () => {
    setIsSecuritySettingsOpen(false);
  };

  // 1. Email Registration — the first-ever user becomes owner; everyone
  // else registers as viewer (roles are granted by an owner afterwards).
  const register = async (
    name: string, 
    email: string, 
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !password || !name) {
      return { success: false, error: 'Please provide all required fields.' };
    }

    if (password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    // Check if email already exists
    if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, error: 'An account with this email address already exists.' };
    }

    // Cryptographic salt and PBKDF2 hash
    const salt = generateSalt(16);
    const hash = await hashPassword(password, salt);

    // Generate 6-digit email verification code
    const verificationCode = generateSixDigitCode();
    const verificationExpiry = Date.now() + 24 * 60 * 60 * 1000; // 24 hours

    // RBAC: no self-assigned roles — first user is owner, the rest are viewers
    const assignedRole: UserRole = users.length === 0 ? 'owner' : 'viewer';

    const newUser: AuthUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: normalizedEmail,
      role: assignedRole,
      avatar: name.trim().split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2),
      passwordSalt: salt,
      passwordHash: hash,
      isEmailVerified: false,
      emailVerificationCode: verificationCode,
      emailVerificationExpiresAt: verificationExpiry,
      twoFactorEnabled: false,
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setUsers(prev => [newUser, ...prev]);

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: newUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);

    // Send mock verification notice
    addEmailNotice({
      type: 'verification',
      toEmail: normalizedEmail,
      subject: `Verify your MicroBiz Manager account: ${verificationCode}`,
      code: verificationCode
    });

    closeAuthModal();
    return { success: true };
  };

  // 2. Login
  const login = async (
    email: string, 
    password: string, 
    rememberMe: boolean = true
  ): Promise<{ success: boolean; requires2FA?: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const targetUser = users.find(u => u.email.toLowerCase() === normalizedEmail);

    if (!targetUser) {
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Verify password against PBKDF2 hash and salt
    const isPasswordCorrect = await verifyPassword(password, targetUser.passwordSalt, targetUser.passwordHash);

    if (!isPasswordCorrect) {
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Deactivated accounts cannot sign in. Checked after the password so we
    // don't reveal which email addresses exist.
    if (targetUser.isActive === false) {
      return { success: false, error: 'This account has been deactivated. Please contact your business owner.' };
    }

    // Populate the in-memory 2FA vault now that the password is verified.
    // Secrets stay encrypted at rest; only this session's memory holds them.
    if (targetUser.twoFactorEnabled && targetUser.twoFactorSecretEnc) {
      try {
        const saltB64 = extractPayloadSalt(targetUser.twoFactorSecretEnc);
        const key = await deriveAesKey(password, b64ToU8(saltB64));
        const secret = await decryptWithKey(targetUser.twoFactorSecretEnc, key);
        const codesJson = targetUser.twoFactorBackupCodesEnc
          ? await decryptWithKey(targetUser.twoFactorBackupCodesEnc, key)
          : '[]';
        vaultCache.set(targetUser.id, {
          secret,
          backupCodes: JSON.parse(codesJson) as string[],
          key,
          saltB64
        });
      } catch (e) {
        console.error('2FA vault decryption failed:', e);
        return { success: false, error: 'Security data is corrupted. Reset your password to re-enroll 2FA.' };
      }
    }

    // Check if Two-Factor Authentication is enabled
    if (targetUser.twoFactorEnabled) {
      setTwoFactorPending({ user: targetUser, rememberMe });
      setAuthModalView('two_factor');
      return { success: true, requires2FA: true };
    }

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const durationDays = rememberMe ? 30 : 1;
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    closeAuthModal();
    return { success: true, requires2FA: false };
  };

  // 3. Verify 2FA Login
  const verify2FALogin = async (code: string): Promise<{ success: boolean; error?: string }> => {
    if (!twoFactorPending) {
      return { success: false, error: 'No active two-factor challenge found.' };
    }

    const { user: targetUser, rememberMe } = twoFactorPending;
    const cleanCode = code.trim().toUpperCase();

    // Re-check: the account may have been deactivated mid-challenge.
    const freshTarget = users.find(u => u.id === targetUser.id);
    if (freshTarget?.isActive === false) {
      setTwoFactorPending(null);
      setAuthModalView('login');
      return { success: false, error: 'This account has been deactivated. Please contact your business owner.' };
    }

    // Secrets live only in the in-memory vault (populated at password login)
    const vault = vaultCache.get(targetUser.id);
    if (!vault) {
      return { success: false, error: 'Two-factor session expired. Please sign in again.' };
    }

    // Check TOTP code against the vault secret
    const isTotpValid = await verifyTotpCode(vault.secret, cleanCode);

    // Check backup recovery codes (single-use: consumed codes are re-encrypted)
    let isBackupCodeValid = false;
    if (!isTotpValid && vault.backupCodes.length > 0) {
      const backupIndex = vault.backupCodes.findIndex(bc => bc.toUpperCase() === cleanCode);
      if (backupIndex !== -1) {
        isBackupCodeValid = true;
        vault.backupCodes.splice(backupIndex, 1);
        const reEnc = await encryptWithExistingKey(JSON.stringify(vault.backupCodes), vault.key, vault.saltB64);
        setUsers(prev => prev.map(u => u.id === targetUser.id ? { ...u, twoFactorBackupCodesEnc: reEnc } : u));
      }
    }

    if (!isTotpValid && !isBackupCodeValid) {
      return { success: false, error: 'Invalid authentication code. Please check your authenticator app.' };
    }

    // Create session
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const durationDays = rememberMe ? 30 : 1;
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    setTwoFactorPending(null);
    closeAuthModal();
    return { success: true };
  };

  const cancel2FALogin = () => {
    setTwoFactorPending(null);
    setAuthModalView('login');
  };

  // 4. Logout
  const logout = () => {
    if (currentToken) {
      const sess = sessions.find(s => s.token === currentToken);
      if (sess) vaultCache.delete(sess.userId);
      setSessions(prev => prev.filter(s => s.token !== currentToken));
      setCurrentToken(null);
    }
    openAuthModal('login');
  };

  // 5. Session Management: Terminate other sessions
  const logoutOtherSessions = () => {
    if (!currentToken) return;
    setSessions(prev => prev.filter(s => s.token === currentToken));
  };

  const revokeSession = (sessionId: string) => {
    const targetSession = sessions.find(s => s.id === sessionId);
    if (!targetSession) return;

    if (targetSession.token === currentToken) {
      logout();
    } else {
      setSessions(prev => prev.filter(s => s.id !== sessionId));
    }
  };

  // 6. Password Reset: Request
  const requestPasswordReset = async (email: string): Promise<{ success: boolean; error?: string; code?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const targetUser = users.find(u => u.email.toLowerCase() === normalizedEmail);

    if (!targetUser) {
      // Return generic success to prevent email enumeration attacks
      return { success: true };
    }

    const code = generateSixDigitCode();
    const token = generateRandomToken();
    const expiresAt = Date.now() + 60 * 60 * 1000; // 1 hour

    const record: PasswordResetRecord = {
      email: normalizedEmail,
      token,
      code,
      expiresAt
    };

    setResetRecords(prev => [record, ...prev.filter(r => r.email !== normalizedEmail)]);

    // Send mock notification
    addEmailNotice({
      type: 'password_reset',
      toEmail: normalizedEmail,
      subject: `Reset your MicroBiz Manager password: Code ${code}`,
      code,
      token
    });

    return { success: true, code };
  };

  // 7. Password Reset: Complete
  const resetPassword = async (codeOrToken: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (newPassword.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    const cleanInput = codeOrToken.trim();
    const record = resetRecords.find(r => 
      (r.code === cleanInput || r.token === cleanInput) && r.expiresAt > Date.now()
    );

    if (!record) {
      return { success: false, error: 'Invalid or expired password reset code. Please request a new one.' };
    }

    const targetUser = users.find(u => u.email.toLowerCase() === record.email.toLowerCase());
    if (!targetUser) {
      return { success: false, error: 'User account not found.' };
    }

    // Re-hash with fresh salt
    const newSalt = generateSalt(16);
    const newHash = await hashPassword(newPassword, newSalt);

    setUsers(prev => prev.map(u => u.id === targetUser.id ? {
      ...u,
      passwordSalt: newSalt,
      passwordHash: newHash,
      // 2FA secrets were encrypted with the OLD password and are now
      // unrecoverable — disable 2FA so the account is not locked out.
      // The email reset code served as the second factor for this reset.
      twoFactorEnabled: false,
      twoFactorSecretEnc: undefined,
      twoFactorBackupCodesEnc: undefined,
      mustChangePassword: false,
      updatedAt: new Date().toISOString()
    } : u));
    vaultCache.delete(targetUser.id);

    // Clear reset records for this email
    setResetRecords(prev => prev.filter(r => r.email !== record.email));

    // Invalidate all existing sessions for security
    setSessions(prev => prev.filter(s => s.userId !== targetUser.id));
    setCurrentToken(null);

    // Create fresh session and auto-login
    const client = detectClientEnvironment();
    const token = generateRandomToken();
    const session: UserSession = {
      id: `sess-${Date.now()}`,
      userId: targetUser.id,
      token,
      device: client.device,
      browser: client.browser,
      ip: client.ip,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    };

    setSessions(prev => [session, ...prev]);
    setCurrentToken(token);
    closeAuthModal();

    addEmailNotice({
      type: 'security_alert',
      toEmail: targetUser.email,
      subject: 'Password reset completed — 2FA was disabled, please re-enroll'
    });

    return { success: true };
  };

  // 8. Email Verification: Send
  const sendVerificationEmail = async (): Promise<{ success: boolean; code?: string }> => {
    if (!currentUser) return { success: false };

    const code = generateSixDigitCode();
    const expiry = Date.now() + 24 * 60 * 60 * 1000;

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      emailVerificationCode: code,
      emailVerificationExpiresAt: expiry
    } : u));

    addEmailNotice({
      type: 'verification',
      toEmail: currentUser.email,
      subject: `Verify your email: Code ${code}`,
      code
    });

    return { success: true, code };
  };

  // 9. Email Verification: Confirm
  const verifyEmail = async (code: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const cleanCode = code.trim();
    if (!currentUser.emailVerificationCode || currentUser.emailVerificationCode !== cleanCode) {
      return { success: false, error: 'Invalid verification code. Please check and try again.' };
    }

    if (currentUser.emailVerificationExpiresAt && currentUser.emailVerificationExpiresAt < Date.now()) {
      return { success: false, error: 'Verification code has expired. Please request a new code.' };
    }

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      isEmailVerified: true,
      emailVerificationCode: undefined,
      emailVerificationExpiresAt: undefined,
      updatedAt: new Date().toISOString()
    } : u));

    closeAuthModal();
    return { success: true };
  };

  // 10. Two-Factor Authentication: Start Setup
  const start2FASetup = (): TwoFactorSetupData => {
    const email = currentUser?.email || 'user@microbiz.com';
    const secret = generateBase32Secret(16);
    const otpauthUri = generateOtpauthUri(email, secret);
    const backupCodes = generateBackupCodes(8);

    return { secret, otpauthUri, backupCodes };
  };

  // 11. Two-Factor Authentication: Confirm Enable — secrets are encrypted
  // with the user's password before being persisted (never plaintext).
  const confirmEnable2FA = async (
    secret: string, 
    candidateCode: string, 
    backupCodes: string[],
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isValid = await verifyTotpCode(secret, candidateCode);
    if (!isValid) {
      return { success: false, error: 'Invalid 6-digit authenticator code. Check your device clock and try again.' };
    }

    const isPasswordCorrect = await verifyPassword(password, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect) {
      return { success: false, error: 'Incorrect password. 2FA enrollment requires password confirmation.' };
    }

    try {
      const saltBytes = new Uint8Array(16);
      window.crypto.getRandomValues(saltBytes);
      const saltB64 = u8ToB64(saltBytes);
      const key = await deriveAesKey(password, saltBytes);
      const secretEnc = await encryptWithExistingKey(secret, key, saltB64);
      const codesEnc = await encryptWithExistingKey(JSON.stringify(backupCodes), key, saltB64);

      vaultCache.set(currentUser.id, { secret, backupCodes: [...backupCodes], key, saltB64 });

      setUsers(prev => prev.map(u => u.id === currentUser.id ? {
        ...u,
        twoFactorEnabled: true,
        twoFactorSecretEnc: secretEnc,
        twoFactorBackupCodesEnc: codesEnc,
        updatedAt: new Date().toISOString()
      } : u));
    } catch (e) {
      console.error('2FA enrollment encryption failed:', e);
      return { success: false, error: 'Failed to secure 2FA credentials. Please try again.' };
    }

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Two-Factor Authentication Enabled on your account'
    });

    return { success: true };
  };

  // Password-gated reveal of backup codes — never shown without re-authentication
  const revealBackupCodes = async (password: string): Promise<{ success: boolean; codes?: string[]; error?: string }> => {
    if (!currentUser?.twoFactorEnabled || !currentUser.twoFactorBackupCodesEnc) {
      return { success: false, error: 'Two-factor authentication is not enabled.' };
    }
    const isPasswordCorrect = await verifyPassword(password, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect) {
      return { success: false, error: 'Incorrect password.' };
    }
    try {
      const codesJson = await decryptWithPassword(currentUser.twoFactorBackupCodesEnc, password);
      return { success: true, codes: JSON.parse(codesJson) as string[] };
    } catch (e) {
      console.error('Backup code reveal failed:', e);
      return { success: false, error: 'Could not decrypt backup codes.' };
    }
  };

  // 12. Two-Factor Authentication: Disable
  const disable2FA = async (currentPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect) {
      return { success: false, error: 'Incorrect password. Password verification is required to disable 2FA.' };
    }

    vaultCache.delete(currentUser.id);
    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      twoFactorEnabled: false,
      twoFactorSecretEnc: undefined,
      twoFactorBackupCodesEnc: undefined,
      updatedAt: new Date().toISOString()
    } : u));

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Two-Factor Authentication was disabled on your account'
    });

    return { success: true };
  };

  // 13. Password Change — re-encrypts 2FA secrets from old password to new
  const changePassword = async (currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    if (newPassword.length < 8) {
      return { success: false, error: 'New password must be at least 8 characters long.' };
    }

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect) {
      return { success: false, error: 'Current password is incorrect.' };
    }

    const newSalt = generateSalt(16);
    const newHash = await hashPassword(newPassword, newSalt);

    // Re-encrypt 2FA secrets under the new password so they stay accessible
    let newSecretEnc = currentUser.twoFactorSecretEnc;
    let newCodesEnc = currentUser.twoFactorBackupCodesEnc;
    if (currentUser.twoFactorEnabled && currentUser.twoFactorSecretEnc) {
      try {
        const oldSaltB64 = extractPayloadSalt(currentUser.twoFactorSecretEnc);
        const oldKey = await deriveAesKey(currentPassword, b64ToU8(oldSaltB64));
        const secret = await decryptWithKey(currentUser.twoFactorSecretEnc, oldKey);
        const codesJson = currentUser.twoFactorBackupCodesEnc
          ? await decryptWithKey(currentUser.twoFactorBackupCodesEnc, oldKey)
          : '[]';
        const newSaltBytes = new Uint8Array(16);
        window.crypto.getRandomValues(newSaltBytes);
        const newSaltB64 = u8ToB64(newSaltBytes);
        const newKey = await deriveAesKey(newPassword, newSaltBytes);
        newSecretEnc = await encryptWithExistingKey(secret, newKey, newSaltB64);
        newCodesEnc = await encryptWithExistingKey(codesJson, newKey, newSaltB64);
        vaultCache.set(currentUser.id, {
          secret,
          backupCodes: JSON.parse(codesJson) as string[],
          key: newKey,
          saltB64: newSaltB64
        });
      } catch (e) {
        console.error('2FA re-encryption failed:', e);
        return { success: false, error: 'Could not migrate 2FA credentials. Please disable 2FA first, then change your password.' };
      }
    }

    setUsers(prev => prev.map(u => u.id === currentUser.id ? {
      ...u,
      passwordSalt: newSalt,
      passwordHash: newHash,
      twoFactorSecretEnc: newSecretEnc,
      twoFactorBackupCodesEnc: newCodesEnc,
      mustChangePassword: false,
      updatedAt: new Date().toISOString()
    } : u));

    // Terminate other sessions for security
    logoutOtherSessions();

    addEmailNotice({
      type: 'security_alert',
      toEmail: currentUser.email,
      subject: 'Your password was changed successfully'
    });

    return { success: true };
  };

  // 14. Account Deletion
  const deleteAccount = async (currentPassword: string): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Not authenticated.' };

    const isPasswordCorrect = await verifyPassword(currentPassword, currentUser.passwordSalt, currentUser.passwordHash);
    if (!isPasswordCorrect) {
      return { success: false, error: 'Incorrect password. Account deletion requires valid password authorization.' };
    }

    const userId = currentUser.id;
    vaultCache.delete(userId);

    // Remove user
    setUsers(prev => prev.filter(u => u.id !== userId));

    // Remove all sessions
    setSessions(prev => prev.filter(s => s.userId !== userId));
    setCurrentToken(null);

    closeSecuritySettings();
    openAuthModal('login');

    return { success: true };
  };

  // 15. Update Profile — role changes are NOT allowed here; roles are
  // granted by an owner through user management, never self-assigned.
  const updateProfile = (updates: Partial<Pick<AuthUser, 'name' | 'avatar'>>) => {
    if (!currentUser) return;
    setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, ...updates, updatedAt: new Date().toISOString() } : u));
  };

  // 16. Team management (owner-only) — staff accounts on a shared device.

  /** Shared guard for all team-management actions. Returns an error string or null. */
  const requireTeamManager = (): string | null => {
    if (!currentUser) return 'Not authenticated.';
    if (!can('users.manage')) return 'Only the business owner can manage the team.';
    return null;
  };

  /** True when at least one active owner besides `excludeUserId` exists. */
  const ownerRemains = (excludeUserId?: string): boolean => {
    return users.some(u => u.id !== excludeUserId && u.role === 'owner' && u.isActive !== false);
  };

  const updateUserRole = async (userId: string, role: UserRole): Promise<{ success: boolean; error?: string }> => {
    const blocked = requireTeamManager();
    if (blocked) return { success: false, error: blocked };
    const target = users.find(u => u.id === userId);
    if (!target) return { success: false, error: 'User not found.' };
    if (target.role === role) return { success: true };
    if (target.role === 'owner' && role !== 'owner' && !ownerRemains(userId)) {
      return { success: false, error: 'At least one active owner must remain. Promote someone else first.' };
    }
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role, updatedAt: new Date().toISOString() } : u));
    return { success: true };
  };

  const setUserActive = async (userId: string, active: boolean): Promise<{ success: boolean; error?: string }> => {
    const blocked = requireTeamManager();
    if (blocked) return { success: false, error: blocked };
    const target = users.find(u => u.id === userId);
    if (!target) return { success: false, error: 'User not found.' };
    if (userId === currentUser?.id) {
      return { success: false, error: 'You cannot deactivate your own account.' };
    }
    if (!active && target.role === 'owner' && !ownerRemains(userId)) {
      return { success: false, error: 'At least one active owner must remain.' };
    }
    if ((target.isActive !== false) === active) return { success: true };
    if (!active) {
      // Kill their sessions immediately and drop cached 2FA secrets.
      vaultCache.delete(userId);
      setSessions(prev => prev.filter(s => s.userId !== userId));
    }
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, isActive: active, updatedAt: new Date().toISOString() } : u));
    return { success: true };
  };

  const adminResetPassword = async (userId: string): Promise<{ success: boolean; tempPassword?: string; error?: string }> => {
    const blocked = requireTeamManager();
    if (blocked) return { success: false, error: blocked };
    const target = users.find(u => u.id === userId);
    if (!target) return { success: false, error: 'User not found.' };
    if (userId === currentUser?.id) {
      return { success: false, error: 'Use Change Password for your own account.' };
    }
    const tempPassword = generateTempPassword();
    const salt = generateSalt(16);
    const hash = await hashPassword(tempPassword, salt);
    // Force re-login: drop sessions and vault; 2FA secrets were encrypted
    // with the old password and must be re-enrolled by the user.
    vaultCache.delete(userId);
    setSessions(prev => prev.filter(s => s.userId !== userId));
    setUsers(prev => prev.map(u => u.id === userId ? {
      ...u,
      passwordSalt: salt,
      passwordHash: hash,
      mustChangePassword: true,
      twoFactorEnabled: false,
      twoFactorSecretEnc: undefined,
      twoFactorBackupCodesEnc: undefined,
      updatedAt: new Date().toISOString()
    } : u));
    return { success: true, tempPassword };
  };

  const createUser = async (name: string, email: string, password: string, role: UserRole): Promise<{ success: boolean; error?: string }> => {
    const blocked = requireTeamManager();
    if (blocked) return { success: false, error: blocked };
    const normalizedEmail = email.trim().toLowerCase();
    if (!name.trim() || !normalizedEmail || !password) {
      return { success: false, error: 'Please provide all required fields.' };
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }
    if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, error: 'An account with this email address already exists.' };
    }
    const validRoles: UserRole[] = ['owner', 'admin', 'sales', 'inventory', 'accountant', 'viewer'];
    if (!validRoles.includes(role)) {
      return { success: false, error: 'Invalid role selected.' };
    }
    const salt = generateSalt(16);
    const hash = await hashPassword(password, salt);
    const newUser: AuthUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: normalizedEmail,
      role,
      avatar: name.trim().split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 2),
      passwordSalt: salt,
      passwordHash: hash,
      // Created by the owner on a shared device — no email round-trip needed.
      isEmailVerified: true,
      twoFactorEnabled: false,
      isActive: true,
      mustChangePassword: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setUsers(prev => [newUser, ...prev]);
    return { success: true };
  };

  // 17. Backup support: export / restore the users table (I11)
  const getBackupUsers = (): AuthUser[] => users;

  const restoreBackupUsers = (data: unknown): { success: boolean; error?: string } => {
    if (!Array.isArray(data)) {
      return { success: false, error: 'Backup "users" section is not an array.' };
    }
    for (const u of data) {
      const valid = u && typeof u.id === 'string' && typeof u.email === 'string'
        && typeof u.passwordHash === 'string' && typeof u.passwordSalt === 'string'
        && typeof u.role === 'string';
      if (!valid) {
        return { success: false, error: 'Backup "users" section has an invalid shape.' };
      }
    }
    setUsers(data as AuthUser[]);
    // Sessions referenced the old user table — force re-login for safety
    vaultCache.clear();
    setSessions([]);
    setCurrentToken(null);
    return { success: true };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentSession,
        allSessions: userSessions,
        isAuthenticated,
        isEmailVerified,
        twoFactorPending,
        mockEmailNotices: mockNotices,
        latestEmailNotice,
        isAuthModalOpen,
        authModalView,
        isSecuritySettingsOpen,
        openAuthModal,
        closeAuthModal,
        openSecuritySettings,
        closeSecuritySettings,
        dismissEmailNotice,
        register,
        login,
        verify2FALogin,
        cancel2FALogin,
        logout,
        can,
        logoutOtherSessions,
        revokeSession,
        requestPasswordReset,
        resetPassword,
        sendVerificationEmail,
        verifyEmail,
        start2FASetup,
        confirmEnable2FA,
        disable2FA,
        revealBackupCodes,
        changePassword,
        deleteAccount,
        updateProfile,
        allUsers: users,
        mustChangePasswordNow,
        updateUserRole,
        setUserActive,
        adminResetPassword,
        createUser,
        getBackupUsers,
        restoreBackupUsers
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
